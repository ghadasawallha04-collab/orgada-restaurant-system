<?php
session_start();
//Redirect user if logged in correctly
if (isset($_SESSION['role']) && isset($_SESSION['user_id'])) {

  if (strtolower($_SESSION['role']) === 'admin') {
    header("Location: admin.php");
  } else {
    // Any non-admin user (cashier)
    header("Location: cashier.php");
  }

  exit;
}
?>
<!doctype html>
<html>
<head>
  <title>Orgada | Login Page</title>
  <style>
    *{
      box-sizing:border-box
    }
    body{
      margin:0;
      font-family:Arial, sans-serif;
      background:#0b0b0d;
      color:#ffffff;
    }
    a{
      color:inherit;
      text-decoration:none
    }
    .wrap{
      width:1150px;
      margin:0 auto
    }

    .nav{
      background:#0b0b0d;
      border-bottom:1px solid rgba(255,255,255,.12);
    }
    .nav-inner{
      display:flex;
      align-items:center;
      justify-content:space-between;
      padding:14px 0;
    }
    .brand{
      display:flex;
      align-items:center;
      gap:12px;
    }
    .brand img{
      width:46px;
      height:46px;
      border-radius:14px;
      background:#fff;
      object-fit:cover;
    }
    .brand b{
      font-size:16px
    }
    .brand span{
      display:block;
      font-size:12px;
      color:#cfcfd4;
      margin-top:3px
    }

    .nav-links{
      display:flex;
      gap:18px;
      font-size:13px;
      color:#cfcfd4;
    }
    .nav-links a:hover{
      color:#ffffff
    }

    .btn{
      padding:10px 14px;
      border-radius:14px;
      border:1px solid rgba(255,255,255,.12);
      font-weight:700;
      cursor:pointer;
      background:transparent;
      color:#ffffff;
    }
    .btn.primary{
      background:#d71920;
      border:none;
    }

    .page{
      padding:50px 0;
    }

    .card{
      width:520px;
      background:#121216;
      border:1px solid rgba(255,255,255,.12);
      border-radius:18px;
      padding:24px;
      box-shadow:0 18px 45px rgba(0,0,0,.45);
    }

    h1{
      margin:0 0 8px;
      font-size:26px
    }
    p{
      margin:0 0 18px;
      color:#cfcfd4;
      line-height:1.7;
      font-size:14px
    }

    label{
      display:block;
      margin:0 0 8px;
      font-weight:700;
      font-size:13px;
      color:#ffffff
    }
    input{
      width:100%;
      padding:12px 12px;
      border-radius:14px;
      border:1px solid rgba(255,255,255,.12);
      background:#0f0f13;
      color:#ffffff;
      outline:none;
    }
    input:focus{
      border-color:rgba(215,25,32,.55);
    }

    .field{
      margin-bottom:14px
    }

    .msg{
      margin:0 0 14px;
      padding:10px 12px;
      border-radius:14px;
      border:1px solid rgba(215,25,32,.35);
      background:rgba(215,25,32,.10);
      color:#ffffff;
      font-size:13px;
    }

    .actions{
      display:flex;
      gap:10px;
      align-items:center;
      margin-top:4px;
    }
  </style>
</head>

<body>

<header class="nav">
  <div class="wrap nav-inner">
    <a class="brand" href="index.php">
      <img src="assets/logo.jpg" alt="Orgada Logo">
      <div>
        <b>ORGADA BURGERS</b>
      </div>
    </a>
    <nav class="nav-links">
      <a href="index.php#about">About</a>
      <a href="index.php#menu">Menu</a>
      <a href="index.php#contact">Contact</a>
    </nav>

    <a class="btn" href="index.php">Home</a>
  </div>
</header>

<section class="page">
  <div class="wrap">
    <div class="card">
      <h1>Login</h1>
      <p>
        This page is for staff access only. If you are a customer, please go back to the homepage.
      </p>
      
      <!-- Error message when enter incorrect credintals-->
      <?php if (isset($_GET['error'])): ?>
        <div class="msg">Incorrect username or password! Please try again.</div>
      <?php endif; ?>

      <form method="post" action="auth.php">
        <div class="field">
          <label for="username">Username</label>
          <input id="username" type="text" name="username" required
                 autocomplete="username" maxlength="50"
                 spellcheck="false" autocapitalize="none">
        </div>

        <div class="field">
          <label for="password">Password</label>
          <input id="password" type="password" name="password" required
                 autocomplete="current-password">
        </div>

        <div class="actions">
          <button class="btn primary" type="submit">Login</button>
          <a class="btn" href="index.php">Cancel</a>
        </div>
      </form>

    </div>
  </div>
</section>

</body>
</html>
