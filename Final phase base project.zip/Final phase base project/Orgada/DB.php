<?php
/**************Database information***************/
$dbHost="localhost";
$dbUser="root";
$dbPassword="";         
$dbName="Orgada";
/**************Create Connection***************/
$databaseConnection=new mysqli($dbHost,$dbUser,$dbPassword,$dbName);
/**************Check Connection***************/
if ($databaseConnection->connect_error) {
    die("Connection failed:". $databaseConnection->connect_error);
}
//echo "Connected Sucessfully"; //This is just for testing
?>
