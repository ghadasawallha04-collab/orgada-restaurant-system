<?php
session_start();
require_once "DB.php";

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
  header("Location: login.php");
  exit;
}
if (strtolower($_SESSION['role']) === 'admin') {
  header("Location: admin.php");
  exit;
}

$uid = (int)$_SESSION['user_id'];
$name = $_SESSION['username'] ?? 'Staff';
$job  = strtolower($_SESSION['job_type'] ?? 'cashier');

function canSee($job, $module) {
  $map = [
    'cashier'  => ['pos','sales','profile'],
    'chef'     => ['kitchen','profile'],
    'waiter'   => ['tables','orders','profile'],
    'delivery' => ['deliveries','profile'],
  ];
  return in_array($module, $map[$job] ?? ['profile'], true);
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Staff | Dashboard</title>
<style>
  body{font-family:Arial;background:#0b0b0d;color:#fff;margin:0}
  .wrap{width:1100px;margin:40px auto}
  .box{background:#121216;padding:20px;border-radius:14px;margin-bottom:18px;border:1px solid rgba(255,255,255,.12)}
  .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
  .btn{display:inline-block;padding:10px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.12);color:#fff;text-decoration:none;background:transparent}
  .muted{color:#cfcfd4}
  .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
  details.panel{border:1px solid rgba(255,255,255,.12);border-radius:14px;background:#0f0f14;overflow:hidden}
  summary.card{list-style:none;cursor:pointer;padding:18px;display:flex;gap:14px;align-items:center}
  summary.card::-webkit-details-marker{display:none}
  .ico{width:44px;height:44px;border-radius:14px;display:grid;place-items:center;background:rgba(215,25,32,.12);border:1px solid rgba(215,25,32,.25);font-size:20px}
  .card h4{margin:0;font-size:16px}
  .card small{color:#cfcfd4}
  details[open] summary.card{border-bottom:1px solid rgba(255,255,255,.12)}
  .panel-body{padding:16px 18px;background:#101014}
  table{width:100%;border-collapse:collapse;margin-top:10px}
  th,td{padding:10px;border-bottom:1px solid #333;text-align:left}
  th{color:#cfcfd4}
  .pill{display:inline-block;padding:4px 10px;border-radius:999px;border:1px solid rgba(255,255,255,.14);font-size:12px;color:#cfcfd4}
</style>
</head>
<body>
<div class="wrap">

  <div class="top">
    <div>
      <h1 style="margin:0;">Welcome, <?= htmlspecialchars($name) ?></h1>
      <div class="muted" style="margin-top:6px;">Job: <span class="pill"><?= htmlspecialchars($job) ?></span></div>
    </div>
    <a class="btn" href="logout.php">Logout</a>
  </div>

  <div class="box">
    <h3 style="margin:0 0 12px;">Actions</h3>

    <div class="grid">

      <?php if (canSee($job,'pos')): ?>
      <details class="panel">
        <summary class="card">
          <div class="ico">🧾</div>
          <div>
            <h4>Open POS</h4>
            <small>Create a new sale</small>
          </div>
        </summary>
        <div class="panel-body">
          <a class="btn" href="pos.php">Open POS Page</a>
          <div class="muted" style="margin-top:10px;">(POS full screen page)</div>
        </div>
      </details>
      <?php endif; ?>

      <?php if (canSee($job,'sales')): ?>
      <details class="panel">
        <summary class="card">
          <div class="ico">📊</div>
          <div>
            <h4>My Sales</h4>
            <small>Latest invoices</small>
          </div>
        </summary>
        <div class="panel-body">
          <?php
            $stmt = $databaseConnection->prepare(
              "SELECT SaleID, SaleDate, TotalAmount
               FROM sale
               WHERE CreatedBy=?
               ORDER BY SaleID DESC
               LIMIT 10"
            );
            $stmt->bind_param("i",$uid);
            $stmt->execute();
            $sales = $stmt->get_result();
          ?>
          <table>
            <tr><th>ID</th><th>Date</th><th>Total</th><th>Action</th></tr>
            <?php while($s = $sales->fetch_assoc()): ?>
              <tr>
                <td><?= (int)$s['SaleID'] ?></td>
                <td><?= htmlspecialchars($s['SaleDate']) ?></td>
                <td><?= number_format((float)$s['TotalAmount'],2) ?></td>
                <td><a class="btn" href="invoice.php?id=<?= (int)$s['SaleID'] ?>">View</a></td>
              </tr>
            <?php endwhile; ?>
          </table>
        </div>
      </details>
      <?php endif; ?>
<!-- 
      <details class="panel">
        <summary class="card">
          <div class="ico">💳</div>
          <div>
            <h4>Payment Methods</h4>
            <small>View available methods</small>
          </div>
        </summary>
        <div class="panel-body">
          <a class="btn" href="payment_methods.php">Open Payment Methods</a>
          <div class="muted" style="margin-top:10px;">(View only for staff)</div>
        </div>
      </details> -->

      <?php if (canSee($job,'kitchen')): ?>
      <details class="panel">
        <summary class="card">
          <div class="ico">👨‍🍳</div>
          <div>
            <h4>Kitchen Orders</h4>
            <small>Pending / in-progress</small>
          </div>
        </summary>
        <div class="panel-body">
          <?php
            $q = $databaseConnection->query(
              "SELECT OrderID, CreatedAt, Status
               FROM `Order`
               WHERE Status IN ('Pending','Preparing')
               ORDER BY OrderID DESC
               LIMIT 10"
            );
          ?>
          <table>
            <tr><th>Order</th><th>Time</th><th>Status</th></tr>
            <?php while($o = $q->fetch_assoc()): ?>
              <tr>
                <td>#<?= (int)$o['OrderID'] ?></td>
                <td><?= htmlspecialchars($o['CreatedAt']) ?></td>
                <td><?= htmlspecialchars($o['Status']) ?></td>
              </tr>
            <?php endwhile; ?>
          </table>
        </div>
      </details>
      <?php endif; ?>

      <?php if (canSee($job,'tables')): ?>
      <details class="panel">
        <summary class="card">
          <div class="ico">🍽️</div>
          <div>
            <h4>Tables</h4>
            <small>Current table status</small>
          </div>
        </summary>
        <div class="panel-body">
          <?php
            $t = $databaseConnection->query(
              "SELECT TableNo, Status
               FROM TableStatus
               ORDER BY TableNo ASC"
            );
          ?>
          <table>
            <tr><th>Table</th><th>Status</th></tr>
            <?php while($r = $t->fetch_assoc()): ?>
              <tr>
                <td><?= htmlspecialchars($r['TableNo']) ?></td>
                <td><?= htmlspecialchars($r['Status']) ?></td>
              </tr>
            <?php endwhile; ?>
          </table>
        </div>
      </details>
      <?php endif; ?>

      <?php if (canSee($job,'deliveries')): ?>
      <details class="panel">
        <summary class="card">
          <div class="ico">🛵</div>
          <div>
            <h4>Deliveries</h4>
            <small>Assigned deliveries</small>
          </div>
        </summary>
        <div class="panel-body">
          <?php
            $stmt = $databaseConnection->prepare(
              "SELECT DeliveryID, OrderID, Status
               FROM Delivery
               WHERE AssignedTo=?
               ORDER BY DeliveryID DESC
               LIMIT 10"
            );
            $stmt->bind_param("i",$uid);
            $stmt->execute();
            $d = $stmt->get_result();
          ?>
          <table>
            <tr><th>Delivery</th><th>Order</th><th>Status</th></tr>
            <?php while($x = $d->fetch_assoc()): ?>
              <tr>
                <td>#<?= (int)$x['DeliveryID'] ?></td>
                <td>#<?= (int)$x['OrderID'] ?></td>
                <td><?= htmlspecialchars($x['Status']) ?></td>
              </tr>
            <?php endwhile; ?>
          </table>
        </div>
      </details>
      <?php endif; ?>

      <details class="panel" open>
        <summary class="card">
          <div class="ico">👤</div>
          <div>
            <h4>My Profile</h4>
            <small>Account information</small>
          </div>
        </summary>
        <div class="panel-body">
          <a class="btn" href="cashier_profile.php">Open Profile</a>
          <div class="muted" style="margin-top:10px;">(Includes password change if allowed)</div>
        </div>
      </details>

    </div>
  </div>

</div>
</body>
</html>
