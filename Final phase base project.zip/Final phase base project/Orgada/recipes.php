<?php
session_start();
require_once "DB.php";
//Allow admin access only
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}
//Add new recipe
if (isset($_POST['add_recipe'])) {
  $name = trim($_POST['recipe_name'] ?? '');
  if ($name !== '') {
    $statement = $databaseConnection->prepare("INSERT INTO Recipe (RecipeName) VALUES (?)");
    $statement->bind_param("s", $name);
    $statement->execute();
  }
  header("Location: recipes.php");
  exit;
}
//Delete existing recipe
if (isset($_POST['delete_recipe'])) {
  $id=(int)($_POST['recipe_id'] ?? 0);
  if ($id > 0) {
    $chk = $databaseConnection->prepare("SELECT COUNT(*) c FROM MenuItem WHERE recipeID=?");
    $chk->bind_param("i", $id);
    $chk->execute();
    $c = (int)($chk->get_result()->fetch_assoc()['c'] ?? 0);
    if ($c > 0) {
      header("Location: recipes.php?msg=used");
      exit;
    }
    $statement=$databaseConnection->prepare("DELETE FROM Recipe WHERE RecipeID=?");
    $statement->bind_param("i", $id);
    $statement->execute();
  }
  header("Location: recipes.php");
  exit;
}
//Edit Existing recipe
$editRow = null;
if (isset($_GET['edit'])) {
  $id = (int)$_GET['edit'];
  if ($id > 0) {
    $statement=$databaseConnection->prepare("SELECT * FROM Recipe WHERE RecipeID=? LIMIT 1");
    $statement->bind_param("i", $id);
    $statement->execute();
    $editRow=$statement->get_result()->fetch_assoc();
  }
}
if (isset($_POST['update_recipe'])) {
  $id=(int)($_POST['recipe_id'] ?? 0);
  $name=trim($_POST['recipe_name'] ?? '');
  if ($id > 0 && $name !== '') {
    $stmt = $databaseConnection->prepare("UPDATE Recipe SET RecipeName=? WHERE RecipeID=?");
    $stmt->bind_param("si", $name, $id);
    $stmt->execute();
  }
  header("Location: recipes.php");
  exit;
}
$recipes=$databaseConnection->query("SELECT * FROM Recipe ORDER BY RecipeID DESC");
?>
<!--HTML&CSS Codes-->
<!doctype html>
<html>
<head>
  <title>Admin | Recipes</title>
  <style>
  body {
    font-family: Arial;
    background: #0b0b0d;
    color: #fff;
    margin: 0;
  }

  .wrap {
    width: 1100px;
    margin: 40px auto;
  }

  .top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
  }

  .box {
    background: #121216;
    padding: 20px;
    border-radius: 14px;
    margin-bottom: 18px;
    border: 1px solid rgba(255, 255, 255, 0.12);
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 14px;
  }

  th,
  td {
    padding: 10px;
    border-bottom: 1px solid #333;
    text-align: left;
  }

  th {
    color: #cfcfd4;
  }

  input,
  button {
    padding: 8px;
    border-radius: 8px;
    border: none;
    margin: 4px;
    outline: none;
  }

  input {
    width: 360px;
  }

  button {
    cursor: pointer;
    background: #d71920;
    color: #fff;
    font-weight: 700;
  }

  .btn-lite {
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.12);
    color: #fff;
    display: inline-block;
    padding: 8px 14px;
    border-radius: 10px;
  }

  .danger {
    background: #ff4d4d;
  }

  .row-actions {
    display: flex;
    gap: 8px;
    align-items: center;
  }
</style>

</head>
<body>
<div class="wrap">

  <div class="top">
    <h1 style="margin:0;">Recipes</h1>
    <div style="display:flex;gap:10px;align-items:center;">
      <a href="recipeingredients.php" class="btn-lite">Recipe Ingredients</a>
      <a href="admin.php" class="btn-lite">← Back to Dashboard</a>
    </div>
  </div>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'used'): ?>
    <div class="box" style="border-color:rgba(215,25,32,.35);background:rgba(215,25,32,.10);">
      This recipe cannot be deleted because it is used in Menu Items.
    </div>
  <?php endif; ?>

  <div class="box">
    <h3 style="margin:0 0 10px;"><?= $editRow ? "Edit Recipe" : "Add New Recipe" ?></h3>
    <form method="post">
      <?php if ($editRow): ?>
        <input type="hidden" name="recipe_id" value="<?= (int)$editRow['RecipeID'] ?>">
      <?php endif; ?>

      <input name="recipe_name" placeholder="Recipe Name" required value="<?= htmlspecialchars($editRow['RecipeName'] ?? '') ?>">

      <?php if ($editRow): ?>
        <button type="submit" name="update_recipe">Update</button>
        <a class="btn-lite" href="recipes.php" style="padding:8px 12px;">Cancel</a>
      <?php else: ?>
        <button type="submit" name="add_recipe">Add</button>
      <?php endif; ?>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Recipes List</h3>
    <table>
      <tr>
        <th>ID</th>
        <th>Recipe Name</th>
        <th>Action</th>
      </tr>

      <?php while($row = $recipes->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['RecipeID'] ?></td>
          <td><?= htmlspecialchars($row['RecipeName']) ?></td>
          <td class="row-actions">
            <a class="btn-lite" href="recipes.php?edit=<?= (int)$row['RecipeID'] ?>">Edit</a>
            <a class="btn-lite" href="recipeingredients.php?rid=<?= (int)$row['RecipeID'] ?>">Ingredients</a>

            <form method="post" onsubmit="return confirm('Delete this recipe?');" style="margin:0;">
              <input type="hidden" name="recipe_id" value="<?= (int)$row['RecipeID'] ?>">
              <button class="danger" type="submit" name="delete_recipe">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

</div>
</body>
</html>
