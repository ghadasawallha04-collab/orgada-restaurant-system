<?php
session_start();
require_once "DB.php";

/* Allow access only for cashier */
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'cashier') {
  header("Location: login.php");
  exit;
}

$name = $_SESSION['name'] ?? 'Cashier';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Cashier | Dashboard</title>
<style>
  body{font-family:Arial;background:#0b0b0d;color:#fff;margin:0}
  .wrap{width:1100px;margin:40px auto}
  .box{background:#121216;padding:20px;border-radius:14px;margin-bottom:18px;border:1px solid rgba(255,255,255,.12)}
  .grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}
  a.card{display:block;text-decoration:none;color:#fff;padding:18px;border-radius:14px;border:1px solid rgba(255,255,255,.12);background:#0f0f14}
  a.card:hover{border-color:rgba(215,25,32,.7)}
  .btn{display:inline-block;padding:10px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.12);color:#fff;text-decoration:none}
</style>
</head>
<body>
<div class="wrap">

  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
    <h1 style="margin:0;">Welcome, <?= htmlspecialchars($name) ?></h1>
    <a class="btn" href="logout.php">Logout</a>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Cashier Actions</h3>
    <div class="grid">
      <a class="card" href="pos.php">
        <b>Open POS</b><br><small>Create a new sale</small>
      </a>

      <a class="card" href="cashier_sales.php">
        <b>My Sales</b><br><small>View my invoices</small>
      </a>

      <a class="card" href="cashier_profile.php">
        <b>My Profile</b><br><small>Change password</small>
      </a>
    </div>
  </div>

</div>
</body>
</html>
