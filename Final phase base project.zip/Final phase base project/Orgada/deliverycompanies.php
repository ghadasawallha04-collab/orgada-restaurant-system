<?php
session_start();
require_once "DB.php";
//Allow admin access only
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}

//Add delivery Company
if (isset($_POST['add_dc'])) {
  $name=trim($_POST['company_name'] ?? '');
  $phone=trim($_POST['phone'] ?? '');
  if ($name !== '') {
    $statment = $databaseConnection->prepare(
      "INSERT INTO DeliveryCompany (CompanyName, phone) VALUES (?, ?)"
    );
    $statment->bind_param("ss", $name, $phone);
    $statment->execute();
  }
  header("Location: deliverycompanies.php");
  exit;
}
//Delete delivery Company
if (isset($_POST['delete_dc'])) {
  $id = (int)($_POST['dc_id'] ?? 0);

  if ($id > 0) {
    $chk = $databaseConnection->prepare("SELECT COUNT(*) c FROM Orders WHERE deliverycompanyID=?");
    $chk->bind_param("i", $id);
    $chk->execute();
    $c = (int)($chk->get_result()->fetch_assoc()['c'] ?? 0);

    if ($c > 0) {
      header("Location: deliverycompanies.php?msg=used");
      exit;
    }
    $statment=$databaseConnection->prepare("DELETE FROM DeliveryCompany WHERE DeliveryCompanyID=?");
    $statment->bind_param("i", $id);
    $statment->execute();
  }
  header("Location: deliverycompanies.php");
  exit;
}
//Edit delivery Company
$editRow=null;
if (isset($_GET['edit'])) {
  $id=(int)$_GET['edit'];
  if ($id > 0) {
    $statment=$databaseConnection->prepare(
      "SELECT * FROM DeliveryCompany WHERE DeliveryCompanyID=? LIMIT 1"
    );
    $statment->bind_param("i", $id);
    $statment->execute();
    $editRow=$statment->get_result()->fetch_assoc();
  }
}
if (isset($_POST['update_dc'])) {
  $id=(int)($_POST['dc_id'] ?? 0);
  $name=trim($_POST['company_name'] ?? '');
  $phone=trim($_POST['phone'] ?? '');
  if ($id > 0 && $name !== '') {
    $statment=$databaseConnection->prepare(
      "UPDATE DeliveryCompany SET CompanyName=?, phone=? WHERE DeliveryCompanyID=?"
    );
    $statment->bind_param("ssi", $name, $phone, $id);
    $statment->execute();
  }
  header("Location: deliverycompanies.php");
  exit;
}
//DeliveryCompany List
$companies=$databaseConnection->query(
  "SELECT * FROM DeliveryCompany ORDER BY DeliveryCompanyID DESC"
);
?>
<!--HTML&CSS Codes-->
<!doctype html>
<html>
<head>
  <title>Admin | Delivery Companies</title>
<style>
  body {
    font-family: Arial;
    background: #0b0b0d;
    color: #fff;
    margin: 0;
  }

  .wrap {
    width: 1100px;
    margin: 40px auto;
  }

  .top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
  }

  .box {
    background: #121216;
    padding: 20px;
    border-radius: 14px;
    margin-bottom: 18px;
    border: 1px solid rgba(255, 255, 255, 0.12);
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 14px;
  }

  th,
  td {
    padding: 10px;
    border-bottom: 1px solid #333;
    text-align: left;
  }

  th {
    color: #cfcfd4;
  }

  input,
  button {
    padding: 8px;
    border-radius: 8px;
    border: none;
    margin: 4px;
    outline: none;
  }

  input {
    width: 260px;
  }

  button {
    cursor: pointer;
    background: #d71920;
    color: #fff;
    font-weight: 700;
  }

  .btn-lite {
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.12);
    color: #fff;
    display: inline-block;
    padding: 8px 14px;
    border-radius: 10px;
  }

  .danger {
    background: #ff4d4d;
  }

  .row-actions {
    display: flex;
    gap: 8px;
    align-items: center;
  }
</style>
</head>
<body>
<div class="wrap">

  <div class="top">
    <h1 style="margin:0;">Delivery Companies</h1>
    <a href="admin.php" class="btn-lite">← Back to Dashboard</a>
  </div>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'used'): ?>
    <div class="box" style="border-color:rgba(215,25,32,.35);background:rgba(215,25,32,.10);">
      This delivery company cannot be deleted because it is used in Orders.
    </div>
  <?php endif; ?>

  <div class="box">
    <h3 style="margin:0 0 10px;"><?= $editRow ? "Edit Company" : "Add New Company" ?></h3>

    <form method="post">
      <?php if ($editRow): ?>
        <input type="hidden" name="dc_id" value="<?= (int)$editRow['DeliveryCompanyID'] ?>">
      <?php endif; ?>

      <input name="company_name" placeholder="Company Name" required value="<?= htmlspecialchars($editRow['CompanyName'] ?? '') ?>">
      <input name="phone" placeholder="Phone" value="<?= htmlspecialchars($editRow['phone'] ?? '') ?>">

      <?php if ($editRow): ?>
        <button type="submit" name="update_dc">Update</button>
        <a class="btn-lite" href="deliverycompanies.php" style="padding:8px 12px;">Cancel</a>
      <?php else: ?>
        <button type="submit" name="add_dc">Add</button>
      <?php endif; ?>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Companies List</h3>

    <table>
      <tr>
        <th>ID</th>
        <th>Company Name</th>
        <th>Phone</th>
        <th>Action</th>
      </tr>

      <?php while($row = $companies->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['DeliveryCompanyID'] ?></td>
          <td><?= htmlspecialchars($row['CompanyName']) ?></td>
          <td><?= htmlspecialchars($row['phone'] ?? '') ?></td>
          <td class="row-actions">
            <a class="btn-lite" href="deliverycompanies.php?edit=<?= (int)$row['DeliveryCompanyID'] ?>">Edit</a>

            <form method="post" onsubmit="return confirm('Delete this company?');" style="margin:0;">
              <input type="hidden" name="dc_id" value="<?= (int)$row['DeliveryCompanyID'] ?>">
              <button class="danger" type="submit" name="delete_dc">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

</div>
</body>
</html>
