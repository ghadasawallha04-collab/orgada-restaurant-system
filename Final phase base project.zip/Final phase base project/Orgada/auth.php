<?php
session_start();
require_once "DB.php";
//Verify that login form submited correctly
if (!isset($_POST['username'], $_POST['password'])) {
    header("Location: login.php?error=1");
    exit;
}
$username=trim($_POST['username']);
$password=$_POST['password'];
$stmt=$databaseConnection->prepare(
    "SELECT UserID,Username,PasswordHash,Role,EmployeeID 
     FROM users 
     WHERE Username=? 
     LIMIT 1"
);
$stmt->bind_param("s",$username);
$stmt->execute();
$result = $stmt->get_result();
if ($result->num_rows!== 1) {
    header("Location: login.php?error=1");
    exit;
}
$user=$result->fetch_assoc();
if (!password_verify($password, $user['PasswordHash'])) {
    header("Location: login.php?error=1");
    exit;
}
session_regenerate_id(true);
$_SESSION['user_id'] = $user['UserID'];
$_SESSION['username'] = $user['Username'];
$_SESSION['role'] = $user['Role'];
$_SESSION['employee_id'] = $user['EmployeeID'];
$_SESSION['can_refund']    = (int)$user['CanRefund'];
$_SESSION['can_void']      = (int)$user['CanVoid'];
$_SESSION['can_discount']  = (int)$user['CanDiscount'];
$_SESSION['can_customers'] = (int)$user['CanManageCustomers'];
$_SESSION['can_change_password'] = (int)$user['CanChangePassword'];

if (strtolower($user['Role']) === 'admin' || empty($user['EmployeeID'])) {
    header("Location: admin.php");
} else {
    header("Location: cashier.php");
}

exit;