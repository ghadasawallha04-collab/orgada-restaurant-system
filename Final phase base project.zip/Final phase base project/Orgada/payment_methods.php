<!-- <?php
session_start();
require_once "DB.php";

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
  header("Location: login.php");
  exit;
}
if (strtolower($_SESSION['role']) === 'admin') {
  header("Location: admin.php");
  exit;
}

$methods = $databaseConnection->query("SELECT * FROM paymentmethod ORDER BY 1 ASC");
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Payment Methods</title>
<style>
body{font-family:Arial;background:#0b0b0d;color:#fff;margin:0}
.wrap{width:900px;margin:40px auto}
.box{background:#121216;padding:20px;border-radius:14px;border:1px solid rgba(255,255,255,.12)}
table{width:100%;border-collapse:collapse;margin-top:14px}
th,td{padding:10px;border-bottom:1px solid #333;text-align:left}
th{color:#cfcfd4}
.btn{display:inline-block;padding:10px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.12);color:#fff;text-decoration:none;background:transparent}
</style>
</head>
<body>
<div class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
    <h1 style="margin:0;">Payment Methods</h1>
    <a class="btn" href="cashier.php">← Back</a>
  </div>

  <div class="box">
    <table>
      <tr><th>ID</th><th>Method</th></tr>
      <?php while($m = $methods->fetch_assoc()): 
        $keys = array_keys($m);
        $idKey = $keys[0];
        $nameKey = $keys[1] ?? $keys[0];
      ?>
        <tr>
          <td><?= (int)$m[$idKey] ?></td>
          <td><?= htmlspecialchars($m[$nameKey]) ?></td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>
</div>
</body>
</html> -->
