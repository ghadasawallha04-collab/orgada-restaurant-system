<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role']!=='admin'){
  header("Location: login.php");
  exit;
}
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Orgada | Orders</title>
  <style>
    :root{
      --red:#d71920;
      --black:#0b0b0d;
      --white:#ffffff;
      --muted:#cfcfd4;
      --border:rgba(255,255,255,.12);
      --shadow:0 18px 45px rgba(0,0,0,.45);
      --radius:18px;
    }

    *{ box-sizing:border-box }

    body{
      margin:0;
      font-family:Arial, sans-serif;
      background:var(--black);
      color:var(--white);
      min-width:1200px;
    }

    a{ color:inherit; text-decoration:none }

    .wrap{
      width:1150px;
      margin:0 auto;
    }

    .nav{
      background:#0b0b0d;
      border-bottom:1px solid var(--border);
    }

    .nav-inner{
      display:flex;
      align-items:center;
      justify-content:space-between;
      padding:14px 0;
    }

    .brand{
      display:flex;
      align-items:center;
      gap:12px;
    }

    .brand img{
      width:46px;
      height:46px;
      border-radius:14px;
      background:#fff;
      object-fit:cover;
    }

    .brand b{ font-size:16px }

    .brand span{
      display:block;
      font-size:12px;
      color:var(--muted);
      margin-top:3px;
    }

    .btn{
      padding:10px 14px;
      border-radius:14px;
      border:1px solid var(--border);
      font-weight:700;
      cursor:pointer;
      background:transparent;
      color:var(--white);
      display:inline-block;
    }

    .btn.primary{
      background:var(--red);
      border:none;
    }

    .page{ padding:50px 0 }

    .card{
      background:#121216;
      border:1px solid var(--border);
      border-radius:var(--radius);
      padding:22px;
      box-shadow:var(--shadow);
    }

    h1{
      margin:0 0 8px;
      font-size:24px;
    }

    p{
      margin:0 0 18px;
      color:var(--muted);
      line-height:1.7;
      font-size:14px;
    }

    .box{
      padding:18px;
      border-radius:18px;
      border:1px solid var(--border);
      background:#0f0f13;
      margin-top:12px;
    }

    .box h2{
      margin:0 0 8px;
      font-size:18px;
    }

    .box small{
      display:block;
      color:var(--muted);
      line-height:1.6;
      margin-bottom:12px;
    }

    .footer{
      text-align:center;
      font-size:12px;
      color:var(--muted);
      padding:30px 0;
    }
  </style>
</head>

<body>
<header class="nav">
  <div class="wrap nav-inner">
    <div class="brand">
      <img src="assets/logo.jpg" alt="Orgada Logo">
      <div>
        <b>ORGADA BURGERS</b>
        <span>Orders</span>
      </div>
    </div>
    <a class="btn primary" href="logout.php">Logout</a>
  </div>
</header>

<section class="page">
  <div class="wrap">
    <div class="card">
      <h1>Orders</h1>
      <p>Choose what you want to do.</p>

      <div class="box">
        <h2>Orders History</h2>
        <small>View all orders and their items.</small>
        <a class="btn" href="history.php">Open History</a>
      </div>

      <div class="box">
        <h2>Add New Order</h2>
        <small>Create a new order by adding items to an invoice.</small>
        <a class="btn primary" href="AddOrder.php">Add Order</a>
      </div>

    </div>
  </div>
</section>

<footer class="footer">
  copyright 2025 Orgada Burgers — Ghada1220064 - Malak1220203
</footer>
</body>
</html>
