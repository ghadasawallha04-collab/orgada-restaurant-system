<?php
session_start();
require_once "DB.php";

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || strtolower($_SESSION['role']) === 'admin') {
  header("Location: login.php");
  exit;
}

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

$search = trim($_GET['search'] ?? '');
$productsList = null;

$pmList = [];
$pmRes = $databaseConnection->query("SELECT PaymentMethodID, PaymentMethodName FROM paymentmethod ORDER BY PaymentMethodID ASC");
if ($pmRes) {
  while ($r = $pmRes->fetch_assoc()) $pmList[] = $r;
}

if (isset($_POST['add_to_cart'])) {
  $pid = (int)($_POST['product_id'] ?? 0);
  if ($pid > 0) {
    $_SESSION['cart'][$pid] = ($_SESSION['cart'][$pid] ?? 0) + 1;
  }
  $searchBack = urlencode(trim($_POST['search_back'] ?? ''));
  header("Location: pos.php?search=$searchBack#cart");
  exit;
}

if (isset($_POST['update_cart'])) {
  foreach (($_POST['qty'] ?? []) as $pid => $qty) {
    $pid = (int)$pid;
    $qty = (int)$qty;
    if ($qty <= 0) unset($_SESSION['cart'][$pid]);
    else $_SESSION['cart'][$pid] = $qty;
  }
  header("Location: pos.php#cart");
  exit;
}

if (isset($_POST['clear_cart'])) {
  $_SESSION['cart'] = [];
  header("Location: pos.php#cart");
  exit;
}

if (isset($_POST['checkout'])) {
  if (count($_SESSION['cart']) === 0) {
    header("Location: pos.php?msg=empty#cart");
    exit;
  }

  $ids = array_keys($_SESSION['cart']);
  $placeholders = implode(',', array_fill(0, count($ids), '?'));
  $types = str_repeat('i', count($ids));

  $sql = "SELECT MenuItemID AS ProductID, MenuItemName AS Name, Price FROM menuitem WHERE MenuItemID IN ($placeholders)";
  $stmt = $databaseConnection->prepare($sql);
  $stmt->bind_param($types, ...$ids);
  $stmt->execute();
  $res = $stmt->get_result();

  $products = [];
  while ($r = $res->fetch_assoc()) {
    $products[(int)$r['ProductID']] = $r;
  }

  $total = 0;
  foreach ($_SESSION['cart'] as $pid => $qty) {
    if (!isset($products[$pid])) continue;
    $total += ((float)$products[$pid]['Price']) * $qty;
  }

  $methodId  = (int)($_POST['payment_method'] ?? 0);
  $payAmount = (float)($_POST['pay_amount'] ?? 0);
  $status    = trim($_POST['payment_status'] ?? 'Pending');
  if ($status !== 'Paid' && $status !== 'Pending') $status = 'Pending';

  $card = preg_replace('/\D+/', '', $_POST['card_number'] ?? '');
  $txnRef = trim($_POST['txn_ref'] ?? '');

  if ($methodId <= 0 || $payAmount <= 0) {
    header("Location: pos.php?msg=payfail#cart");
    exit;
  }

  $chk = $databaseConnection->prepare("SELECT PaymentMethodName FROM paymentmethod WHERE PaymentMethodID=? LIMIT 1");
  $chk->bind_param("i", $methodId);
  $chk->execute();
  $pmRow = $chk->get_result()->fetch_assoc();
  if (!$pmRow) {
    header("Location: pos.php?msg=payfail#cart");
    exit;
  }

  $pmName = strtolower($pmRow['PaymentMethodName']);

  if (strpos($pmName, 'card') !== false) {
    if (strlen($card) < 12) {
      header("Location: pos.php?msg=cardfail#cart");
      exit;
    }
  }

  if (strpos($pmName, 'online') !== false) {
    if ($txnRef === '') {
      header("Location: pos.php?msg=onlinefail#cart");
      exit;
    }
  }

  if ($status === 'Paid' && $payAmount + 0.00001 < $total) {
    header("Location: pos.php?msg=amountfail#cart");
    exit;
  }

  $databaseConnection->begin_transaction();
  try {
    $createdBy = (int)$_SESSION['user_id'];

    $stmtSale = $databaseConnection->prepare(
      "INSERT INTO sale (SaleDate, TotalAmount, CreatedBy) VALUES (NOW(), ?, ?)"
    );
    $stmtSale->bind_param("di", $total, $createdBy);
    $stmtSale->execute();
    $saleId = $databaseConnection->insert_id;

    $stmtItem = $databaseConnection->prepare(
      "INSERT INTO saleitem (SaleID, ProductID, Qty, UnitPrice, LineTotal) VALUES (?, ?, ?, ?, ?)"
    );

    foreach ($_SESSION['cart'] as $pid => $qty) {
      if (!isset($products[$pid])) continue;
      $price = (float)$products[$pid]['Price'];
      $line  = $price * $qty;
      $stmtItem->bind_param("iiidd", $saleId, $pid, $qty, $price, $line);
      $stmtItem->execute();
    }

    $databaseConnection->commit();
    $_SESSION['cart'] = [];

    header("Location: cashier_sales.php?msg=done");
    exit;

  } catch (Exception $e) {
    $databaseConnection->rollback();
    header("Location: pos.php?msg=fail#cart");
    exit;
  }
}

if ($search !== '') {
  $like = "%" . $search . "%";
  $stmt = $databaseConnection->prepare(
    "SELECT MenuItemID AS ProductID, MenuItemName AS Name, Price
     FROM menuitem
     WHERE MenuItemName LIKE ?
     ORDER BY MenuItemID DESC"
  );
  $stmt->bind_param("s", $like);
  $stmt->execute();
  $productsList = $stmt->get_result();
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>POS</title>
<style>
  body{font-family:Arial;background:#0b0b0d;color:#fff;margin:0}
  .wrap{width:1100px;margin:40px auto}
  .box{background:#121216;padding:20px;border-radius:14px;margin-bottom:18px;border:1px solid rgba(255,255,255,.12)}
  input,button,select{padding:10px;border-radius:10px;border:none;outline:none}
  input,select{background:#0f0f13;color:#fff;border:1px solid rgba(255,255,255,.12)}
  button{cursor:pointer;background:#d71920;color:#fff;font-weight:700}
  table{width:100%;border-collapse:collapse;margin-top:12px}
  th,td{padding:10px;border-bottom:1px solid #333;text-align:left}
  th{color:#cfcfd4}
  .btn-lite{background:transparent;border:1px solid rgba(255,255,255,.12);color:#fff}
  .msg{margin:0 0 14px;padding:10px 12px;border-radius:14px;border:1px solid rgba(215,25,32,.35);background:rgba(215,25,32,.10);font-size:13px;}
  .rowpay{display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end;margin-top:14px}
</style>
</head>
<body>
<div class="wrap">

  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
    <h1 style="margin:0;">POS</h1>
    <a class="btn-lite" href="cashier.php" style="text-decoration:none;padding:10px 14px;border-radius:10px;">← Back</a>
  </div>

  <?php if (isset($_GET['msg']) && $_GET['msg']==='empty'): ?>
    <div class="msg">Cart is empty.</div>
  <?php elseif (isset($_GET['msg']) && $_GET['msg']==='fail'): ?>
    <div class="msg">Checkout failed. Try again.</div>
  <?php elseif (isset($_GET['msg']) && $_GET['msg']==='payfail'): ?>
    <div class="msg">Please select payment method and amount.</div>
  <?php elseif (isset($_GET['msg']) && $_GET['msg']==='cardfail'): ?>
    <div class="msg">Card number is required for Card payments.</div>
  <?php elseif (isset($_GET['msg']) && $_GET['msg']==='onlinefail'): ?>
    <div class="msg">Transaction reference is required for Online payments.</div>
  <?php elseif (isset($_GET['msg']) && $_GET['msg']==='amountfail'): ?>
    <div class="msg">Paid amount must be equal or greater than total.</div>
  <?php endif; ?>

  <div class="box">
    <h3 style="margin:0 0 10px;">Search Product</h3>
    <form method="get" style="display:flex;gap:8px;flex-wrap:wrap;">
      <input name="search" placeholder="Type product name..." value="<?= htmlspecialchars($search) ?>" style="width:320px;">
      <button type="submit">Search</button>
      <a class="btn-lite" href="pos.php" style="text-decoration:none;padding:10px 14px;border-radius:10px;">Reset</a>
    </form>

    <?php if ($productsList !== null): ?>
      <table>
        <tr><th>ID</th><th>Name</th><th>Price</th><th>Action</th></tr>
        <?php while ($p = $productsList->fetch_assoc()): ?>
          <tr>
            <td><?= (int)$p['ProductID'] ?></td>
            <td><?= htmlspecialchars($p['Name']) ?></td>
            <td><?= number_format((float)$p['Price'], 2) ?></td>
            <td>
              <form method="post" style="margin:0;">
                <input type="hidden" name="product_id" value="<?= (int)$p['ProductID'] ?>">
                <input type="hidden" name="search_back" value="<?= htmlspecialchars($search) ?>">
                <button type="submit" name="add_to_cart">Add</button>
              </form>
            </td>
          </tr>
        <?php endwhile; ?>
      </table>
    <?php endif; ?>
  </div>

  <div class="box" id="cart">
    <h3 style="margin:0 0 10px;">Cart</h3>

    <?php if (count($_SESSION['cart']) === 0): ?>
      <p style="color:#cfcfd4;margin:0;">No items in cart.</p>
    <?php else: ?>
      <?php
        $ids = array_keys($_SESSION['cart']);
        $placeholders = implode(',', array_fill(0, count($ids), '?'));
        $types = str_repeat('i', count($ids));
        $sql = "SELECT MenuItemID AS ProductID, MenuItemName AS Name, Price FROM menuitem WHERE MenuItemID IN ($placeholders)";
        $stmt = $databaseConnection->prepare($sql);
        $stmt->bind_param($types, ...$ids);
        $stmt->execute();
        $res = $stmt->get_result();

        $rows = [];
        $total = 0;
        while ($r = $res->fetch_assoc()) {
          $pid = (int)$r['ProductID'];
          $qty = (int)($_SESSION['cart'][$pid] ?? 0);
          $price = (float)$r['Price'];
          $line = $qty * $price;
          $total += $line;
          $rows[] = [$pid, $r['Name'], $price, $qty, $line];
        }
      ?>

      <form method="post">
        <table>
          <tr><th>ID</th><th>Name</th><th>Price</th><th>Qty</th><th>Line</th></tr>
          <?php foreach ($rows as $r): ?>
            <tr>
              <td><?= (int)$r[0] ?></td>
              <td><?= htmlspecialchars($r[1]) ?></td>
              <td><?= number_format((float)$r[2],2) ?></td>
              <td><input type="number" min="0" name="qty[<?= (int)$r[0] ?>]" value="<?= (int)$r[3] ?>" style="width:90px;"></td>
              <td><?= number_format((float)$r[4],2) ?></td>
            </tr>
          <?php endforeach; ?>
        </table>

        <div class="rowpay">
          <div>
            <div style="color:#cfcfd4;font-size:13px;margin-bottom:6px;">Payment Method</div>
            <select name="payment_method" id="pm" required style="min-width:220px;">
              <?php foreach($pmList as $m): ?>
                <option value="<?= (int)$m['PaymentMethodID'] ?>"><?= htmlspecialchars($m['PaymentMethodName']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>

          <div>
            <div style="color:#cfcfd4;font-size:13px;margin-bottom:6px;">Amount</div>
            <input type="number" step="0.01" min="0" name="pay_amount" required style="width:160px;" value="<?= number_format((float)$total,2,'.','') ?>">
          </div>

          <div id="cardBox" style="display:none;">
            <div style="color:#cfcfd4;font-size:13px;margin-bottom:6px;">Card Number</div>
            <input type="text" name="card_number" maxlength="19" placeholder="xxxx xxxx xxxx xxxx" style="width:220px;">
          </div>

          <div id="onlineBox" style="display:none;">
            <div style="color:#cfcfd4;font-size:13px;margin-bottom:6px;">Transaction Ref</div>
            <input type="text" name="txn_ref" maxlength="60" placeholder="Reference ID" style="width:220px;">
          </div>

          <div>
            <div style="color:#cfcfd4;font-size:13px;margin-bottom:6px;">Status</div>
            <select name="payment_status" style="min-width:160px;">
              <option value="Paid">Paid</option>
              <option value="Pending">Pending</option>
            </select>
          </div>
        </div>

        <div style="display:flex;justify-content:space-between;align-items:center;margin-top:12px;gap:10px;flex-wrap:wrap;">
          <div style="font-weight:700;">Total: <?= number_format((float)$total,2) ?></div>
          <div style="display:flex;gap:10px;flex-wrap:wrap;">
            <button class="btn-lite" type="submit" name="update_cart" style="background:transparent;border:1px solid rgba(255,255,255,.12);">Update Cart</button>
            <button class="btn-lite" type="submit" name="clear_cart" style="background:transparent;border:1px solid rgba(255,255,255,.12);">Clear</button>
            <button type="submit" name="checkout">Checkout</button>
          </div>
        </div>
      </form>

      <script>
        (function(){
          const pm = document.getElementById('pm');
          const cardBox = document.getElementById('cardBox');
          const onlineBox = document.getElementById('onlineBox');

          function toggle(){
            const text = pm.options[pm.selectedIndex].text.toLowerCase();
            cardBox.style.display = text.includes('card') ? 'block' : 'none';
            onlineBox.style.display = text.includes('online') ? 'block' : 'none';
          }
          pm.addEventListener('change', toggle);
          toggle();
        })();
      </script>
    <?php endif; ?>
  </div>

</div>
</body>
</html>
