<?php
session_start();
require_once "DB.php";
//Allow access only for admins
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}
//Recaluculate parchase total depending on parchaseItem
function recalc_purchase_total($conn, $pid) {
  $statement=$conn->prepare("SELECT COALESCE(SUM(Cost * Quantity),0) AS total FROM PurchaseItem WHERE PurchaseID=?");
  $statement->bind_param("i", $pid);
  $statement->execute();
  $total = (float)($statement->get_result()->fetch_assoc()['total'] ?? 0);
  $up = $conn->prepare("UPDATE Purchase SET TotalAmount=? WHERE PurchaseID=?");
  $up->bind_param("di", $total, $pid);
  $up->execute();
}
//Get current status for a purchase (Pending/Received/Cancelled)
function get_purchase_status($conn, $pid) {
  $statement = $conn->prepare("SELECT PurchaseStatus FROM Purchase WHERE PurchaseID=? LIMIT 1");
  $statement->bind_param("i", $pid);
  $statement->execute();
  $row = $statement->get_result()->fetch_assoc();
  return $row ? $row['PurchaseStatus'] : null;
}
$warehousesRes=$databaseConnection->query("SELECT WarehouseID, WarehouseName FROM Warehouse ORDER BY WarehouseName");
$ingredientsRes=$databaseConnection->query("SELECT IngredientID, IngredientName FROM Ingredient ORDER BY IngredientName");

//Add new parchase
if (isset($_POST['add_purchase'])) {
  $supplierId  = (int)($_POST['supplier_id'] ?? 0);
  $warehouseId = (int)($_POST['warehouse_id'] ?? 0);
  $branchId    = (int)($_POST['branch_id'] ?? 0);
  $date        = $_POST['purchase_date'] ?? date('Y-m-d');
  $status      = trim($_POST['status'] ?? 'Pending');

  if ($supplierId > 0 && $warehouseId > 0 && $branchId > 0) {
    $statement=$databaseConnection->prepare(
      "INSERT INTO Purchase (supplierID, warehouseId, PurchaseDate, branchId, TotalAmount, PurchaseStatus)
       VALUES (?, ?, ?, ?, 0.00, ?)"
    );
    $statement->bind_param("iisis", $supplierId, $warehouseId, $date, $branchId, $status);
    $statement->execute();
  }

  header("Location: purchases.php");
  exit;
}

//Edit parchase
$editPurchase = null;
if (isset($_GET['edit'])) {
  $eid = (int)$_GET['edit'];
  if ($eid > 0) {
    $statement=$databaseConnection->prepare("SELECT * FROM Purchase WHERE PurchaseID=? LIMIT 1");
    $statement->bind_param("i", $eid);
    $statement->execute();
    $editPurchase=$statement->get_result()->fetch_assoc();
  }
}

//If status changes to Received automaticlly create stockmovement IN
if (isset($_POST['update_purchase'])) {
  $id=(int)($_POST['purchase_id'] ?? 0);
  $supplierId=(int)($_POST['supplier_id'] ?? 0);
  $warehouseId=(int)($_POST['warehouse_id'] ?? 0);
  $branchId=(int)($_POST['branch_id'] ?? 0);
  $date=$_POST['purchase_date'] ?? date('Y-m-d');
  $status=trim($_POST['status'] ?? 'Pending');
  if ($id > 0 && $supplierId > 0 && $warehouseId > 0 && $branchId > 0) {
    $oldStatus=get_purchase_status($databaseConnection, $id);

    $statement = $databaseConnection->prepare(
      "UPDATE Purchase
       SET supplierID=?, warehouseId=?, PurchaseDate=?, branchId=?, PurchaseStatus=?
       WHERE PurchaseID=?"
    );
    $statement->bind_param("iisisi", $supplierId, $warehouseId, $date, $branchId, $status, $id);
    $statement->execute();
    recalc_purchase_total($databaseConnection, $id);
    if ($oldStatus !== 'Received' && $status === 'Received') {
      $statement=$databaseConnection->prepare("SELECT warehouseId, PurchaseDate FROM Purchase WHERE PurchaseID=? LIMIT 1");
      $statement->bind_param("i", $id);
      $statement->execute();
      $p=$statement->get_result()->fetch_assoc();
      $wh = (int)($p['warehouseId'] ?? 0);
      $moveDate = $p['PurchaseDate'] ?? date('Y-m-d');
      if ($wh > 0) {
        $itemsStmt=$databaseConnection->prepare("SELECT IngredientID, Quantity FROM PurchaseItem WHERE PurchaseID=?");
        $itemsStmt->bind_param("i", $id);
        $itemsStmt->execute();
        $itemsRes=$itemsStmt->get_result();

        while ($it=$itemsRes->fetch_assoc()) {
          $ing=(int)$it['IngredientID'];
          $qty=(int)$it['Quantity'];
          if ($ing > 0 && $qty > 0) {
            $ins = $databaseConnection->prepare(
              "INSERT INTO StockMovement (WarehouseID, IngredientID, MovementType, MovementDate, Quantity)
               VALUES (?, ?, 'IN', ?, ?)"
            );
            $ins->bind_param("iisi", $wh, $ing, $moveDate, $qty);
            $ins->execute();
          }
        }
      }
      header("Location: purchases.php?msg=received&id=".(int)$id);
      exit;
    }
  }

  header("Location: purchases.php");
  exit;
}
//Delete purchase
if (isset($_POST['delete_purchase'])) {
  $id=(int)($_POST['purchase_id'] ?? 0);
  if ($id > 0) {
    $chk = $databaseConnection->prepare("SELECT COUNT(*) c FROM PurchaseItem WHERE PurchaseID=?");
    $chk->bind_param("i", $id);
    $chk->execute();
    $count = (int)($chk->get_result()->fetch_assoc()['c'] ?? 0);
    if ($count == 0) {
      $stmt = $databaseConnection->prepare("DELETE FROM Purchase WHERE PurchaseID=?");
      $stmt->bind_param("i", $id);
      $stmt->execute();
    } else {
      header("Location: purchases.php?msg=has_items");
      exit;
    }
  }

  header("Location: purchases.php");
  exit;
}
//Adding purchase item
if (isset($_POST['add_item']) || isset($_POST['update_item']) || isset($_POST['delete_item'])) {
  $pidLock = (int)($_POST['purchase_id'] ?? 0);
  if ($pidLock > 0) {
    $st = get_purchase_status($databaseConnection, $pidLock);
    if ($st === 'Received') {
      header("Location: purchases.php?pid=".$pidLock."&msg=locked");
      exit;
    }
  }
}
if (isset($_POST['add_item'])) {
  $pid=(int)($_POST['purchase_id'] ?? 0);
  $ing=(int)($_POST['ingredient_id'] ?? 0);
  $qty=(int)($_POST['quantity'] ?? 0);
  $cost=(float)($_POST['cost'] ?? 0);
  $exp=$_POST['expiry'] ?? null;
  if ($pid > 0 && $ing > 0 && $qty > 0) {
    $stmt = $databaseConnection->prepare(
      "INSERT INTO PurchaseItem (PurchaseID, IngredientID, Cost, Quantity, ExpiryDate)
       VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("iidis", $pid, $ing, $cost, $qty, $exp);
    $stmt->execute();

    recalc_purchase_total($databaseConnection, $pid);
  }
  header("Location: purchases.php?pid=".$pid);
  exit;
}
//Edit purchase item
$editItem = null;
if (isset($_GET['edit_item'])) {
  $pid=(int)($_GET['pid'] ?? 0);
  $ing=(int)($_GET['ing'] ?? 0);

  if ($pid > 0 && $ing > 0) {
    $stmt = $databaseConnection->prepare(
      "SELECT pi.*, i.IngredientName
       FROM PurchaseItem pi
       JOIN Ingredient i ON i.IngredientID=pi.IngredientID
       WHERE pi.PurchaseID=? AND pi.IngredientID=? LIMIT 1"
    );
    $stmt->bind_param("ii", $pid, $ing);
    $stmt->execute();
    $editItem = $stmt->get_result()->fetch_assoc();
  }
}
if (isset($_POST['update_item'])) {
  $pid=(int)($_POST['purchase_id'] ?? 0);
  $ing=(int)($_POST['ingredient_id'] ?? 0);
  $qty=(int)($_POST['quantity'] ?? 0);
  $cost=(float)($_POST['cost'] ?? 0);
  $exp=$_POST['expiry'] ?? null;
  if ($pid > 0 && $ing > 0 && $qty > 0) {
    $stmt = $databaseConnection->prepare(
      "UPDATE PurchaseItem
       SET Cost=?, Quantity=?, ExpiryDate=?
       WHERE PurchaseID=? AND IngredientID=?"
    );
    $stmt->bind_param("disii", $cost, $qty, $exp, $pid, $ing);
    $stmt->execute();

    recalc_purchase_total($databaseConnection, $pid);
  }

  header("Location: purchases.php?pid=".$pid);
  exit;
}

if (isset($_POST['delete_item'])) {
  $pid = (int)($_POST['purchase_id'] ?? 0);
  $ing = (int)($_POST['ingredient_id'] ?? 0);

  if ($pid > 0 && $ing > 0) {
    $stmt = $databaseConnection->prepare(
      "DELETE FROM PurchaseItem WHERE PurchaseID=? AND IngredientID=?"
    );
    $stmt->bind_param("ii", $pid, $ing);
    $stmt->execute();

    recalc_purchase_total($databaseConnection, $pid);
  }

  header("Location: purchases.php?pid=".$pid);
  exit;
}

$purchases = $databaseConnection->query(
  "SELECT p.*, s.SupplierName, w.WarehouseName, b.BranchName
   FROM Purchase p
   JOIN Supplier s ON s.SupplierID=p.supplierID
   JOIN Warehouse w ON w.WarehouseID=p.warehouseId
   JOIN Branch b ON b.BranchID=p.branchId
   ORDER BY p.PurchaseDate DESC, p.PurchaseID DESC"
);

$pidView = (int)($_GET['pid'] ?? 0);
$items = null;
$pidStatus = null;

if ($pidView > 0) {
  $pidStatus = get_purchase_status($databaseConnection, $pidView);

  $stmt = $databaseConnection->prepare(
    "SELECT pi.*, i.IngredientName
     FROM PurchaseItem pi
     JOIN Ingredient i ON i.IngredientID=pi.IngredientID
     WHERE pi.PurchaseID=?
     ORDER BY i.IngredientName"
  );
  $stmt->bind_param("i", $pidView);
  $stmt->execute();
  $items = $stmt->get_result();
}

$suppliers   = $databaseConnection->query("SELECT SupplierID, SupplierName FROM Supplier ORDER BY SupplierName");
$warehouses  = $databaseConnection->query("SELECT WarehouseID, WarehouseName FROM Warehouse ORDER BY WarehouseName");
$branches    = $databaseConnection->query("SELECT BranchID, BranchName FROM Branch ORDER BY BranchName");
$ingredients = $databaseConnection->query("SELECT IngredientID, IngredientName FROM Ingredient ORDER BY IngredientName");
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Admin | Purchases</title>
<style>
  body {
    font-family: Arial;
    background: #0b0b0d;
    color: #fff;
    margin: 0;
  }

  .wrap {
    width: 1100px;
    margin: 40px auto;
  }

  .top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
  }

  .box {
    background: #121216;
    padding: 20px;
    border-radius: 14px;
    margin-bottom: 18px;
    border: 1px solid rgba(255, 255, 255, 0.12);
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 10px;
  }

  th,
  td {
    padding: 10px;
    border-bottom: 1px solid #333;
    text-align: left;
  }

  th {
    color: #cfcfd4;
  }

  input,
  select,
  button {
    padding: 8px;
    border-radius: 8px;
    border: none;
    margin: 4px;
    outline: none;
  }

  input {
    width: 160px;
  }

  select {
    width: 220px;
  }

  button {
    cursor: pointer;
    background: #d71920;
    color: #fff;
    font-weight: 700;
  }

  .btn-lite {
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.12);
    color: #fff;
    padding: 8px 14px;
    border-radius: 10px;
    display: inline-block;
    text-decoration: none;
  }

  .danger {
    background: #ff4d4d;
  }

  .row-actions {
    display: flex;
    gap: 8px;
    align-items: center;
  }
</style>

</head>
<body>
<div class="wrap">

  <div class="top">
    <h1 style="margin:0;">Purchases</h1>
    <div style="display:flex;gap:10px;align-items:center;">
      <a class="btn-lite" href="admin.php">Go back to Dashboard</a>
      <a class="btn-lite" href="purchases.php">Refresh</a>
    </div>
  </div>

  <?php if (isset($_GET['msg']) && $_GET['msg']==='has_items'): ?>
    <div class="box" style="border-color:rgba(215,25,32,.35);background:rgba(215,25,32,.10);">
      Cannot delete this purchase because it has items linked to it.
    </div>
  <?php endif; ?>

  <?php if (isset($_GET['msg']) && $_GET['msg']==='received'): ?>
    <div class="box" style="border-color:rgba(0,200,120,.25);background:rgba(0,200,120,.10);">
      Purchase marked as Received. StockMovement (IN) has been created automatically.
    </div>
  <?php endif; ?>

  <?php if (isset($_GET['msg']) && $_GET['msg']==='locked'): ?>
    <div class="box" style="border-color:rgba(215,25,32,.35);background:rgba(215,25,32,.10);">
      This purchase is already Received, so items cannot be modified.
    </div>
  <?php endif; ?>

  <div class="box">
    <h3 style="margin:0 0 10px;"><?= $editPurchase ? "Edit Purchase #".(int)$editPurchase['PurchaseID'] : "Add New Purchase" ?></h3>
    <form method="post">
      <?php if ($editPurchase): ?>
        <input type="hidden" name="purchase_id" value="<?= (int)$editPurchase['PurchaseID'] ?>">
      <?php endif; ?>

      <select name="supplier_id" required>
        <option value="">Select Supplier</option>
        <?php while($s=$suppliers->fetch_assoc()): ?>
          <?php
            $sid = (int)$s['SupplierID'];
            $sel = ($editPurchase && (int)$editPurchase['supplierID'] === $sid) ? 'selected' : '';
          ?>
          <option value="<?= $sid ?>" <?= $sel ?>><?= htmlspecialchars($s['SupplierName']) ?></option>
        <?php endwhile; ?>
      </select>

      <select name="warehouse_id" required>
        <option value="">Select Warehouse</option>
        <?php while($w=$warehouses->fetch_assoc()): ?>
          <?php
            $wid = (int)$w['WarehouseID'];
            $sel = ($editPurchase && (int)$editPurchase['warehouseId'] === $wid) ? 'selected' : '';
          ?>
          <option value="<?= $wid ?>" <?= $sel ?>><?= htmlspecialchars($w['WarehouseName']) ?></option>
        <?php endwhile; ?>
      </select>

      <select name="branch_id" required>
        <option value="">Select Branch</option>
        <?php while($b=$branches->fetch_assoc()): ?>
          <?php
            $bid = (int)$b['BranchID'];
            $sel = ($editPurchase && (int)$editPurchase['branchId'] === $bid) ? 'selected' : '';
          ?>
          <option value="<?= $bid ?>" <?= $sel ?>><?= htmlspecialchars($b['BranchName']) ?></option>
        <?php endwhile; ?>
      </select>

      <input type="date" name="purchase_date" required value="<?= htmlspecialchars($editPurchase['PurchaseDate'] ?? date('Y-m-d')) ?>">

      <select name="status" required>
        <?php $cur = $editPurchase['PurchaseStatus'] ?? 'Pending'; ?>
        <option value="Pending"  <?= ($cur==='Pending') ? 'selected' : '' ?>>Pending</option>
        <option value="Received" <?= ($cur==='Received') ? 'selected' : '' ?>>Received</option>
        <option value="Cancelled"<?= ($cur==='Cancelled') ? 'selected' : '' ?>>Cancelled</option>
      </select>

      <?php if ($editPurchase): ?>
        <button type="submit" name="update_purchase">Update</button>
        <a class="btn-lite" href="purchases.php">Cancel</a>
      <?php else: ?>
        <button type="submit" name="add_purchase">Add Purchase</button>
      <?php endif; ?>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Purchases List</h3>
    <table>
      <tr>
        <th>ID</th><th>Date</th><th>Supplier</th><th>Warehouse</th><th>Branch</th><th>Status</th><th>Total</th><th>Action</th>
      </tr>
      <?php while($p=$purchases->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$p['PurchaseID'] ?></td>
          <td><?= htmlspecialchars($p['PurchaseDate']) ?></td>
          <td><?= htmlspecialchars($p['SupplierName']) ?></td>
          <td><?= htmlspecialchars($p['WarehouseName']) ?></td>
          <td><?= htmlspecialchars($p['BranchName']) ?></td>
          <td><?= htmlspecialchars($p['PurchaseStatus']) ?></td>
          <td><?= htmlspecialchars($p['TotalAmount']) ?></td>
          <td class="row-actions">
            <a class="btn-lite" href="purchases.php?pid=<?= (int)$p['PurchaseID'] ?>">Items</a>
            <a class="btn-lite" href="purchases.php?edit=<?= (int)$p['PurchaseID'] ?>">Edit</a>
            <form method="post" onsubmit="return confirm('Delete this purchase?');" style="margin:0;">
              <input type="hidden" name="purchase_id" value="<?= (int)$p['PurchaseID'] ?>">
              <button class="danger" type="submit" name="delete_purchase">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

  <?php if ($pidView > 0): ?>
    <div class="box">
      <div style="display:flex;justify-content:space-between;align-items:center;">
        <h3 style="margin:0;">Purchase Items (Purchase #<?= (int)$pidView ?>)</h3>
        <a class="btn-lite" href="purchases.php">Close Items</a>
      </div>

      <?php if ($pidStatus === 'Received'): ?>
        <div class="box" style="margin-top:12px;border-color:rgba(215,25,32,.35);background:rgba(215,25,32,.10);">
          This purchase is Received. Items are locked (no add/edit/delete).
        </div>
      <?php endif; ?>

      <div style="margin-top:12px;">
        <h4 style="margin:0 0 8px; font-size:14px; color:#cfcfd4;">
          <?= $editItem ? "Edit Item: ".htmlspecialchars($editItem['IngredientName']) : "Add Item" ?>
        </h4>

        <form method="post">
          <input type="hidden" name="purchase_id" value="<?= (int)$pidView ?>">

          <?php if ($editItem): ?>
            <input type="hidden" name="ingredient_id" value="<?= (int)$editItem['IngredientID'] ?>">
            <input value="<?= htmlspecialchars($editItem['IngredientName']) ?>" disabled>
          <?php else: ?>
            <select name="ingredient_id" required <?= ($pidStatus==='Received') ? 'disabled' : '' ?>>
              <option value="">Select Ingredient</option>
              <?php while($i=$ingredients->fetch_assoc()): ?>
                <option value="<?= (int)$i['IngredientID'] ?>"><?= htmlspecialchars($i['IngredientName']) ?></option>
              <?php endwhile; ?>
            </select>
          <?php endif; ?>

          <input type="number" name="quantity" placeholder="Qty" min="1" required value="<?= $editItem ? (int)$editItem['Quantity'] : '' ?>" <?= ($pidStatus==='Received') ? 'disabled' : '' ?>>
          <input type="number" step="0.01" name="cost" placeholder="Cost" required value="<?= $editItem ? htmlspecialchars($editItem['Cost']) : '' ?>" <?= ($pidStatus==='Received') ? 'disabled' : '' ?>>
          <input type="date" name="expiry" required value="<?= $editItem ? htmlspecialchars($editItem['ExpiryDate']) : date('Y-m-d') ?>" <?= ($pidStatus==='Received') ? 'disabled' : '' ?>>

          <?php if ($pidStatus !== 'Received'): ?>
            <?php if ($editItem): ?>
              <button name="update_item">Update Item</button>
              <a class="btn-lite" href="purchases.php?pid=<?= (int)$pidView ?>">Cancel</a>
            <?php else: ?>
              <button name="add_item">Add Item</button>
            <?php endif; ?>
          <?php endif; ?>
        </form>
      </div>

      <table>
        <tr>
          <th>Ingredient</th><th>Qty</th><th>Cost</th><th>Expiry</th><th>Action</th>
        </tr>

        <?php while($it=$items->fetch_assoc()): ?>
          <tr>
            <td><?= htmlspecialchars($it['IngredientName']) ?></td>
            <td><?= (int)$it['Quantity'] ?></td>
            <td><?= htmlspecialchars($it['Cost']) ?></td>
            <td><?= htmlspecialchars($it['ExpiryDate']) ?></td>
            <td class="row-actions">
              <?php if ($pidStatus !== 'Received'): ?>
                <a class="btn-lite" href="purchases.php?pid=<?= (int)$pidView ?>&edit_item=1&ing=<?= (int)$it['IngredientID'] ?>">Edit</a>
                <form method="post" style="margin:0;" onsubmit="return confirm('Delete this item?');">
                  <input type="hidden" name="purchase_id" value="<?= (int)$pidView ?>">
                  <input type="hidden" name="ingredient_id" value="<?= (int)$it['IngredientID'] ?>">
                  <button class="danger" name="delete_item">Delete</button>
                </form>
              <?php else: ?>
                <span style="color:#cfcfd4;">Locked</span>
              <?php endif; ?>
            </td>
          </tr>
        <?php endwhile; ?>
      </table>

      <div style="margin-top:14px;">
        <a class="btn-lite" href="admin.php">Go back to Dashboard</a>
      </div>
    </div>
  <?php endif; ?>

</div>
</body>
</html>
