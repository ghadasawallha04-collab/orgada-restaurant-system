<?php
session_start();
session_destroy(); //Logout
header("Location: index.php"); //Go back to home page after logout
exit;
