<?php
session_start();
require_once "DB.php";
//Allow admin access only
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}
//Add new menu Item
if (isset($_POST['add_item'])) {
  $name = trim($_POST['item_name'] ?? '');
  $cat  = (int)($_POST['category_id'] ?? 0);
  $rec  = (int)($_POST['recipe_id'] ?? 0);
  $price= (float)($_POST['price'] ?? 0);
  $avail= isset($_POST['is_available']) ? 1 : 0;

  if ($name !== '' && $cat > 0 && $rec > 0) {
    $stmt = $databaseConnection->prepare(
      "INSERT INTO MenuItem (CategoryID, recipeID, MenuItemName, price, IsAvailable)
       VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("iisdi", $cat, $rec, $name, $price, $avail);
    $stmt->execute();
  }

  header("Location: menuitem.php");
  exit;
}
//Delete existing menu item
if (isset($_POST['delete_item'])) {
  $id=(int)($_POST['menuitem_id'] ?? 0);
  if ($id > 0) {
    $chk=$databaseConnection->prepare("SELECT COUNT(*) c FROM OrderItem WHERE MenuItemID=?");
    $chk->bind_param("i", $id);
    $chk->execute();
    $c=(int)($chk->get_result()->fetch_assoc()['c'] ?? 0);
    if ($c > 0) {
      header("Location: menuitem.php?msg=used");
      exit;
    }
    $statement = $databaseConnection->prepare("DELETE FROM MenuItem WHERE MenuItemID=?");
    $statement->bind_param("i", $id);
    $statement->execute();
  }
  header("Location: menuitem.php");
  exit;
}

//Edit menu Item
$editRow = null;
if (isset($_GET['edit'])) {
  $id = (int)$_GET['edit'];
  if ($id > 0) {
    $statement=$databaseConnection->prepare("SELECT * FROM MenuItem WHERE MenuItemID=? LIMIT 1");
    $statement->bind_param("i", $id);
    $statement->execute();
    $editRow=$statement->get_result()->fetch_assoc();
  }
}
if (isset($_POST['update_item'])) {
  $id=(int)($_POST['menuitem_id'] ?? 0);
  $name=trim($_POST['item_name'] ?? '');
  $cat=(int)($_POST['category_id'] ?? 0);
  $rec=(int)($_POST['recipe_id'] ?? 0);
  $price=(float)($_POST['price'] ?? 0);
  $avail=isset($_POST['is_available']) ? 1 : 0;
  if ($id > 0 && $name !== '' && $cat > 0 && $rec > 0) {
    $statement=$databaseConnection->prepare(
      "UPDATE MenuItem
       SET CategoryID=?, recipeID=?, MenuItemName=?, price=?, IsAvailable=?
       WHERE MenuItemID=?"
    );
    $statement->bind_param("iisdis", $cat, $rec, $name, $price, $avail, $id);
    $statement->close();

    $statement=$databaseConnection->prepare(
      "UPDATE MenuItem
       SET CategoryID=?, recipeID=?, MenuItemName=?, price=?, IsAvailable=?
       WHERE MenuItemID=?"
    );
    $statement->bind_param("iisdii", $cat, $rec, $name, $price, $avail, $id);
    $statement->execute();
  }
  header("Location: menuitem.php");
  exit;
}

//Filter by category
$catFilter=trim($_GET['category_id'] ?? '');
$catsRes=$databaseConnection->query("SELECT CategoryID, CategoryName FROM Category ORDER BY CategoryName");
$recipesRes=$databaseConnection->query("SELECT RecipeID, RecipeName FROM Recipe ORDER BY RecipeName");
if ($catFilter !== '') {
  $statement=$databaseConnection->prepare(
    "SELECT m.*, c.CategoryName, r.RecipeName
     FROM MenuItem m
     JOIN Category c ON c.CategoryID=m.CategoryID
     JOIN Recipe r ON r.RecipeID=m.recipeID
     WHERE m.CategoryID=?
     ORDER BY m.MenuItemID DESC"
  );
  $statement->bind_param("i", $catFilter);
  $statement->execute();
  $items=$statement->get_result();
} else {
  $items = $databaseConnection->query(
    "SELECT m.*, c.CategoryName, r.RecipeName
     FROM MenuItem m
     JOIN Category c ON c.CategoryID=m.CategoryID
     JOIN Recipe r ON r.RecipeID=m.recipeID
     ORDER BY m.MenuItemID DESC"
  );
}
?>
<!--HTML&CSS Codes-->
<!doctype html>
<html>
<head>
  <title>Admin | Menu Items</title>
<style>
  body {
    font-family: Arial;
    background: #0b0b0d;
    color: #fff;
    margin: 0;
  }

  .wrap {
    width: 1100px;
    margin: 40px auto;
  }

  .top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
  }

  .box {
    background: #121216;
    padding: 20px;
    border-radius: 14px;
    margin-bottom: 18px;
    border: 1px solid rgba(255, 255, 255, 0.12);
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 14px;
  }

  th,
  td {
    padding: 10px;
    border-bottom: 1px solid #333;
    text-align: left;
  }

  th {
    color: #cfcfd4;
  }

  input,
  select,
  button {
    padding: 8px;
    border-radius: 8px;
    border: none;
    margin: 4px;
    outline: none;
  }

  input {
    width: 210px;
  }

  select {
    width: 230px;
  }

  button {
    cursor: pointer;
    background: #d71920;
    color: #fff;
    font-weight: 700;
  }

  .btn-lite {
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.12);
    color: #fff;
    display: inline-block;
    padding: 8px 14px;
    border-radius: 10px;
  }

  .danger {
    background: #ff4d4d;
  }

  .row-actions {
    display: flex;
    gap: 8px;
    align-items: center;
  }

  .chip {
    padding: 4px 10px;
    border-radius: 999px;
    border: 1px solid rgba(255, 255, 255, 0.12);
    font-size: 12px;
  }
</style>
</head>
<body>
<div class="wrap">

  <div class="top">
    <h1 style="margin:0;">Menu Items</h1>
    <div style="display:flex;gap:10px;align-items:center;">
      <a href="categories.php" class="btn-lite">Categories</a>
      <a href="recipes.php" class="btn-lite">Recipes</a>
      <a href="admin.php" class="btn-lite">← Back to Dashboard</a>
    </div>
  </div>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'used'): ?>
    <div class="box" style="border-color:rgba(215,25,32,.35);background:rgba(215,25,32,.10);">
      This menu item cannot be deleted because it is used in Orders.
    </div>
  <?php endif; ?>

  <div class="box">
    <h3 style="margin:0 0 10px;"><?= $editRow ? "Edit Menu Item" : "Add New Menu Item" ?></h3>
    <form method="post">
      <?php if ($editRow): ?>
        <input type="hidden" name="menuitem_id" value="<?= (int)$editRow['MenuItemID'] ?>">
      <?php endif; ?>

      <input name="item_name" placeholder="Menu Item Name" required value="<?= htmlspecialchars($editRow['MenuItemName'] ?? '') ?>">
      <input type="number" step="0.01" name="price" placeholder="Price" value="<?= htmlspecialchars($editRow['price'] ?? 0) ?>">

      <select name="category_id" required>
        <option value="">Select Category</option>
        <?php
          $catsAgain = $databaseConnection->query("SELECT CategoryID, CategoryName FROM Category ORDER BY CategoryName");
          while($c = $catsAgain->fetch_assoc()):
            $cid = (int)$c['CategoryID'];
            $sel = ($editRow && (int)$editRow['CategoryID'] === $cid) ? 'selected' : '';
        ?>
          <option value="<?= $cid ?>" <?= $sel ?>><?= htmlspecialchars($c['CategoryName']) ?></option>
        <?php endwhile; ?>
      </select>

      <select name="recipe_id" required>
        <option value="">Select Recipe</option>
        <?php
          $recAgain = $databaseConnection->query("SELECT RecipeID, RecipeName FROM Recipe ORDER BY RecipeName");
          while($r = $recAgain->fetch_assoc()):
            $rid = (int)$r['RecipeID'];
            $sel = ($editRow && (int)$editRow['recipeID'] === $rid) ? 'selected' : '';
        ?>
          <option value="<?= $rid ?>" <?= $sel ?>><?= htmlspecialchars($r['RecipeName']) ?></option>
        <?php endwhile; ?>
      </select>

      <label style="display:inline-flex;align-items:center;gap:8px;margin-left:8px;">
        <input type="checkbox" name="is_available" <?= ($editRow && (int)$editRow['IsAvailable'] === 1) ? 'checked' : '' ?> <?= (!$editRow ? 'checked' : '') ?>>
        Available
      </label>

      <?php if ($editRow): ?>
        <button type="submit" name="update_item">Update</button>
        <a class="btn-lite" href="menuitem.php" style="padding:8px 12px;">Cancel</a>
      <?php else: ?>
        <button type="submit" name="add_item">Add</button>
      <?php endif; ?>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Filter by Category</h3>
    <form method="get">
      <select name="category_id">
        <option value="">All Categories</option>
        <?php
          $catsFilter = $databaseConnection->query("SELECT CategoryID, CategoryName FROM Category ORDER BY CategoryName");
          while($c = $catsFilter->fetch_assoc()):
            $cid = (int)$c['CategoryID'];
            $sel = ((string)$catFilter === (string)$cid) ? 'selected' : '';
        ?>
          <option value="<?= $cid ?>" <?= $sel ?>><?= htmlspecialchars($c['CategoryName']) ?></option>
        <?php endwhile; ?>
      </select>
      <button type="submit">Search</button>
      <a class="btn-lite" href="menuitem.php" style="padding:8px 12px;">Reset</a>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Menu Items List</h3>
    <table>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Category</th>
        <th>Recipe</th>
        <th>Price</th>
        <th>Status</th>
        <th>Action</th>
      </tr>

      <?php while($row = $items->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['MenuItemID'] ?></td>
          <td><?= htmlspecialchars($row['MenuItemName']) ?></td>
          <td><?= htmlspecialchars($row['CategoryName']) ?></td>
          <td><?= htmlspecialchars($row['RecipeName']) ?></td>
          <td><?= htmlspecialchars($row['price']) ?></td>
          <td>
            <?php if ((int)$row['IsAvailable'] === 1): ?>
              <span class="chip">Available</span>
            <?php else: ?>
              <span class="chip" style="opacity:.7;">Not Available</span>
            <?php endif; ?>
          </td>
          <td class="row-actions">
            <a class="btn-lite" href="menuitem.php?edit=<?= (int)$row['MenuItemID'] ?>">Edit</a>

            <form method="post" onsubmit="return confirm('Delete this menu item?');" style="margin:0;">
              <input type="hidden" name="menuitem_id" value="<?= (int)$row['MenuItemID'] ?>">
              <button class="danger" type="submit" name="delete_item">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

</div>
</body>
</html>
