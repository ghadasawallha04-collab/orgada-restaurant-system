<?php
session_start();
require_once "DB.php";
//Allow admin user only
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}
$rid=(int)($_GET['rid'] ?? 0);
//Add ingredient to recipe
if (isset($_POST['add_link'])) {
  $recipeId=(int)($_POST['recipe_id'] ?? 0);
  $ingId=(int)($_POST['ingredient_id'] ?? 0);
  $qty=(float)($_POST['quantity'] ?? 0);
  if ($recipeId > 0 && $ingId > 0 && $qty > 0) {
    $statement=$databaseConnection->prepare(
      "INSERT INTO RecipeIngredient (IngredientID, RecipeID, Quantity) VALUES (?, ?, ?)"
    );
    $statement->bind_param("iid", $ingId, $recipeId, $qty);
    $statement->execute();
  }
  header("Location: recipeingredients.php?rid=".$recipeId);
  exit;
}
//Delete ingredient from recipe
if (isset($_POST['delete_link'])) {
  $recipeId=(int)($_POST['recipe_id'] ?? 0);
  $ingId=(int)($_POST['ingredient_id'] ?? 0);
  if ($recipeId > 0 && $ingId > 0) {
    $statement=$databaseConnection->prepare(
      "DELETE FROM RecipeIngredient WHERE RecipeID=? AND IngredientID=?"
    );
    $statement->bind_param("ii", $recipeId, $ingId);
    $statement->execute();
  }
  header("Location: recipeingredients.php?rid=".$recipeId);
  exit;
}
//Edit ingredient
$editRow = null;
if (isset($_GET['edit'])) {
  $recipeId=(int)($_GET['rid'] ?? 0);
  $ingId=(int)($_GET['ing'] ?? 0);
  if ($recipeId > 0 && $ingId > 0) {
    $stmt = $databaseConnection->prepare(
      "SELECT ri.*, r.RecipeName, i.IngredientName
       FROM RecipeIngredient ri
       JOIN Recipe r ON r.RecipeID=ri.RecipeID
       JOIN Ingredient i ON i.IngredientID=ri.IngredientID
       WHERE ri.RecipeID=? AND ri.IngredientID=? LIMIT 1"
    );
    $stmt->bind_param("ii", $recipeId, $ingId);
    $stmt->execute();
    $editRow = $stmt->get_result()->fetch_assoc();
  }
}

if (isset($_POST['update_link'])) {
  $recipeId=(int)($_POST['recipe_id'] ?? 0);
  $ingId=(int)($_POST['ingredient_id'] ?? 0);
  $qty=(float)($_POST['quantity'] ?? 0);
  if ($recipeId > 0 && $ingId > 0 && $qty > 0) {
    $stmt = $databaseConnection->prepare(
      "UPDATE RecipeIngredient SET Quantity=? WHERE RecipeID=? AND IngredientID=?"
    );
    $stmt->bind_param("dii", $qty, $recipeId, $ingId);
    $stmt->execute();
  }
  header("Location: recipeingredients.php?rid=".$recipeId);
  exit;
}

$recipesRes=$databaseConnection->query(
  "SELECT RecipeID, RecipeName FROM Recipe ORDER BY RecipeName"
);
$ingredientsRes=$databaseConnection->query(
  "SELECT IngredientID, IngredientName, Unit FROM Ingredient ORDER BY IngredientName"
);

if ($rid > 0) {
  $stmt = $databaseConnection->prepare(
    "SELECT ri.Quantity, i.IngredientID, i.IngredientName, i.Unit, r.RecipeID, r.RecipeName
     FROM RecipeIngredient ri
     JOIN Ingredient i ON i.IngredientID=ri.IngredientID
     JOIN Recipe r ON r.RecipeID=ri.RecipeID
     WHERE r.RecipeID=?
     ORDER BY i.IngredientName"
  );
  $stmt->bind_param("i", $rid);
  $stmt->execute();
  $links=$stmt->get_result();
} 
else {
  $links=$databaseConnection->query(
    "SELECT ri.Quantity, i.IngredientID, i.IngredientName, i.Unit, r.RecipeID, r.RecipeName
     FROM RecipeIngredient ri
     JOIN Ingredient i ON i.IngredientID=ri.IngredientID
     JOIN Recipe r ON r.RecipeID=ri.RecipeID
     ORDER BY r.RecipeName, i.IngredientName"
  );
}
?>
<!--HTML&CSS Codes-->
<!doctype html>
<html>
<head>
  <title>Admin | Recipe Ingredients</title>
 <style>
  body {
    font-family: Arial;
    background: #0b0b0d;
    color: #fff;
    margin: 0;
  }

  .wrap {
    width: 1100px;
    margin: 40px auto;
  }

  .top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
  }

  .box {
    background: #121216;
    padding: 20px;
    border-radius: 14px;
    margin-bottom: 18px;
    border: 1px solid rgba(255, 255, 255, 0.12);
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 14px;
  }

  th,
  td {
    padding: 10px;
    border-bottom: 1px solid #333;
    text-align: left;
  }

  th {
    color: #cfcfd4;
  }

  input,
  select,
  button {
    padding: 8px;
    border-radius: 8px;
    border: none;
    margin: 4px;
    outline: none;
  }

  input {
    width: 160px;
  }

  select {
    width: 260px;
  }

  button {
    cursor: pointer;
    background: #d71920;
    color: #fff;
    font-weight: 700;
  }

  .btn-lite {
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.12);
    color: #fff;
    display: inline-block;
    padding: 8px 14px;
    border-radius: 10px;
  }

  .danger {
    background: #ff4d4d;
  }

  .row-actions {
    display: flex;
    gap: 8px;
    align-items: center;
  }
</style>
</head>
<body>
<div class="wrap">

  <div class="top">
    <h1 style="margin:0;">Recipe Ingredients</h1>
    <div style="display:flex;gap:10px;align-items:center;">
      <a href="recipes.php" class="btn-lite">Recipes</a>
      <a href="admin.php" class="btn-lite">← Back to Dashboard</a>
    </div>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;"><?= $editRow ? "Edit Link" : "Add Ingredient to Recipe" ?></h3>

    <form method="post">
      <?php if ($editRow): ?>
        <input type="hidden" name="recipe_id" value="<?= (int)$editRow['RecipeID'] ?>">
        <input type="hidden" name="ingredient_id" value="<?= (int)$editRow['IngredientID'] ?>">

        <input value="<?= htmlspecialchars($editRow['RecipeName']) ?>" disabled>
        <input value="<?= htmlspecialchars($editRow['IngredientName']) ?>" disabled>

        <input type="number" step="0.01" name="quantity" required value="<?= htmlspecialchars($editRow['Quantity']) ?>">
        <button type="submit" name="update_link">Update</button>
        <a class="btn-lite" href="recipeingredients.php?rid=<?= (int)$editRow['RecipeID'] ?>" style="padding:8px 12px;">Cancel</a>
      <?php else: ?>
        <select name="recipe_id" required>
          <option value="">Select Recipe</option>
          <?php while($r = $recipesRes->fetch_assoc()): ?>
            <?php
              $val = (int)$r['RecipeID'];
              $sel = ($rid > 0 && $rid === $val) ? 'selected' : '';
            ?>
            <option value="<?= $val ?>" <?= $sel ?>><?= htmlspecialchars($r['RecipeName']) ?></option>
          <?php endwhile; ?>
        </select>

        <select name="ingredient_id" required>
          <option value="">Select Ingredient</option>
          <?php while($i = $ingredientsRes->fetch_assoc()): ?>
            <option value="<?= (int)$i['IngredientID'] ?>">
              <?= htmlspecialchars($i['IngredientName']) ?> (<?= htmlspecialchars($i['Unit']) ?>)
            </option>
          <?php endwhile; ?>
        </select>

        <input type="number" step="0.01" name="quantity" required>
        <button type="submit" name="add_link">Add</button>
      <?php endif; ?>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Links List <?= ($rid>0 ? "(Recipe #".$rid.")" : "") ?></h3>

    <form method="get" style="margin-bottom:10px;">
      <select name="rid">
        <option value="">All Recipes</option>
        <?php
          $r2 = $databaseConnection->query("SELECT RecipeID, RecipeName FROM Recipe ORDER BY RecipeName");
          while($rr = $r2->fetch_assoc()):
            $val = (int)$rr['RecipeID'];
            $sel = ($rid === $val) ? 'selected' : '';
        ?>
          <option value="<?= $val ?>" <?= $sel ?>><?= htmlspecialchars($rr['RecipeName']) ?></option>
        <?php endwhile; ?>
      </select>
      <button type="submit">Filter</button>
      <a class="btn-lite" href="recipeingredients.php" style="padding:8px 12px;">Reset</a>
    </form>

    <table>
      <tr>
        <th>Recipe</th>
        <th>Ingredient</th>
        <th>Unit</th>
        <th>Quantity</th>
        <th>Action</th>
      </tr>

      <?php while($row = $links->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($row['RecipeName']) ?></td>
          <td><?= htmlspecialchars($row['IngredientName']) ?></td>
          <td><?= htmlspecialchars($row['Unit']) ?></td>
          <td><?= htmlspecialchars($row['Quantity']) ?></td>
          <td class="row-actions">
            <a class="btn-lite" href="recipeingredients.php?rid=<?= (int)$row['RecipeID'] ?>&edit=1&ing=<?= (int)$row['IngredientID'] ?>">Edit</a>

            <form method="post" onsubmit="return confirm('Delete this link?');" style="margin:0;">
              <input type="hidden" name="recipe_id" value="<?= (int)$row['RecipeID'] ?>">
              <input type="hidden" name="ingredient_id" value="<?= (int)$row['IngredientID'] ?>">
              <button class="danger" type="submit" name="delete_link">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>

  </div>

</div>
</body>
</html>
