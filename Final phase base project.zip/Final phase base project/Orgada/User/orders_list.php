<?php
require_once __DIR__ . "/../includes/guard_user.php";
require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/helpers.php";
include __DIR__ . "/../includes/header.php";

$rows = $pdo->query("
  SELECT o.OrderID, o.OrderDate, o.OrderType,
         c.FirstName, c.LastName, c.Phone,
         COALESCE(SUM(oi.Quantity * oi.Price),0) AS TotalComputed
  FROM `Order` o
  JOIN Customer c ON o.CustomerID=c.CustomerID
  LEFT JOIN OrderItem oi ON oi.OrderID=o.OrderID
  GROUP BY o.OrderID, o.OrderDate, o.OrderType, c.FirstName, c.LastName, c.Phone
  ORDER BY o.OrderID DESC
  LIMIT 50
")->fetchAll();
?>
<div class="card">
  <h2>Latest Orders</h2>
  <table>
    <thead><tr><th>ID</th><th>Date</th><th>Customer</th><th>Type</th><th>Total</th><th></th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
      <tr>
        <td><?=h($r['OrderID'])?></td>
        <td><?=h($r['OrderDate'])?></td>
        <td><?=h($r['FirstName']." ".$r['LastName'])?> (<?=h($r['Phone'])?>)</td>
        <td><?=h($r['OrderType'])?></td>
        <td><?=number_format((float)$r['TotalComputed'],2)?></td>
        <td><a href="/app/user/order_view.php?OrderID=<?=h($r['OrderID'])?>">View</a></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../includes/footer.php"; ?>
