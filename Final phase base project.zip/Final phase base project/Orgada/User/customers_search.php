<?php
require_once __DIR__ . "/../includes/guard_user.php";
require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/helpers.php";
include __DIR__ . "/../includes/header.php";

$q = trim($_GET['q'] ?? "");
if ($q !== "") {
  $like = "%$q%";
  $st = $pdo->prepare("SELECT * FROM Customer
                       WHERE Phone LIKE ? OR FirstName LIKE ? OR LastName LIKE ?
                       ORDER BY CustomerID DESC");
  $st->execute([$like,$like,$like]);
  $rows = $st->fetchAll();
} else {
  $rows = $pdo->query("SELECT * FROM Customer ORDER BY CustomerID DESC LIMIT 20")->fetchAll();
}
?>
<div class="card">
  <h2>Customers</h2>
  <p class="small"><a href="/app/user/customers_add.php">+ Add Customer</a></p>

  <form method="get">
    <label>Search (phone / name)</label>
    <input name="q" value="<?=h($q)?>" placeholder="059... or Ahmad">
    <button type="submit">Search</button>
  </form>

  <table>
    <thead><tr><th>ID</th><th>Name</th><th>Phone</th><th>Address</th><th></th></tr></thead>
    <tbody>
      <?php foreach($rows as $r): ?>
        <tr>
          <td><?=h($r['CustomerID'])?></td>
          <td><?=h($r['FirstName']." ".$r['LastName'])?></td>
          <td><?=h($r['Phone'])?></td>
          <td><?=h($r['Address'])?></td>
          <td><a href="/app/user/order_create.php?CustomerID=<?=h($r['CustomerID'])?>">Create Order</a></td>
        </tr>
      <?php endforeach; ?>
    </tbody>
  </table>
</div>
<?php include __DIR__ . "/../includes/footer.php"; ?>
