<?php
require_once __DIR__ . "/../includes/guard_user.php";
require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/helpers.php";
include __DIR__ . "/../includes/header.php";

$prefCustomer = (int)($_GET['CustomerID'] ?? 0);

$customers = $pdo->query("SELECT CustomerID, FirstName, LastName, Phone
                          FROM Customer ORDER BY CustomerID DESC LIMIT 60")->fetchAll();
$payments  = $pdo->query("SELECT PaymentMethodID, MethodName FROM PaymentMethod ORDER BY MethodName")->fetchAll();
$deliveries= $pdo->query("SELECT DeliveryCompanyID, CompanyName FROM DeliveryCompany ORDER BY CompanyName")->fetchAll();

$err = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $CustomerID = (int)($_POST['CustomerID'] ?? 0);
  $OrderType  = $_POST['OrderType'] ?? "";
  $PaymentMethodID = (int)($_POST['PaymentMethodID'] ?? 0);
  $DeliveryCompanyID = $_POST['DeliveryCompanyID'] ?? null;

  if (!in_array($OrderType, ['dine-in','takeaway','delivery'], true)) $err = "Invalid order type.";
  elseif ($CustomerID <= 0 || $PaymentMethodID <= 0) $err = "Customer and payment are required.";
  elseif ($OrderType === 'delivery' && ((int)$DeliveryCompanyID <= 0)) $err = "Delivery company required.";
  else {
    if ($OrderType !== 'delivery') $DeliveryCompanyID = null;

    // Optional from session (recommended)
    $EmployeeID = $_SESSION['user']['EmployeeID'] ?? null;
    $BranchID   = $_SESSION['user']['BranchID'] ?? null;

    $st = $pdo->prepare("INSERT INTO `Order` (OrderType, CustomerID, PaymentMethodID, DeliveryCompanyID, EmployeeID, BranchID)
                         VALUES (?,?,?,?,?,?)");
    $st->execute([$OrderType,$CustomerID,$PaymentMethodID,$DeliveryCompanyID,$EmployeeID,$BranchID]);

    $OrderID = (int)$pdo->lastInsertId();
    header("Location: /app/user/order_items.php?OrderID=".$OrderID);
    exit;
  }
}
?>
<div class="card">
  <h2>Create Order</h2>
  <?php if($err) echo "<div class='err'>".h($err)."</div>"; ?>

  <form method="post">
    <label>Customer</label>
    <select name="CustomerID" required>
      <option value="">-- Select --</option>
      <?php foreach($customers as $c): ?>
        <option value="<?=h($c['CustomerID'])?>" <?=($prefCustomer===(int)$c['CustomerID']?'selected':'')?>>
          <?=h($c['FirstName']." ".$c['LastName']." - ".$c['Phone'])?>
        </option>
      <?php endforeach; ?>
    </select>

    <label>Order Type</label>
    <select name="OrderType" id="OrderType" required>
      <option value="dine-in">Dine-in</option>
      <option value="takeaway">Takeaway</option>
      <option value="delivery">Delivery</option>
    </select>

    <label>Payment Method</label>
    <select name="PaymentMethodID" required>
      <option value="">-- Select --</option>
      <?php foreach($payments as $p): ?>
        <option value="<?=h($p['PaymentMethodID'])?>"><?=h($p['MethodName'])?></option>
      <?php endforeach; ?>
    </select>

    <div id="deliveryBlock" style="display:none;">
      <label>Delivery Company</label>
      <select name="DeliveryCompanyID">
        <option value="0">-- Select --</option>
        <?php foreach($deliveries as $d): ?>
          <option value="<?=h($d['DeliveryCompanyID'])?>"><?=h($d['CompanyName'])?></option>
        <?php endforeach; ?>
      </select>
    </div>

    <button type="submit">Next: Add Items</button>
  </form>
</div>

<script>
const t = document.getElementById('OrderType');
const b = document.getElementById('deliveryBlock');
function toggle(){ b.style.display = (t.value === 'delivery') ? 'block' : 'none'; }
t.addEventListener('change', toggle); toggle();
</script>

<?php include __DIR__ . "/../includes/footer.php"; ?>
