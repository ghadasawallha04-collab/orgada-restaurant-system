<?php
require_once __DIR__ . "/../includes/guard_user.php";
require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/helpers.php";
include __DIR__ . "/../includes/header.php";

$err = $ok = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $first = trim($_POST['FirstName'] ?? "");
  $last  = trim($_POST['LastName'] ?? "");
  $phone = trim($_POST['Phone'] ?? "");
  $addr  = trim($_POST['Address'] ?? "");

  if ($first === "" || $last === "" || $phone === "") $err = "First, last name and phone are required.";
  elseif (!valid_phone($phone)) $err = "Invalid phone format.";
  else {
    try {
      $st = $pdo->prepare("INSERT INTO Customer (FirstName, LastName, Phone, Address) VALUES (?,?,?,?)");
      $st->execute([$first,$last,$phone,$addr]);
      $ok = "Customer added.";
    } catch (PDOException $e) {
      $err = str_contains($e->getMessage(),"Duplicate") ? "Phone already exists." : $e->getMessage();
    }
  }
}
?>
<div class="card">
  <h2>Add Customer</h2>
  <?php if($err) echo "<div class='err'>".h($err)."</div>"; ?>
  <?php if($ok)  echo "<div class='ok'>".h($ok)."</div>"; ?>

  <form method="post">
    <div class="row">
      <div>
        <label>First Name</label>
        <input name="FirstName" required value="<?=h($_POST['FirstName'] ?? '')?>">
      </div>
      <div>
        <label>Last Name</label>
        <input name="LastName" required value="<?=h($_POST['LastName'] ?? '')?>">
      </div>
    </div>

    <label>Phone</label>
    <input name="Phone" required value="<?=h($_POST['Phone'] ?? '')?>">

    <label>Address</label>
    <input name="Address" value="<?=h($_POST['Address'] ?? '')?>">

    <button type="submit">Save</button>
  </form>
</div>
<?php include __DIR__ . "/../includes/footer.php"; ?>
