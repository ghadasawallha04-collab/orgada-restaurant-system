<?php
require_once __DIR__ . "/../includes/guard_user.php";
require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/helpers.php";
include __DIR__ . "/../includes/header.php";

$OrderID = (int)($_GET['OrderID'] ?? 0);
if ($OrderID<=0){ echo "<div class='err'>Invalid OrderID</div>"; include __DIR__."/../includes/footer.php"; exit; }

$st = $pdo->prepare("
  SELECT o.OrderID, o.OrderDate, o.OrderType,
         c.FirstName, c.LastName, c.Phone,
         pm.MethodName,
         dc.CompanyName
  FROM `Order` o
  JOIN Customer c ON o.CustomerID=c.CustomerID
  JOIN PaymentMethod pm ON o.PaymentMethodID=pm.PaymentMethodID
  LEFT JOIN DeliveryCompany dc ON o.DeliveryCompanyID=dc.DeliveryCompanyID
  WHERE o.OrderID=?
");
$st->execute([$OrderID]);
$o = $st->fetch();
if(!$o){ echo "<div class='err'>Order not found</div>"; include __DIR__."/../includes/footer.php"; exit; }

$itemsSt = $pdo->prepare("
  SELECT m.MenuItemName, oi.Quantity, oi.Price
  FROM OrderItem oi
  JOIN MenuItem m ON oi.MenuItemID=m.MenuItemID
  WHERE oi.OrderID=?
");
$itemsSt->execute([$OrderID]);
$items = $itemsSt->fetchAll();

$total = 0.0;
foreach($items as $it){ $total += (float)$it['Price']*(int)$it['Quantity']; }
?>
<div class="card">
  <h2>Receipt - Order #<?=h($OrderID)?></h2>
  <p class="small">
    Date: <?=h($o['OrderDate'])?><br>
    Customer: <?=h($o['FirstName']." ".$o['LastName'])?> (<?=h($o['Phone'])?>)<br>
    Type: <?=h($o['OrderType'])?><br>
    Payment: <?=h($o['MethodName'])?><br>
    <?php if($o['OrderType']==='delivery'): ?>
      Delivery: <?=h($o['CompanyName'] ?? '-')?><br>
    <?php endif; ?>
  </p>

  <table>
    <thead><tr><th>Item</th><th>Qty</th><th>Unit</th><th>Line</th></tr></thead>
    <tbody>
      <?php foreach($items as $it):
        $line = (float)$it['Price']*(int)$it['Quantity'];
      ?>
      <tr>
        <td><?=h($it['MenuItemName'])?></td>
        <td><?=h($it['Quantity'])?></td>
        <td><?=number_format((float)$it['Price'],2)?></td>
        <td><?=number_format($line,2)?></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <p><b>Total (computed):</b> <?=number_format($total,2)?></p>
  <a href="/app/user/order_create.php"><button type="button">New Order</button></a>
</div>
<?php include __DIR__ . "/../includes/footer.php"; ?>
