<?php
require_once __DIR__ . "/../includes/guard_user.php";
require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/helpers.php";
include __DIR__ . "/../includes/header.php";

$OrderID = (int)($_GET['OrderID'] ?? 0);
if ($OrderID <= 0) {
  echo "<div class='err'>Invalid OrderID</div>";
  include __DIR__."/../includes/footer.php";
  exit;
}

/**
 * Update Orders.TotalAmount to match items + extras
 */
function update_order_total(PDO $pdo, int $OrderID): void {
  $sql = "
    UPDATE Orders o
    SET o.TotalAmount = (
      SELECT IFNULL(SUM(
        (oi.Price + IFNULL(ex.ExtraTotal, 0)) * oi.Quantity
      ), 0)
      FROM OrderItem oi
      LEFT JOIN (
        SELECT oie.OrderItemID, SUM(e.ExtraPrice * oie.Quantity) AS ExtraTotal
        FROM OrderItemExtra oie
        JOIN Extra e ON e.ExtraID = oie.ExtraID
        GROUP BY oie.OrderItemID
      ) ex ON ex.OrderItemID = oi.OrderItemID
      WHERE oi.OrderID = o.OrderID
    )
    WHERE o.OrderID = ?
  ";
  $st = $pdo->prepare($sql);
  $st->execute([$OrderID]);
}

/**
 * Load order header
 */
$st = $pdo->prepare("
  SELECT o.OrderID, o.OrderDate, o.OrderType,
         c.FirstName, c.LastName, c.Phone
  FROM Orders o
  LEFT JOIN Customer c ON o.CustomerID = c.CustomerID
  WHERE o.OrderID = ?
");
$st->execute([$OrderID]);
$order = $st->fetch(PDO::FETCH_ASSOC);

if (!$order) {
  echo "<div class='err'>Order not found</div>";
  include __DIR__."/../includes/footer.php";
  exit;
}

/**
 * Menu list (for dropdown)
 */
$menu = $pdo->query("
  SELECT m.MenuItemID, m.MenuItemName, m.Price, c.CategoryName
  FROM MenuItem m
  JOIN Category c ON c.CategoryID = m.CategoryID
  WHERE m.IsAvailable = 1
  ORDER BY c.CategoryName, m.MenuItemName
")->fetchAll(PDO::FETCH_ASSOC);

/**
 * Extras map per MenuItem (for filtering extras on UI)
 */
$extrasRows = $pdo->query("
  SELECT me.MenuItemID, e.ExtraID, e.ExtraName, e.ExtraPrice
  FROM MenuItemExtra me
  JOIN Extra e ON e.ExtraID = me.ExtraID
  WHERE e.IsAvailable = 1
  ORDER BY me.MenuItemID, e.ExtraName
")->fetchAll(PDO::FETCH_ASSOC);

$extrasByMenu = [];
foreach ($extrasRows as $r) {
  $mid = (int)$r['MenuItemID'];
  if (!isset($extrasByMenu[$mid])) $extrasByMenu[$mid] = [];
  $extrasByMenu[$mid][] = $r;
}

/**
 * Handle add item + extras
 */
$err = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add') {
  $MenuItemID = (int)($_POST['MenuItemID'] ?? 0);
  $Quantity   = (int)($_POST['Quantity'] ?? 0);
  $Extras     = $_POST['extras'] ?? []; // array of ExtraID

  if ($MenuItemID <= 0 || $Quantity <= 0) {
    $err = "Select item + valid quantity.";
  } else {
    // ensure menu item exists + available
    $p = $pdo->prepare("SELECT Price FROM MenuItem WHERE MenuItemID = ? AND IsAvailable = 1");
    $p->execute([$MenuItemID]);
    $row = $p->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
      $err = "Item not available.";
    } else {
      $Price = (float)$row['Price'];

      // 1) Insert NEW OrderItem row (no ON DUPLICATE KEY now)
      $ins = $pdo->prepare("
        INSERT INTO OrderItem (OrderID, MenuItemID, Quantity, Price)
        VALUES (?, ?, ?, ?)
      ");
      $ins->execute([$OrderID, $MenuItemID, $Quantity, $Price]);
      $OrderItemID = (int)$pdo->lastInsertId();

      // 2) Insert extras (only those allowed for this MenuItem)
      if ($OrderItemID > 0 && is_array($Extras) && count($Extras) > 0) {
        // allowed extras set for menu item
        $allowed = [];
        foreach (($extrasByMenu[$MenuItemID] ?? []) as $ex) {
          $allowed[(int)$ex['ExtraID']] = true;
        }

        $insEx = $pdo->prepare("
          INSERT INTO OrderItemExtra (OrderItemID, ExtraID, Quantity)
          VALUES (?, ?, 1)
        ");

        foreach ($Extras as $eid) {
          $eid = (int)$eid;
          if ($eid > 0 && isset($allowed[$eid])) {
            $insEx->execute([$OrderItemID, $eid]);
          }
        }
      }

      // Update order total in DB
      update_order_total($pdo, $OrderID);

      // Refresh to avoid resubmission
      header("Location: /app/user/order_items.php?OrderID=".$OrderID);
      exit;
    }
  }
}

/**
 * Remove by OrderItemID (not MenuItemID)
 */
if (isset($_GET['remove']) && (int)$_GET['remove'] > 0) {
  $RemoveOrderItemID = (int)$_GET['remove'];

  $del = $pdo->prepare("DELETE FROM OrderItem WHERE OrderItemID = ? AND OrderID = ?");
  $del->execute([$RemoveOrderItemID, $OrderID]);

  update_order_total($pdo, $OrderID);

  header("Location: /app/user/order_items.php?OrderID=".$OrderID);
  exit;
}

/**
 * Load items with extras summary per OrderItemID
 */
$itemsSt = $pdo->prepare("
  SELECT
    oi.OrderItemID,
    oi.MenuItemID,
    m.MenuItemName,
    oi.Quantity,
    oi.Price,
    IFNULL(ex.ExtraTotal, 0) AS ExtraTotal,
    IFNULL(ex.Extras, '') AS Extras
  FROM OrderItem oi
  JOIN MenuItem m ON m.MenuItemID = oi.MenuItemID
  LEFT JOIN (
    SELECT
      oie.OrderItemID,
      SUM(e.ExtraPrice * oie.Quantity) AS ExtraTotal,
      GROUP_CONCAT(CONCAT(e.ExtraName, ' (+', e.ExtraPrice, ')') SEPARATOR ', ') AS Extras
    FROM OrderItemExtra oie
    JOIN Extra e ON e.ExtraID = oie.ExtraID
    GROUP BY oie.OrderItemID
  ) ex ON ex.OrderItemID = oi.OrderItemID
  WHERE oi.OrderID = ?
  ORDER BY oi.OrderItemID
");
$itemsSt->execute([$OrderID]);
$items = $itemsSt->fetchAll(PDO::FETCH_ASSOC);

// Compute total (item + extras) * qty
$total = 0.0;
foreach ($items as $it) {
  $unit = (float)$it['Price'] + (float)$it['ExtraTotal'];
  $line = $unit * (int)$it['Quantity'];
  $total += $line;
}
?>

<div class="card">
  <h2>Order #<?= h($OrderID) ?></h2>

  <p class="small">
    Customer:
    <?= h(trim(($order['FirstName'] ?? '')." ".($order['LastName'] ?? ''))) ?>
    (<?= h($order['Phone'] ?? '') ?>)
    | Type: <?= h($order['OrderType'] ?? '') ?>
    | Total (computed): <?= number_format($total, 2) ?>
  </p>

  <?php if ($err) echo "<div class='err'>".h($err)."</div>"; ?>

  <form method="post" class="card" id="addForm">
    <input type="hidden" name="action" value="add">

    <label>Menu Item</label>
    <select name="MenuItemID" id="menuSelect" required>
      <option value="">-- Select --</option>
      <?php
        $currentCat = "";
        foreach ($menu as $m):
          if ($currentCat !== $m['CategoryName']) {
            if ($currentCat !== "") echo "</optgroup>";
            $currentCat = $m['CategoryName'];
            echo "<optgroup label='".h($currentCat)."'>";
          }
      ?>
        <option value="<?= h($m['MenuItemID']) ?>">
          <?= h($m['MenuItemName']) ?> (<?= number_format((float)$m['Price'], 2) ?>)
        </option>
      <?php endforeach;
        if ($currentCat !== "") echo "</optgroup>";
      ?>
    </select>

    <label>Quantity</label>
    <input type="number" name="Quantity" min="1" value="1" required>

    <div style="margin-top:10px;">
      <label><b>Extras</b> ( choosed items )</label>
      <div id="extrasBox" class="card" style="padding:10px; margin-top:6px;">
        <div class="small">Select a menu item to see available extras.</div>

        <?php
        // Render all extras with data-menu attribute, and JS will show/hide
        foreach ($extrasByMenu as $mid => $extrasList):
          foreach ($extrasList as $ex):
        ?>
          <label class="extraRow" data-menu="<?= (int)$mid ?>" style="display:none;">
            <input type="checkbox" name="extras[]" value="<?= (int)$ex['ExtraID'] ?>">
            <?= h($ex['ExtraName']) ?> (+<?= number_format((float)$ex['ExtraPrice'], 2) ?>)
          </label><br class="extraRow" data-menu="<?= (int)$mid ?>" style="display:none;">
        <?php
          endforeach;
        endforeach;
        ?>
      </div>
    </div>

    <button type="submit" style="margin-top:10px;">Add</button>
  </form>

  <h3>Items</h3>
  <table>
    <thead>
      <tr>
        <th>Item</th>
        <th>Extras</th>
        <th>Qty</th>
        <th>Unit (with extras)</th>
        <th>Line</th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($items as $it):
        $unit = (float)$it['Price'] + (float)$it['ExtraTotal'];
        $line = $unit * (int)$it['Quantity'];
      ?>
      <tr>
        <td><?= h($it['MenuItemName']) ?></td>
        <td class="small"><?= h($it['Extras'] ?: '-') ?></td>
        <td><?= h($it['Quantity']) ?></td>
        <td><?= number_format($unit, 2) ?></td>
        <td><?= number_format($line, 2) ?></td>
        <td>
          <a href="/app/user/order_items.php?OrderID=<?= $OrderID ?>&remove=<?= (int)$it['OrderItemID'] ?>">Remove</a>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

  <p><b>Total:</b> <?= number_format($total, 2) ?></p>
  <a href="/app/user/order_view.php?OrderID=<?= $OrderID ?>"><button type="button">Finish / View</button></a>
</div>

<script>
(function(){
  const menuSelect = document.getElementById('menuSelect');
  const extraRows = document.querySelectorAll('.extraRow');

  function refreshExtras(){
    const mid = menuSelect.value;
    extraRows.forEach(el => {
      const m = el.getAttribute('data-menu');
      const show = (mid && m === mid);
      el.style.display = show ? '' : 'none';
      // Uncheck when hidden
      if (!show) {
        const cb = el.querySelector('input[type="checkbox"]');
        if (cb) cb.checked = false;
      }
    });

    // If no menu selected, show hint text only
    const hint = document.querySelector('#extrasBox .small');
    if (hint) hint.style.display = mid ? 'none' : '';
  }

  menuSelect.addEventListener('change', refreshExtras);
  refreshExtras();
})();
</script>

<?php include __DIR__ . "/../includes/footer.php"; ?>
