<?php
session_start();
require_once "DB.php";

if (!isset($_SESSION['user_id'])) {
  header("Location: login.php");
  exit;
}

$saleId = (int)($_GET['id'] ?? 0);
if ($saleId <= 0) {
  echo "Invalid invoice";
  exit;
}

$uid = (int)$_SESSION['user_id'];

$stmt = $databaseConnection->prepare(
  "SELECT SaleID, SaleDate, TotalAmount
   FROM sale
   WHERE SaleID=? AND CreatedBy=?"
);
$stmt->bind_param("ii", $saleId, $uid);
$stmt->execute();
$sale = $stmt->get_result()->fetch_assoc();

if (!$sale) {
  echo "Invoice not found or access denied";
  exit;
}

$stmt = $databaseConnection->prepare(
  "SELECT si.Qty, si.UnitPrice, si.LineTotal, mi.MenuItemName
   FROM saleitem si
   JOIN menuitem mi ON mi.MenuItemID = si.ProductID
   WHERE si.SaleID=?"
);
$stmt->bind_param("i", $saleId);
$stmt->execute();
$items = $stmt->get_result();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice #<?= (int)$sale['SaleID'] ?></title>
<style>
body{background:#0b0b0d;color:#fff;font-family:Arial;margin:0}
.wrap{width:900px;margin:40px auto}
.box{background:#121216;padding:20px;border-radius:14px;border:1px solid rgba(255,255,255,.12)}
table{width:100%;border-collapse:collapse;margin-top:12px}
th,td{padding:10px;border-bottom:1px solid #333;text-align:left}
th{color:#cfcfd4}
.btn{display:inline-block;padding:10px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.12);color:#fff;text-decoration:none}
</style>
</head>
<body>
<div class="wrap">
  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
    <h1 style="margin:0;">Invoice #<?= (int)$sale['SaleID'] ?></h1>
    <a class="btn" href="cashier_sales.php">← Back</a>
  </div>

  <div class="box">
    <div style="display:flex;gap:18px;flex-wrap:wrap;">
      <div><b>Date:</b> <?= htmlspecialchars($sale['SaleDate']) ?></div>
      <div><b>Total:</b> <?= number_format((float)$sale['TotalAmount'],2) ?></div>
    </div>

    <table>
      <tr>
        <th>Item</th>
        <th>Qty</th>
        <th>Unit Price</th>
        <th>Line Total</th>
      </tr>
      <?php while ($i = $items->fetch_assoc()): ?>
        <tr>
          <td><?= htmlspecialchars($i['MenuItemName']) ?></td>
          <td><?= (int)$i['Qty'] ?></td>
          <td><?= number_format((float)$i['UnitPrice'],2) ?></td>
          <td><?= number_format((float)$i['LineTotal'],2) ?></td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>
</div>
</body>
</html>
