<?php
session_start();
//Allow access only for admins
require_once "DB.php";
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}
$warehousesRes=$databaseConnection->query("SELECT WarehouseID, WarehouseName FROM Warehouse ORDER BY WarehouseName");
$ingredientsRes=$databaseConnection->query("SELECT IngredientID, IngredientName FROM Ingredient ORDER BY IngredientName");
//Add new stock movement
if (isset($_POST['add_move'])) {
  $warehouseId=(int)($_POST['warehouse_id'] ?? 0);
  $ingredientId=(int)($_POST['ingredient_id'] ?? 0);
  $type=trim($_POST['movement_type'] ?? '');
  $date=$_POST['movement_date'] ?? date('Y-m-d');
  $qty=(int)($_POST['quantity'] ?? 0);
  $typeUpper=strtoupper($type);
  if ($warehouseId > 0 && $ingredientId > 0 && ($typeUpper === 'IN' || $typeUpper === 'OUT') && $qty > 0) {
    $stmt = $databaseConnection->prepare(
      "INSERT INTO StockMovement (WarehouseID, IngredientID, MovementType, MovementDate, Quantity)
       VALUES (?, ?, ?, ?, ?)"
    );
    $stmt->bind_param("iissi", $warehouseId, $ingredientId, $typeUpper, $date, $qty);
    $stmt->execute();
  }
  header("Location: stockmovement.php");
  exit;
}
// Delete stock movement
if (isset($_POST['delete_move'])) {
  $id = (int)($_POST['move_id'] ?? 0);

  if ($id > 0) {
    $stmt = $databaseConnection->prepare("DELETE FROM StockMovement WHERE stockmovementid=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
  }

  header("Location: stockmovement.php");
  exit;
}
$fw=trim($_GET['warehouse_id'] ?? '');
$fi=trim($_GET['ingredient_id'] ?? '');
$ft=trim($_GET['type'] ?? '');
$sql = "SELECT sm.stockmovementid, sm.MovementType, sm.MovementDate, sm.Quantity,
               w.WarehouseName, i.IngredientName
        FROM StockMovement sm
        JOIN Warehouse w ON w.WarehouseID = sm.WarehouseID
        JOIN Ingredient i ON i.IngredientID = sm.IngredientID
        WHERE 1=1 ";

$params = [];
$types  = "";
if ($fw !== '') { $sql .= " AND sm.WarehouseID=? ";  $params[] = (int)$fw; $types .= "i"; }
if ($fi !== '') { $sql .= " AND sm.IngredientID=? "; $params[] = (int)$fi; $types .= "i"; }
if ($ft !== '' && ($ft === 'IN' || $ft === 'OUT')) { $sql .= " AND sm.MovementType=? "; $params[] = $ft; $types .= "s"; }
$sql .=" ORDER BY sm.MovementDate DESC, sm.stockmovementid DESC";
if (count($params) > 0) {
  $stmt = $databaseConnection->prepare($sql);
  $stmt->bind_param($types, ...$params);
  $stmt->execute();
  $moves = $stmt->get_result();
} else {
  $moves = $databaseConnection->query(
    "SELECT sm.stockmovementid, sm.MovementType, sm.MovementDate, sm.Quantity,
            w.WarehouseName, i.IngredientName
     FROM StockMovement sm
     JOIN Warehouse w ON w.WarehouseID = sm.WarehouseID
     JOIN Ingredient i ON i.IngredientID = sm.IngredientID
     ORDER BY sm.MovementDate DESC, sm.stockmovementid DESC"
  );
}
?>
<!--HTML&CSS codes-->
<!doctype html>
<html>
<head>
  <title>Admin | Stock Movement</title>
  <style>
    body{
        font-family:Arial;
        background:#0b0b0d;
        color:#fff;
        margin:0;
    }
    .wrap{
        width:1100px;
        margin:40px auto;
    }
    .top{
        display:flex;
        justify-content:space-between;
        align-items:center;
        margin-bottom:12px;
    }
    .box{
        background:#121216;
        padding:20px;
        border-radius:14px;
        margin-bottom:18px;
        border:1px solid rgba(255,255,255,.12);
    }
    table{
        width:100%;
        border-collapse:collapse;
        margin-top:14px;
    }
    th,td{
        padding:10px;
        border-bottom:1px solid #333;
        text-align:left;
    }
    th{
        color:#cfcfd4;
    }

    input,select,button{
        padding:8px;
        border-radius:8px;
        border:none;
        margin:4px;
        outline:none;
    }

    input{
        width:160px;
    }
    select{
        width:220px;
    }
    button{
        cursor:pointer;
        background:#d71920;
        color:#fff;
        font-weight:700;
    }
    .btn-lite{
        background:transparent;
        border:1px solid rgba(255,255,255,.12);
        color:#fff;
        display:inline-block;
        padding:8px 14px;
        border-radius:10px;
        text-decoration:none;
    }
    .danger{
        background:#ff4d4d;
    }
    .row-actions{
        display:flex;
        gap:8px;
        align-items:center;
    }
  </style>
</head>
<body>
<div class="wrap">

  <div class="top">
    <h1 style="margin:0;">Stock Movement</h1>
    <a href="admin.php" class="btn-lite">← Back to Dashboard</a>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Add Stock Movement</h3>
    <form method="post">
      <select name="warehouse_id" required>
        <option value="">Select Warehouse</option>
        <?php while($w = $warehousesRes->fetch_assoc()): ?>
          <option value="<?= (int)$w['WarehouseID'] ?>"><?= htmlspecialchars($w['WarehouseName']) ?></option>
        <?php endwhile; ?>
      </select>

      <select name="ingredient_id" required>
        <option value="">Select Ingredient</option>
        <?php while($i = $ingredientsRes->fetch_assoc()): ?>
          <option value="<?= (int)$i['IngredientID'] ?>"><?= htmlspecialchars($i['IngredientName']) ?></option>
        <?php endwhile; ?>
      </select>

      <select name="movement_type" required>
        <option value="IN">IN</option>
        <option value="OUT">OUT</option>
      </select>

      <input type="date" name="movement_date" required value="<?= date('Y-m-d') ?>">
      <input type="number" name="quantity" placeholder="Quantity" min="1" required>

      <button type="submit" name="add_move">Add</button>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Filter</h3>
    <form method="get" style="display:flex;flex-wrap:wrap;align-items:center;gap:6px;">
      <select name="warehouse_id">
        <option value="">All Warehouses</option>
        <?php
          $w2 = $databaseConnection->query("SELECT WarehouseID, WarehouseName FROM Warehouse ORDER BY WarehouseName");
          while($w = $w2->fetch_assoc()):
            $id = (int)$w['WarehouseID'];
            $sel = ((string)$fw === (string)$id) ? 'selected' : '';
        ?>
          <option value="<?= $id ?>" <?= $sel ?>><?= htmlspecialchars($w['WarehouseName']) ?></option>
        <?php endwhile; ?>
      </select>

      <select name="ingredient_id">
        <option value="">All Ingredients</option>
        <?php
          $i2 = $databaseConnection->query("SELECT IngredientID, IngredientName FROM Ingredient ORDER BY IngredientName");
          while($i = $i2->fetch_assoc()):
            $id = (int)$i['IngredientID'];
            $sel = ((string)$fi === (string)$id) ? 'selected' : '';
        ?>
          <option value="<?= $id ?>" <?= $sel ?>><?= htmlspecialchars($i['IngredientName']) ?></option>
        <?php endwhile; ?>
      </select>

      <select name="type">
        <option value="">All Types</option>
        <option value="IN"  <?= ($ft==='IN')  ? 'selected' : '' ?>>IN</option>
        <option value="OUT" <?= ($ft==='OUT') ? 'selected' : '' ?>>OUT</option>
      </select>

      <button type="submit">Search</button>
      <a class="btn-lite" href="stockmovement.php" style="padding:8px 12px;">Reset</a>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Movements List</h3>

    <table>
      <tr>
        <th>ID</th>
        <th>Date</th>
        <th>Type</th>
        <th>Warehouse</th>
        <th>Ingredient</th>
        <th>Qty</th>
        <th>Action</th>
      </tr>

      <?php while($row = $moves->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['stockmovementid'] ?></td>
          <td><?= htmlspecialchars($row['MovementDate']) ?></td>
          <td><?= htmlspecialchars($row['MovementType']) ?></td>
          <td><?= htmlspecialchars($row['WarehouseName']) ?></td>
          <td><?= htmlspecialchars($row['IngredientName']) ?></td>
          <td><?= (int)$row['Quantity'] ?></td>
          <td>
            <form method="post" class="row-actions" onsubmit="return confirm('Delete this movement?');">
              <input type="hidden" name="move_id" value="<?= (int)$row['stockmovementid'] ?>">
              <button class="danger" type="submit" name="delete_move">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

</div>
</body>
</html>
