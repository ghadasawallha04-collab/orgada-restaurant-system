<?php
session_start();
if(!isset($_SESSION['role']) || $_SESSION['role']!=='employee'){
  header("Location: login.php");
  exit;
}
?>
<!doctype html>
<html>
<head>
  <title>Orgada | Employee Dashboard</title>

  <style>
    :root{
      --red:#d71920;
      --black:#0b0b0d;
      --white:#ffffff;
      --muted:#cfcfd4;
      --border:rgba(255,255,255,.12);
      --shadow: 0 18px 45px rgba(0,0,0,.45);
      --radius:18px;
    }
    *{box-sizing:border-box}
    body{
      margin:0;
      font-family: Arial, sans-serif;
      background:var(--black);
      color:var(--white);
    }
    a{
      color:inherit;
      text-decoration:none;
    }

    .wrap{
      width:1150px;
      margin:0 auto;
    }

    /***************************************** NAV ************************/
    .nav{
      background:#0b0b0d;
      border-bottom:1px solid var(--border);
    }
    .nav-inner{
      display:flex;
      align-items:center;
      justify-content:space-between;
      padding:14px 0;
    }
    .brand{
      display:flex;
      align-items:center;
      gap:12px;
    }
    .brand img{
      width:46px;
      height:46px;
      border-radius:14px;
      background:#fff;
      object-fit:cover;
    }
    .brand b{font-size:16px}
    .brand span{
      display:block;
      font-size:12px;
      color:var(--muted);
      margin-top:3px;
    }

    .nav-cta{
      display:flex;
      gap:10px;
      align-items:center;
    }

    .btn{
      padding:10px 14px;
      border-radius:14px;
      border:1px solid var(--border);
      font-weight:700;
      cursor:pointer;
      background:transparent;
      color:var(--white);
      display:inline-block;
    }
    .btn.primary{
      background:var(--red);
      border:none;
    }

    /********************************* Page ******************************/
    .page{
      padding:50px 0;
    }

    .header-card{
      background:#121216;
      border:1px solid var(--border);
      border-radius:var(--radius);
      padding:22px;
      box-shadow:var(--shadow);
      margin-bottom:18px;
    }

    h1{
      margin:0 0 6px;
      font-size:26px;
    }
    p{
      margin:0;
      color:var(--muted);
      line-height:1.7;
      font-size:14px;
    }

    /*********************** Grid ********************************/
    .grid{
      display:grid;
      grid-template-columns: repeat(3, 1fr);
      gap:14px;
    }

    .card{
      background:#121216;
      border:1px solid var(--border);
      border-radius:var(--radius);
      padding:18px;
      box-shadow:var(--shadow);
    }
    .card h3{
      margin:0 0 10px;
      font-size:16px;
    }
    .card p{
      margin:0 0 14px;
      font-size:13px;
      color:var(--muted);
    }

    .footer{
      text-align:center;
      font-size:12px;
      color:var(--muted);
      padding:30px 0;
    }
  </style>
</head>

<body>

<header class="nav">
  <div class="wrap nav-inner">
    <div class="brand">
      <img src="assets/logo.jpg" alt="Orgada Logo">
      <div>
        <b>ORGADA BURGERS</b>
        <span>Employee Dashboard</span>
      </div>
    </div>

    <div class="nav-cta">
      <a class="btn primary" href="logout.php">Logout</a>
    </div>
  </div>
</header>

<section class="page">
  <div class="wrap">

    <div class="header-card">
      <h1>
        Welcome, <?= htmlspecialchars($_SESSION['first_name']) ?>
      </h1>
      <p>
        This page is used for daily operations.
        You can create orders and view customer information from here.
      </p>
    </div>

    <div class="grid">
      <div class="card">
        <h3>Orders</h3>
        <p>Create and manage customer orders.</p>
        <a class="btn primary" href="orders.php">Open</a>
      </div>

      <div class="card">
        <h3>Customers</h3>
        <p>View customer information.</p>
        <a class="btn primary" href="customers.php">Open</a>
      </div>
    </div>

  </div>
</section>

<footer class="footer">
  copyright 2025 Orgada Burgers — Ghada1220064 - Malak1220203
</footer>

</body>
</html>
