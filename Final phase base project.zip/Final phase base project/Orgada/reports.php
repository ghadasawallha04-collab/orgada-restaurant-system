<?php
session_start();
require_once "db.php";
//Allow for admin access only
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}
function esc($value) {
  return filter_var($value ?? '', FILTER_SANITIZE_SPECIAL_CHARS);
}

function fetchAll($conn, $sql, $types = "", $params = []) {
  if ($types !== "") {
    $statment=$conn->prepare($sql);
    if (!$statment) return [];
    $statment->bind_param($types, ...$params);
    $statment->execute();
    $res=$statment->get_result();
    $rows=[];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    return $rows;
  } else {
    $res = $conn->query($sql);
    if (!$res) return [];
    $rows = [];
    while ($r = $res->fetch_assoc()) $rows[] = $r;
    return $rows;
  }
}
function renderTable($rows) {
  if (!$rows || count($rows) === 0) {
    echo "<div style='padding:12px;border:1px solid rgba(255,255,255,.12);border-radius:12px;background:#121216;'>No results</div>";
    return;
  }
  $cols = array_keys($rows[0]);
  echo "<table><tr>";
  foreach ($cols as $c) echo "<th>" . esc($c) . "</th>";
  echo "</tr>";
  foreach ($rows as $row) {
    echo "<tr>";
    foreach ($cols as $c) echo "<td>" . esc((string)($row[$c] ?? "")) . "</td>";
    echo "</tr>";
  }
  echo "</table>";
}
$reports = [
  1  => ["name" => "Staff roster per branch","fields" => ["branch_id"]],
  2  => ["name" => "Branch managers","fields" => []],
  3  => ["name" => "Menu catalog by category","fields" => []],
  4  => ["name" => "Category performance","fields" => ["from","to"]],
  5  => ["name" => "Orders by order type", "fields" => ["from","to"]],
  6  => ["name" => "Top-selling items","fields" => ["from","to","topN"]],
  7  => ["name" => "Payment mix","fields" => ["from","to"]],
  8  => ["name" => "Repeat customers","fields" => ["K","M"]],
  9 => ["name" => "Delivery partner performance", "fields" => ["from","to"]],
  10 => ["name" => "On-hand stock (warehouse)","fields" => ["central_wh"]],
  11 => ["name" => "Recipe feasibility (not makeable)","fields" => ["central_wh","safety"]],
  12 => ["name" => "Recipe cost roll-up","fields" => []],
  13 => ["name" => "Average order value (monthly)","fields" => ["year"]],
  14 => ["name" => "Stock movement audit","fields" => ["from","to"]],
  25 => ["name" => "Monthly revenue comparison","fields" => ["year"]],
  16 => ["name" => "Branches by city","fields" => ["city"]],
];
//Inputs for reports
$report=(int)($_GET['r'] ?? 1);
if (!isset($reports[$report])) $report = 1;
$branchId=(int)($_GET['branch_id'] ?? 0);
$date=$_GET['date'] ?? date('Y-m-d');
$from=$_GET['from'] ?? date('Y-m-01');
$to=$_GET['to'] ?? date('Y-m-d');
$year=(int)($_GET['year'] ?? (int)date('Y'));
$topN=(int)($_GET['topN'] ?? 5);
$K=(int)($_GET['K'] ?? 3);
$M=(int)($_GET['M'] ?? 6);
$city=trim($_GET['city'] ?? '');
$safety=(float)($_GET['safety'] ?? 1.10);
$centralWarehouseId = (int)($_GET['central_wh'] ?? 1);
$branches=fetchAll($databaseConnection, "SELECT BranchID, BranchName FROM Branch ORDER BY BranchName");
$title=$reports[$report]["name"];
$rows=[];

//Excute all the quaries:
switch ($report) {
  case 1: // Staff roster per branch
    if ($branchId <= 0) { $rows = []; break; }
    $rows=fetchAll($databaseConnection,
      "SELECT e.EmployeeID,
              CONCAT(e.FirstName,' ',e.LastName) AS EmployeeName,
              e.Position,
              e.Salary
       FROM Employee e
       WHERE e.BranchID=?
       ORDER BY e.EmployeeID",
      "i", [$branchId]
    );
    break;

  case 2: // Branch managers
    $rows = fetchAll($databaseConnection,
      "SELECT b.BranchID, b.BranchName,
              CONCAT(e.FirstName,' ',e.LastName) AS ManagerName
       FROM Branch b
       LEFT JOIN Employee e ON e.BranchID=b.BranchID AND e.Position='Manager'
       ORDER BY b.BranchID"
    );
    break;

  case 3: // Menu catalog by category
    $rows=fetchAll($databaseConnection,
      "SELECT c.CategoryName,
              m.MenuItemName,
              m.price AS Price,
              m.IsAvailable
       FROM MenuItem m
       JOIN Category c ON c.CategoryID=m.CategoryID
       ORDER BY c.CategoryName, m.MenuItemName"
    );
    break;

    case 4: // Category performance 
    $sql="
    SELECT
      c.CategoryName AS Category,
      SUM(oi.Quantity) AS QtySold,
      SUM(oi.Quantity * oi.price) AS Revenue
    FROM OrderItem oi
    JOIN Orders o     ON o.OrderID = oi.OrderID
    JOIN MenuItem m   ON m.MenuItemID = oi.MenuItemID
    JOIN Category c   ON c.CategoryID = m.CategoryID
    WHERE o.OrderDate >= ? AND o.OrderDate <= ?
    GROUP BY c.CategoryName
    ORDER BY Revenue DESC
    ";
  $rows=fetchAll($databaseConnection,$sql,"ss",[$from, $to]);
  break;

  case 5: // Orders by order type
  $sql="
    SELECT
      b.BranchName AS Branch,
      o.OrderType  AS Type,
      COUNT(o.OrderID) AS OrdersCount,
      SUM(o.TotalAmount) AS Total
    FROM Orders o
    JOIN Branch b ON b.BranchID = o.BranchID
    WHERE o.OrderDate >= ? AND o.OrderDate <= ?
    GROUP BY b.BranchName, o.OrderType
    ORDER BY b.BranchName, o.OrderType
    ";
  $rows = fetchAll($databaseConnection, $sql,"ss",[$from, $to]);
  break;


  case 6: // Top-selling items 
    $rows = fetchAll($databaseConnection,
      "SELECT b.BranchName, m.MenuItemName,
              SUM(oi.Quantity) AS QtySold
       FROM Orders o
       JOIN Branch b ON b.BranchID=o.BranchID
       JOIN OrderItem oi ON oi.OrderID=o.OrderID
       JOIN MenuItem m ON m.MenuItemID=oi.MenuItemID
       WHERE o.OrderDate BETWEEN ? AND ?
       GROUP BY b.BranchName, m.MenuItemName
       ORDER BY b.BranchName, QtySold DESC",
      "ss", [$from, $to]
    );
    break;
    case 7:
        $totalRow = fetchAll($databaseConnection,
    "SELECT COUNT(*) AS TotalOrders
     FROM Orders
     WHERE OrderDate BETWEEN ? AND ?",
    "ss",
    [$from, $to]
  );
  $totalOrders=(int)($totalRow[0]['TotalOrders'] ?? 0);
  $rows = fetchAll(
    $databaseConnection,
    "SELECT pm.PaymentMethodName, COUNT(*) AS Cnt
     FROM Orders o
     JOIN PaymentMethod pm ON pm.PaymentMethodID = o.paymentmethodID
     WHERE o.OrderDate BETWEEN ? AND ?
     GROUP BY pm.PaymentMethodName
     ORDER BY Cnt DESC",
    "ss",
    [$from, $to]
  );
  foreach ($rows as &$r) {
    $cnt = (int)$r['Cnt'];
    $r['SharePct'] = ($totalOrders > 0) ? round(100 * $cnt / $totalOrders, 2) : 0;
  }
  unset($r);
  break;


case 8: //Repeat customers
  $sql = "
    SELECT
      c.CustomerID,
      CONCAT(c.FirstName,' ',c.LastName) AS CustomerName,
      COUNT(o.OrderID) AS OrdersCount,
      SUM(o.TotalAmount) AS TotalSpend
    FROM Orders o
    JOIN Customer c ON c.CustomerID = o.CustomerID
    WHERE o.OrderDate >= DATE_SUB(CURDATE(), INTERVAL ? MONTH)
    GROUP BY c.CustomerID, c.FirstName, c.LastName
    HAVING COUNT(o.OrderID) >= ?
    ORDER BY TotalSpend DESC
  ";
  $rows = fetchAll($databaseConnection, $sql, "ii", [$M, $K]);
  break;

case 9: // Delivery partner performance
  $sql = "
    SELECT
      d.CompanyName,
      COUNT(o.OrderID) AS DeliveryOrders,
      SUM(o.TotalAmount) AS Revenue
    FROM Orders o
    JOIN DeliveryCompany d ON d.DeliveryCompanyID = o.deliverycompanyID
    WHERE o.OrderType = 'Delivery'
      AND o.OrderDate BETWEEN ? AND ?
    GROUP BY d.CompanyName
    ORDER BY Revenue DESC
  ";
  $rows = fetchAll($databaseConnection, $sql, "ss", [$from, $to]);
  break;

case 10:// On-hand stock
  $sql = "
    SELECT
      i.IngredientName,
      i.Unit,
      SUM(
        CASE
          WHEN sm.MovementType = 'IN'  THEN sm.Quantity
          WHEN sm.MovementType = 'OUT' THEN -sm.Quantity
          ELSE 0
        END
      ) AS OnHandQty
    FROM Ingredient i
    LEFT JOIN StockMovement sm
      ON sm.IngredientID = i.IngredientID
     AND sm.WarehouseID = ?
    GROUP BY i.IngredientID, i.IngredientName, i.Unit
    ORDER BY OnHandQty ASC
  ";
  $rows = fetchAll($databaseConnection, $sql, "i", [$centralWarehouseId]);
  break;

case 11:
  $sql = "
    SELECT
      m.MenuItemName,
      i.IngredientName,
      (ri.Quantity * ?) AS NeededQty,
      IFNULL(sm.OnHandQty, 0) AS OnHandQty
    FROM MenuItem m
    JOIN RecipeIngredient ri ON ri.RecipeID = m.recipeID
    JOIN Ingredient i ON i.IngredientID = ri.IngredientID
    LEFT JOIN (
      SELECT
        IngredientID,
        SUM(
          IF(MovementType = 'IN', Quantity, -Quantity)
        ) AS OnHandQty
      FROM StockMovement
      WHERE WarehouseID = ?
      GROUP BY IngredientID
    ) sm ON sm.IngredientID = i.IngredientID
    WHERE IFNULL(sm.OnHandQty, 0) < (ri.Quantity * ?)
    ORDER BY m.MenuItemName, i.IngredientName
  ";

  $rows = fetchAll(
    $databaseConnection,
    $sql,
    "did",
    [$safety, $centralWarehouseId, $safety]
  );
  break;


case 12:
  $costRows = fetchAll(
    $databaseConnection,
    "SELECT
       pi.IngredientID,
       pi.Cost AS LastUnitCost
     FROM PurchaseItem pi
     JOIN Purchase p ON p.PurchaseID = pi.PurchaseID
     WHERE p.PurchaseStatus = 'Received'
       AND (p.PurchaseDate, p.PurchaseID) = (
         SELECT p2.PurchaseDate, p2.PurchaseID
         FROM PurchaseItem pi2
         JOIN Purchase p2 ON p2.PurchaseID = pi2.PurchaseID
         WHERE pi2.IngredientID = pi.IngredientID
           AND p2.PurchaseStatus = 'Received'
         ORDER BY p2.PurchaseDate DESC, p2.PurchaseID DESC
         LIMIT 1
       )"
  );

  $lastCost = [];
  foreach ($costRows as $r) {
    $lastCost[(int)$r['IngredientID']] = (float)$r['LastUnitCost'];
  }
  $reqRows = fetchAll(
    $databaseConnection,
    "SELECT
       m.MenuItemID,
       m.MenuItemName,
       m.price AS SellPrice,
       ri.IngredientID,
       ri.Quantity
     FROM MenuItem m
     JOIN RecipeIngredient ri ON ri.RecipeID = m.recipeID
     ORDER BY m.MenuItemID"
  );

  $result = [];
  foreach ($reqRows as $r) {
    $mid = (int)$r['MenuItemID'];

    if (!isset($result[$mid])) {
      $result[$mid] = [
        'MenuItemName' => $r['MenuItemName'],
        'SellPrice'    => (float)$r['SellPrice'],
        'RecipeCost'   => 0.0,
        'Margin'       => 0.0
      ];
    }

    $ing = (int)$r['IngredientID'];
    $qty = (float)$r['Quantity'];
    $unitCost = $lastCost[$ing] ?? 0.0;

    $result[$mid]['RecipeCost'] += ($qty * $unitCost);
  }

  $rows = [];
  foreach ($result as $mid => $v) {
    $v['RecipeCost'] = round($v['RecipeCost'], 2);
    $v['Margin'] = round($v['SellPrice'] - $v['RecipeCost'], 2);
    $rows[] = $v;
  }

  usort($rows, function($a, $b) {
    return $a['Margin'] <=> $b['Margin'];
  });

  break;

case 13:// Average order value
  $sql = "
    SELECT
      b.BranchName,
      MONTH(o.OrderDate) AS Month,
      ROUND(AVG(o.TotalAmount), 2) AS AvgOrderValue
    FROM Orders o
    JOIN Branch b ON b.BranchID = o.BranchID
    WHERE YEAR(o.OrderDate) = ?
    GROUP BY b.BranchName, MONTH(o.OrderDate)
    ORDER BY b.BranchName, Month
  ";
  $rows = fetchAll($databaseConnection, $sql, "i", [$year]);
  break;

case 14: // Stock movement audit
  $sql = "
    SELECT
      stockmovementid,
      MovementDate,
      MovementType,
      Quantity,
      WarehouseID,
      IngredientID
    FROM StockMovement
    WHERE MovementDate BETWEEN ? AND ?
    ORDER BY MovementDate ASC, stockmovementid ASC
  ";
  $rows = fetchAll($databaseConnection, $sql, "ss", [$from, $to]);
  break;

case 15: // Monthly revenue comparison
  $sql = "
    SELECT
      MONTH(o.OrderDate) AS Month,
      b.BranchName,
      SUM(o.TotalAmount) AS Revenue
    FROM Orders o
    JOIN Branch b ON b.BranchID = o.BranchID
    WHERE YEAR(o.OrderDate) = ?
    GROUP BY MONTH(o.OrderDate), b.BranchName
    ORDER BY Month, b.BranchName
  ";
  $rows = fetchAll($databaseConnection, $sql, "i", [$year]);
  break;

case 16: //Branches by city
  if ($city === '') { $rows = []; break; }
  $sql = "
    SELECT
      BranchID,
      BranchName,
      City
    FROM Branch
    WHERE City = ?
    ORDER BY BranchName
  ";
  $rows = fetchAll($databaseConnection, $sql, "s", [$city]);
  break;
}
?>
<!--HTML&CSS Codes-->
<!doctype html>
<html>
<head>
  <title>Admin | Reports</title>
<style>
  body {
    font-family: Arial;
    background: #0b0b0d;
    color: #fff;
    margin: 0;
  }

  .wrap {
    width: 1200px;
    margin: 40px auto;
  }

  .top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
  }

  .box {
    background: #121216;
    padding: 18px;
    border-radius: 14px;
    margin-bottom: 16px;
    border: 1px solid rgba(255, 255, 255, 0.12);
  }

  label {
    font-size: 13px;
    color: #cfcfd4;
  }

  input,
  select,
  button {
    padding: 8px;
    border-radius: 8px;
    border: none;
    margin: 4px;
    outline: none;
  }

  input,
  select {
    background: #0f0f13;
    color: #fff;
    border: 1px solid rgba(255, 255, 255, 0.10);
  }

  button {
    cursor: pointer;
    background: #d71920;
    color: #fff;
    font-weight: 700;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 12px;
  }

  th,
  td {
    padding: 10px;
    border-bottom: 1px solid #333;
    text-align: left;
    vertical-align: top;
  }

  th {
    color: #cfcfd4;
  }

  .btn-lite {
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.12);
    color: #fff;
    display: inline-block;
    padding: 8px 14px;
    border-radius: 10px;
    text-decoration: none;
  }

  .grid {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: end;
  }

  .field {
    display: flex;
    flex-direction: column;
  }
</style>
</head>
<body>
<div class="wrap">

  <div class="top">
    <h1 style="margin:0;">Reports</h1>
    <a class="btn-lite" href="admin.php">← Back to Dashboard</a>
  </div>

  <div class="box">
    <form method="get" class="grid">
      <div class="field" data-field="r">
        <label>Report</label>
        <select name="r" id="reportSelect">
          <?php foreach($reports as $id => $info): ?>
            <option value="<?= (int)$id ?>" <?= ($report===$id?'selected':'') ?>>
              <?= esc($info['name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="field" data-field="branch_id">
        <label>Branch</label>
        <select name="branch_id">
          <option value="0">-- Select --</option>
          <?php foreach($branches as $b): ?>
            <option value="<?= (int)$b['BranchID'] ?>" <?= ($branchId==(int)$b['BranchID']?'selected':'') ?>>
              <?= esc($b['BranchName']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="field" data-field="from">
        <label>From</label>
        <input type="date" name="from" value="<?= esc($from) ?>">
      </div>

      <div class="field" data-field="to">
        <label>To</label>
        <input type="date" name="to" value="<?= esc($to) ?>">
      </div>

      <div class="field" data-field="year">
        <label>Year</label>
        <input type="number" name="year" value="<?= (int)$year ?>" min="2000" max="2100">
      </div>

      <div class="field" data-field="topN">
        <label>Top N</label>
        <input type="number" name="topN" value="<?= (int)$topN ?>" min="1" max="100">
      </div>

      <div class="field" data-field="K">
        <label>K (repeat orders)</label>
        <input type="number" name="K" value="<?= (int)$K ?>" min="1" max="999">
      </div>

      <div class="field" data-field="M">
        <label>M (months)</label>
        <input type="number" name="M" value="<?= (int)$M ?>" min="1" max="60">
      </div>

      <div class="field" data-field="city">
        <label>City</label>
        <input name="city" value="<?= esc($city) ?>" placeholder="Ramallah...">
      </div>

      <div class="field" data-field="central_wh">
        <label>Warehouse</label>
        <input type="number" name="central_wh" value="<?= (int)$centralWarehouseId ?>" min="1">
      </div>

      <div class="field" data-field="safety">
        <label>Safety</label>
        <input type="number" step="0.01" name="safety" value="<?= esc((string)$safety) ?>" min="1" max="3">
      </div>

      <div class="field" data-field="run">
        <label>&nbsp;</label>
        <button type="submit">Run</button>
      </div>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 8px;"><?= esc($title) ?></h3>
    <?php renderTable($rows); ?>
  </div>

</div>

<script>
  const reportFields = <?= json_encode(array_map(fn($r)=>$r['fields'],$reports), JSON_UNESCAPED_UNICODE) ?>;

  function updateFields() {
    const r = document.getElementById('reportSelect').value;
    const needed = new Set(reportFields[r] || []);
    document.querySelectorAll('[data-field]').forEach(el => {
      const key = el.getAttribute('data-field');
      if (key === 'r' || key === 'run') return;
      el.style.display = needed.has(key) ? 'flex' : 'none';
    });
  }

  document.getElementById('reportSelect').addEventListener('change', updateFields);
  updateFields();
</script>

</body>
</html>
