<?php
session_start();
require_once "DB.php";

/* Cashier only (non-admin) */
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || strtolower($_SESSION['role']) === 'admin') {
  header("Location: login.php");
  exit;
}

$uid = (int)$_SESSION['user_id'];
$msg = "";

/* Permission: change password (default 0 if not set) */
$canChangePassword = (int)($_SESSION['can_change_password'] ?? 0);

/* Handle password change */
if (isset($_POST['change_password'])) {

  if ($canChangePassword !== 1) {
    $msg = "You do not have permission to change the password. Please contact the administrator.";
  } else {

    $current = $_POST['current_password'] ?? '';
    $new1    = $_POST['new_password'] ?? '';
    $new2    = $_POST['confirm_password'] ?? '';

    if ($new1 === '' || $new2 === '' || $current === '') {
      $msg = "Please fill all password fields.";
    } elseif ($new1 !== $new2) {
      $msg = "New passwords do not match.";
    } elseif (strlen($new1) < 6) {
      $msg = "New password must be at least 6 characters.";
    } else {
      // Fetch current hash
      $stmt = $databaseConnection->prepare(
        "SELECT UserID, Username, Role, PasswordHash
         FROM Users
         WHERE UserID=?
         LIMIT 1"
      );
      $stmt->bind_param("i", $uid);
      $stmt->execute();
      $userRow = $stmt->get_result()->fetch_assoc();

      if (!$userRow) {
        $msg = "User not found.";
      } elseif (!password_verify($current, $userRow['PasswordHash'])) {
        $msg = "Current password is incorrect.";
      } else {
        $newHash = password_hash($new1, PASSWORD_DEFAULT);
        $up = $databaseConnection->prepare(
          "UPDATE Users SET PasswordHash=? WHERE UserID=?"
        );
        $up->bind_param("si", $newHash, $uid);
        $up->execute();

        $msg = "Password updated successfully.";
      }
    }
  }
}

/* Fetch user profile data */
$stmt = $databaseConnection->prepare(
  "SELECT UserID, Username, Role
   FROM Users
   WHERE UserID=?
   LIMIT 1"
);
$stmt->bind_param("i", $uid);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if (!$user) {
  header("Location: login.php");
  exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>My Profile</title>
<style>
  body{font-family:Arial;background:#0b0b0d;color:#fff;margin:0}
  .wrap{width:1100px;margin:40px auto}
  .box{background:#121216;padding:20px;border-radius:14px;margin-bottom:18px;border:1px solid rgba(255,255,255,.12)}
  .btn-lite{display:inline-block;padding:10px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.12);color:#fff;text-decoration:none;background:transparent}
  input,button{padding:10px;border-radius:10px;border:none;outline:none}
  input{background:#0f0f13;color:#fff;border:1px solid rgba(255,255,255,.12);width:360px;max-width:100%}
  input:focus{border-color:rgba(215,25,32,.55)}
  button{cursor:pointer;background:#d71920;color:#fff;font-weight:700}
  .row{display:flex;gap:16px;flex-wrap:wrap}
  .label{color:#cfcfd4;font-size:13px;margin-bottom:6px}
  .value{font-weight:700}
  .msg{margin:0 0 14px;padding:10px 12px;border-radius:14px;border:1px solid rgba(215,25,32,.35);background:rgba(215,25,32,.10);font-size:13px;}
  .ok{border-color:rgba(46,160,67,.35);background:rgba(46,160,67,.12);}
</style>
</head>
<body>
<div class="wrap">

  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
    <h1 style="margin:0;">My Profile</h1>
    <a class="btn-lite" href="cashier.php">← Back</a>
  </div>

  <?php if ($msg !== ""): ?>
    <div class="msg <?= (stripos($msg, 'success') !== false) ? 'ok' : '' ?>">
      <?= htmlspecialchars($msg) ?>
    </div>
  <?php endif; ?>

  <div class="box">
    <h3 style="margin:0 0 10px;">Account Info</h3>

    <div class="row">
      <div>
        <div class="label">User ID</div>
        <div class="value"><?= (int)$user['UserID'] ?></div>
      </div>

      <div>
        <div class="label">Username</div>
        <div class="value"><?= htmlspecialchars($user['Username']) ?></div>
      </div>

      <div>
        <div class="label">Role</div>
        <div class="value"><?= htmlspecialchars($user['Role']) ?></div>
      </div>
    </div>
  </div>

  <?php if ($canChangePassword === 1): ?>
    <div class="box">
      <h3 style="margin:0 0 10px;">Change Password</h3>

      <form method="post" style="display:flex;flex-direction:column;gap:10px;max-width:420px;">
        <div>
          <div class="label">Current Password</div>
          <input type="password" name="current_password" required>
        </div>

        <div>
          <div class="label">New Password</div>
          <input type="password" name="new_password" required minlength="6">
        </div>

        <div>
          <div class="label">Confirm New Password</div>
          <input type="password" name="confirm_password" required minlength="6">
        </div>

        <div style="margin-top:6px;">
          <button type="submit" name="change_password">Update Password</button>
        </div>
      </form>
    </div>
  <?php else: ?>
    <div class="box">
      <h3 style="margin:0 0 10px;">Change Password</h3>
      <p style="color:#cfcfd4;margin:0;">
        You do not have permission to change your password. Please contact the administrator.
      </p>
    </div>
  <?php endif; ?>

</div>
</body>
</html>
