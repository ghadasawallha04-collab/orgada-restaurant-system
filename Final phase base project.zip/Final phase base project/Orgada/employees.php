<?php
session_start();
require_once "DB.php";
//Allow access only for admins
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}
$branchesRes=$databaseConnection->query("SELECT BranchID, BranchName FROM Branch ORDER BY BranchID");
// Add new employee and make account for him
if (isset($_POST['add_employee'])) {
  $firstName=trim($_POST['first_name'] ?? '');
  $lastName =trim($_POST['last_name'] ?? '');
  $position =trim($_POST['position'] ?? '');
  $hireDate =$_POST['hire_date'] ?? date('Y-m-d');
  $salary=($_POST['salary'] ?? 0);
  $phone=trim($_POST['phone'] ?? '');
  $branchId=(int)($_POST['branch_id'] ?? 0);
  $username =trim($_POST['username'] ?? '');
  $password=$_POST['password'] ?? '';
  $role=trim($_POST['role'] ?? 'employee');

  if ($firstName !== '' && $lastName !== '' && $position !== '' && $branchId > 0 && $salary>0 && $username !== '' && $password !== '') {
    $statement=$databaseConnection->prepare(
      "INSERT INTO Employee (BranchID, FirstName, LastName, Position, HireDate, Phone, Salary)
       VALUES (?, ?, ?, ?, ?, ?, ?)"
    );
    $statement->bind_param("isssssd", $branchId, $firstName, $lastName, $position, $hireDate, $phone, $salary);
    $statement->execute();
    $employeeId=$databaseConnection->insert_id;
    $hash=password_hash($password, PASSWORD_BCRYPT);
    $statement2=$databaseConnection->prepare(
      "INSERT INTO Users (Username, PasswordHash, Role, EmployeeID)
       VALUES (?, ?, ?, ?)"
    );
    $statement2->bind_param("sssi", $username, $hash, $role, $employeeId);
    $statement2->execute();
  }

  header("Location: employees.php");
  exit;
}

//Delete Employee
if (isset($_POST['delete_employee'])) {
  $id = (int)($_POST['employee_id'] ?? 0);
  if ($id > 0) {
    $statement = $databaseConnection->prepare("DELETE FROM Users WHERE EmployeeID = ?");
    $statement->bind_param("i", $id);
    $statement->execute();
    $statement2 = $databaseConnection->prepare("DELETE FROM Employee WHERE EmployeeID = ?");
    $statement2->bind_param("i", $id);
    $statement2->execute();
  }

  header("Location: employees.php");
  exit;
}

$editRow = null;
if (isset($_GET['edit'])) {
  $id = (int)$_GET['edit'];
  $statement = $databaseConnection->prepare(
    "SELECT e.EmployeeID, e.BranchID, e.FirstName, e.LastName, e.Position, e.HireDate, e.Phone, e.Salary,
            u.Username, u.Role
     FROM Employee e
     LEFT JOIN Users u ON u.EmployeeID = e.EmployeeID
     WHERE e.EmployeeID = ? LIMIT 1"
  );
  $statement->bind_param("i", $id);
  $statement->execute();
  $editRow=$statement->get_result()->fetch_assoc();
}

//Update employee information
if (isset($_POST['update_employee'])) {
  $id=(int)($_POST['employee_id'] ?? 0);
  $firstName=trim($_POST['first_name'] ?? '');
  $lastName=trim($_POST['last_name'] ?? '');
  $position=trim($_POST['position'] ?? '');
  $hireDate=$_POST['hire_date'] ?? date('Y-m-d');
  $salary=(float)($_POST['salary'] ?? 0);
  $phone=trim($_POST['phone'] ?? '');
  $branchId=(int)($_POST['branch_id'] ?? 0);
  $username=trim($_POST['username'] ?? '');
  $role=trim($_POST['role'] ?? 'employee');
  $newPass=$_POST['password'] ?? '';
  if ($id > 0 && $firstName !== '' && $lastName !== '' && $position !== '' && $branchId > 0 && $username !== '') {
    $statement = $databaseConnection->prepare(
      "UPDATE Employee
       SET BranchID=?, FirstName=?, LastName=?, Position=?, HireDate=?, Phone=?, Salary=?
       WHERE EmployeeID=?"
    );
    $statement->bind_param("isssssdi", $branchId, $firstName, $lastName, $position, $hireDate, $phone, $salary, $id);
    $statement->execute();
    if ($newPass !== '') {
      $hash=password_hash($newPass, PASSWORD_BCRYPT);
      $statement2 = $databaseConnection->prepare(
        "UPDATE Users SET Username=?, PasswordHash=?, Role=? WHERE EmployeeID=?"
      );
      $statement2->bind_param("sssi", $username, $hash, $role, $id);
      $statement2->execute();
    } else {
      $statement2 = $databaseConnection->prepare(
        "UPDATE Users SET Username=?, Role=? WHERE EmployeeID=?"
      );
      $statement2->bind_param("ssi", $username, $role, $id);
      $statement2->execute();
    }
  }
  header("Location: employees.php");
  exit;
}
//filter employee by branch
$branchFilter=$_GET['branch_id'] ?? '';
if ($branchFilter !== '') {
  $statement=$databaseConnection->prepare(
    "SELECT e.EmployeeID, e.FirstName, e.LastName, e.Position, e.Salary, e.Phone, e.HireDate,
            b.BranchName, u.Username, u.Role
     FROM Employee e
     JOIN Branch b ON b.BranchID = e.BranchID
     LEFT JOIN Users u ON u.EmployeeID = e.EmployeeID
     WHERE e.BranchID = ?
     ORDER BY e.EmployeeID"
  );
  $statement->bind_param("i", $branchFilter);
  $statement->execute();
  $employees = $statement->get_result();
} 
else {
  $employees=$databaseConnection->query(
    "SELECT e.EmployeeID, e.FirstName, e.LastName, e.Position, e.Salary, e.Phone, e.HireDate,
            b.BranchName, u.Username, u.Role
     FROM Employee e
     LEFT JOIN Branch b ON b.BranchID = e.BranchID
     LEFT JOIN Users u ON u.EmployeeID = e.EmployeeID
     ORDER BY e.EmployeeID"
  );
}
?>
<!-- HTML&CSS Codes-->
<!doctype html>
<html>
<head>
  <title>Admin | Employee Page</title>
  <style>
    body{
      font-family:Arial;
      background:#0b0b0d;
      color:#fff;
      margin:0;
    }
    .wrap{
      width:1100px;
      margin:40px auto;
    }
    .top{
      display:flex;
      justify-content:space-between;
      align-items:center;
      margin-bottom:12px;
    }
    .box{
      background:#121216;
      padding:20px;
      border-radius:14px;
      margin-bottom:18px;
      border:1px solid rgba(255,255,255,.12);
    }
    table{
      width:100%;
      border-collapse:collapse;
      margin-top:14px;
    }
    th,td{
      padding:10px;
      border-bottom:1px solid #333;
      text-align:left;
    }
    th{
      color:#cfcfd4;
    }
    input,select,button{
      padding:8px;
      border-radius:8px;
      border:none;
      margin:4px;
      outline:none;
    }
    input{
      width:190px;
    }
    select{
      width:210px;
    }
    button{
      cursor:pointer;
      background:#d71920;
      color:#fff;
      font-weight:700;
    }
    .btn-lite{
      background:transparent;
      border:1px solid rgba(255,255,255,.12);
      color:#fff;
      display:inline-block;
      padding:8px 14px;
      border-radius:10px;
    }
    .danger{
      background:#ff4d4d;
    }
    .row-actions{
      display:flex;
      gap:8px;
      align-items:center;
    }
  </style>
</head>
<body>
<div class="wrap">
  <div class="top">
    <h1 style="margin:0;">Employees Management</h1>
    <a href="admin.php" class="btn-lite">← Back to Dashboard</a>
  </div>
  <div class="box">
    <h3 style="margin:0 0 10px;"><?= $editRow ? "Edit Employee" : "Add New Employee" ?></h3>
    <form method="post">
      <?php if ($editRow): ?>
        <input type="hidden" name="employee_id" value="<?= (int)$editRow['EmployeeID'] ?>">
      <?php endif; ?>
      <input name="first_name" placeholder="First Name" required value="<?= $editRow['FirstName'] ?? '' ?>">
      <input name="last_name" placeholder="Last Name" required value="<?= $editRow['LastName'] ?? '' ?>">
      <input name="position" placeholder="Position" required value="<?= $editRow['Position'] ?? '' ?>">
      <input type="date" name="hire_date" required value="<?= $editRow['HireDate'] ?? date('Y-m-d') ?>">
      <input name="phone" placeholder="Phone" value="<?= $editRow['Phone'] ?? '' ?>">
      <input type="number" step="0.01" name="salary" placeholder="Salary" value="<?= $editRow['Salary'] ?? 0 ?>">
      <select name="branch_id" required>
        <option value="">Select Branch</option>
        <?php
          $brRes = $databaseConnection->query("SELECT BranchID, BranchName FROM Branch ORDER BY BranchID");
          while ($b = $brRes->fetch_assoc()):
            $bid = (int)$b['BranchID'];
            $selected = ($editRow && (int)$editRow['BranchID'] === $bid) ? 'selected' : '';
        ?>
          <option value="<?= $bid ?>" <?= $selected ?>><?= $b['BranchName'] ?></option>
        <?php endwhile; ?>
      </select>
      <input name="username" placeholder="Username" required value="<?= $editRow['Username'] ?? '' ?>">
      <input name="password" type="password" placeholder="<?= $editRow ? 'New Password (optional)' : 'Password' ?>" <?= $editRow ? '' : 'required' ?>>
      <select name="role">
        <option value="employee" <?= ($editRow && ($editRow['Role'] ?? '') === 'employee') ? 'selected' : '' ?>>employee</option>
        <option value="admin" <?= ($editRow && ($editRow['Role'] ?? '') === 'admin') ? 'selected' : '' ?>>admin</option>
      </select>
      <?php if ($editRow): ?>
        <button type="submit" name="update_employee">Update</button>
        <a class="btn-lite" href="employees.php" style="padding:8px 12px;">Cancel</a>
      <?php else: ?>
        <button type="submit" name="add_employee">Add</button>
      <?php endif; ?>
    </form>
  </div>
  <div class="box">
    <h3 style="margin:0 0 10px;">Filter by Branch</h3>
    <form method="get">
      <select name="branch_id">
        <option value="">All Branches</option>
        <?php
          $brRes2 = $databaseConnection->query("SELECT BranchID, BranchName FROM Branch ORDER BY BranchID");
          while ($b = $brRes2->fetch_assoc()):
            $bid = (int)$b['BranchID'];
            $sel = ((string)$branchFilter === (string)$bid) ? 'selected' : '';
        ?>
          <option value="<?= $bid ?>" <?= $sel ?>><?= $b['BranchName'] ?></option>
        <?php endwhile; ?>
      </select>
      <button type="submit">Search</button>
      <a class="btn-lite" href="employees.php" style="padding:8px 12px;">Reset</a>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Employees List</h3>
    <table>
      <tr>
        <th>ID</th>
        <th>Name</th>
        <th>Branch</th>
        <th>Position</th>
        <th>Salary</th>
        <th>Phone</th>
        <th>Username</th>
        <th>Role</th>
        <th>Action</th>
      </tr>
      <?php while ($row = $employees->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['EmployeeID'] ?></td>
          <td><?= $row['FirstName'] . " " . $row['LastName'] ?></td>
          <td><?= $row['BranchName'] ?? '' ?></td>
          <td><?= $row['Position'] ?></td>
          <td><?= $row['Salary'] ?></td>
          <td><?= $row['Phone'] ?></td>
          <td><?= $row['Username'] ?? '' ?></td>
          <td><?= $row['Role'] ?? '' ?></td>
          <td class="row-actions">
            <a class="btn-lite" href="employees.php?edit=<?= (int)$row['EmployeeID'] ?>">Edit</a>

            <form method="post" onsubmit="return confirm('Delete this employee?');" style="margin:0;">
              <input type="hidden" name="employee_id" value="<?= (int)$row['EmployeeID'] ?>">
              <button class="danger" type="submit" name="delete_employee">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

</div>
</body>
</html>
