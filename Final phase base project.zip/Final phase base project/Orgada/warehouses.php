<?php
session_start();
//Allow access only for admins
require_once "DB.php";
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}
//Add new warehouse
if (isset($_POST['add_warehouse'])) {
  $name = trim($_POST['warehouse_name'] ?? '');

  if ($name !== '') {
    $stmt = $databaseConnection->prepare(
      "INSERT INTO Warehouse (WarehouseName) VALUES (?)"
    );
    $stmt->bind_param("s", $name);
    $stmt->execute();
  }

  header("Location: warehouses.php");
  exit;
}
// Delete Existing Warehouse
if (isset($_POST['delete_warehouse'])) {
  $id = (int)($_POST['warehouse_id'] ?? 0);

  if ($id > 0) {
    $chk1 = $databaseConnection->prepare(
      "SELECT COUNT(*) AS c FROM Purchase WHERE warehouseId=?"
    );
    $chk1->bind_param("i", $id);
    $chk1->execute();
    $c1=(int)($chk1->get_result()->fetch_assoc()['c'] ?? 0);

    $chk2=$databaseConnection->prepare(
      "SELECT COUNT(*) AS c FROM StockMovement WHERE WarehouseID=?"
    );
    $chk2->bind_param("i", $id);
    $chk2->execute();
    $c2 = (int)($chk2->get_result()->fetch_assoc()['c'] ?? 0);

    if ($c1 > 0 || $c2 > 0) {
      header("Location: warehouses.php?msg=used");
      exit;
    }

    $stmt = $databaseConnection->prepare(
      "DELETE FROM Warehouse WHERE WarehouseID=?"
    );
    $stmt->bind_param("i", $id);
    $stmt->execute();
  }

  header("Location: warehouses.php");
  exit;
}
//Search for warehouse
$search = trim($_GET['search'] ?? '');

if ($search !== '') {
  $like = "%" . $search . "%";
  $stmt = $databaseConnection->prepare(
    "SELECT * FROM Warehouse WHERE WarehouseName LIKE ? ORDER BY WarehouseID"
  );
  $stmt->bind_param("s", $like);
  $stmt->execute();
  $warehouses = $stmt->get_result();
} else {
  $warehouses = $databaseConnection->query(
    "SELECT * FROM Warehouse ORDER BY WarehouseID"
  );
}
?>
<!--HTML&CSS Codes-->
<!doctype html>
<html>
<head>
  <title>Admin | Warehouses</title>
  <style>
    body{
        font-family:Arial;
        background:#0b0b0d;
        color:#fff;
        margin:0;
    }
    .wrap{
        width:1100px;
        margin:40px auto;
    }
    h1{
        margin:0 0 10px;
    }
    .box{
        background:#121216;
        padding:20px;
        border-radius:14px;
        margin-bottom:18px;
        border:1px solid rgba(255,255,255,.12);
    }
    table{
        width:100%;
        border-collapse:collapse;
        margin-top:14px;
    }
    th,td{
        padding:10px;
        border-bottom:1px solid #333;
        text-align:left;
    }

    th{
        color:#cfcfd4;
    }
    input,button{
        padding:8px;
        border-radius:8px;
        border:none;
        margin:4px;
        outline:none;
    }
    input{
        width:260px;
    }
    button{
        cursor:pointer;
        background:#d71920;
        color:#fff;
        font-weight:700;
    }
    .btn-lite{
        background:transparent;
        border:1px solid rgba(255,255,255,.12);
        color:#fff;
        display:inline-block;
        padding:8px 14px;
        border-radius:10px;
    }

    .danger{
        background:#ff4d4d;
    }
    .row-actions{
        display:flex;
        gap:8px;
        align-items:center;
    }
  </style>
</head>
<body>
<div class="wrap">

  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
    <h1 style="margin:0;">Warehouses Management</h1>
    <a href="admin.php" class="btn-lite">← Back to Dashboard</a>
  </div>

  <?php if (isset($_GET['msg']) && $_GET['msg']==='used'): ?>
    <div class="box" style="border-color:rgba(215,25,32,.35);background:rgba(215,25,32,.10);">
      This warehouse cannot be deleted because it is linked to purchases or stock movements.
    </div>
  <?php endif; ?>

  <div class="box">
    <h3 style="margin:0 0 10px;">Add New Warehouse</h3>
    <form method="post">
      <input name="warehouse_name" placeholder="Warehouse Name" required>
      <button type="submit" name="add_warehouse">Add Warehouse</button>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Search Warehouse</h3>
    <form method="get" style="display:flex;flex-wrap:wrap;align-items:center;gap:6px;">
      <input name="search" placeholder="Search by name" value="<?= htmlspecialchars($search) ?>">
      <button type="submit">Search</button>
      <a class="btn-lite" href="warehouses.php" style="padding:8px 12px;">Reset</a>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Warehouses List</h3>

    <table>
      <tr>
        <th>ID</th>
        <th>Warehouse Name</th>
        <th>Action</th>
      </tr>

      <?php while ($row = $warehouses->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['WarehouseID'] ?></td>
          <td><?= htmlspecialchars($row['WarehouseName']) ?></td>
          <td>
            <form method="post" class="row-actions" onsubmit="return confirm('Delete this warehouse?');">
              <input type="hidden" name="warehouse_id" value="<?= (int)$row['WarehouseID'] ?>">
              <button class="danger" type="submit" name="delete_warehouse">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>

  </div>

</div>
</body>
</html>
