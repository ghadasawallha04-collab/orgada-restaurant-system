<?php
session_start();

function require_cashier() {
  if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: login.php");
    exit;
  }
  if (strtolower($_SESSION['role']) === 'admin') {
    header("Location: admin.php");
    exit;
  }
}

function require_perm($permKey) {
  require_cashier();
  $allowed = (int)($_SESSION[$permKey] ?? 0);
  if ($allowed !== 1) {
    header("Location: cashier.php?msg=forbidden");
    exit;
  }
}
