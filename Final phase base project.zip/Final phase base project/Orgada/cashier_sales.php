<?php
session_start();
require_once "DB.php";

/* Cashier only (non-admin) */
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || strtolower($_SESSION['role']) === 'admin') {
  header("Location: login.php");
  exit;
}

$uid = (int)$_SESSION['user_id'];

$stmt = $databaseConnection->prepare(
  "SELECT SaleID, SaleDate, TotalAmount
   FROM Sale
   WHERE CreatedBy=?
   ORDER BY SaleID DESC"
);
$stmt->bind_param("i", $uid);
$stmt->execute();
$sales = $stmt->get_result();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>My Sales</title>
<style>
  body{font-family:Arial;background:#0b0b0d;color:#fff;margin:0}
  .wrap{width:1100px;margin:40px auto}
  .box{background:#121216;padding:20px;border-radius:14px;margin-bottom:18px;border:1px solid rgba(255,255,255,.12)}
  table{width:100%;border-collapse:collapse;margin-top:12px}
  th,td{padding:10px;border-bottom:1px solid #333;text-align:left}
  th{color:#cfcfd4}
  .btn-lite{display:inline-block;padding:10px 14px;border-radius:10px;border:1px solid rgba(255,255,255,.12);color:#fff;text-decoration:none}
  .msg{margin:0 0 14px;padding:10px 12px;border-radius:14px;border:1px solid rgba(46,160,67,.35);background:rgba(46,160,67,.12);font-size:13px;}
</style>
</head>
<body>
<div class="wrap">

  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
    <h1 style="margin:0;">My Sales</h1>
    <a class="btn-lite" href="cashier.php">← Back</a>
  </div>

  <?php if (isset($_GET['msg']) && $_GET['msg']==='done'): ?>
    <div class="msg">Sale saved successfully.</div>
  <?php endif; ?>

  <div class="box">
    <table>
      <tr><th>ID</th><th>Date</th><th>Total</th><th>Action</th></tr>
      <?php while ($s = $sales->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$s['SaleID'] ?></td>
          <td><?= htmlspecialchars($s['SaleDate']) ?></td>
          <td><?= number_format((float)$s['TotalAmount'],2) ?></td>
          <td>
            <a class="btn-lite" href="invoice.php?id=<?= (int)$s['SaleID'] ?>">View</a>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

</div>
</body>
</html>
