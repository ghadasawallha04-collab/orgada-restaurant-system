<?php
session_start();
require_once "DB.php";
//Allow access only for admins
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}
//Add new branch
if (isset($_POST['add_branch'])) {
  $name=trim($_POST['branch_name'] ?? '');
  $city=trim($_POST['city'] ?? '');
  $address=trim($_POST['address'] ?? '');
  $phone=trim($_POST['phone'] ?? '');

  if ($name !== '' && $city !== '' && $address !== '') {
    $statment=$databaseConnection->prepare(
      "INSERT INTO Branch (BranchName, City, Address, Phone) VALUES (?, ?, ?, ?)"
    );
    $statment->bind_param("ssss", $name, $city, $address, $phone);
    $statment->execute();
  }
  header("Location: branches.php");
  exit;
}
//Delete existing branch with all relevent information
if (isset($_POST['delete_branch'])) {
  $id=(int)($_POST['branch_id'] ?? 0);

  if ($id>0) {
    $statment=$databaseConnection->prepare("DELETE FROM Branch WHERE BranchID=?");
    $statment->bind_param("i", $id);
    $statment->execute();
  }
  header("Location: branches.php");
  exit;
}
//Query 21: Filtering branch by city
$cityFilter=trim($_GET['city'] ?? '');
$citiesResult=$databaseConnection->query("SELECT DISTINCT City FROM Branch ORDER BY City");
if ($cityFilter !== '') {
  $statment=$databaseConnection->prepare("SELECT * FROM Branch WHERE City=? ORDER BY BranchName");
  $statment->bind_param("s", $cityFilter);
  $statment->execute();
  $branches=$statment->get_result();
} else {
  $branches=$databaseConnection->query("SELECT * FROM Branch ORDER BY BranchID");
}
?>
<!--HTML&CSS codes-->
<!doctype html>
<html>
<head>
  <title>Admin | Branches</title>
  <style>
    body{
      font-family:Arial;
      background:#0b0b0d;
      color:#fff;margin:0
    }
    .wrap{
      width:1100px;
      margin:40px auto;
    }
    h1{
      margin:0 0 10px;
    }
    .box{
      background:#121216;
      padding:20px;
      border-radius:14px;
      margin-bottom:18px;
      border:1px solid rgba(255,255,255,.12);
    }
    table{
      width:100%;
      border-collapse:collapse;
      margin-top:14px;
    }
    th,td{
      padding:10px; 
      border-bottom:1px solid #333;
      text-align:left;
    }

    th{
      color:#cfcfd4;
    }

    input,select,button{
      padding:8px;
      border-radius:8px;
      border:none;
      margin:4px;
      outline:none;
    }

    input{
      width:200px;
    }
    select{
      width:220px;
    }
    button{
      cursor:pointer;
      background:#d71920;
      color:#fff;
      font-weight:700;
    }
    .btn-lite{
      background:transparent;
      border:1px solid rgba(255,255,255,.12);
      color:#fff;
    }
    .row-actions{
      display:flex;
      gap:8px;
      align-items:center;
    }

    .danger{
      background:#ff4d4d;
    }
  </style>
</head>

<body>
<div class="wrap">
  <h1>Branches Management</h1>
  <div class="box">
    <h3 style="margin:0 0 10px;">Add New Branch</h3>
    <form method="post">
      <input name="branch_name" placeholder="Branch Name" required>
      <input name="city" placeholder="City" required>
      <input name="address" placeholder="Address" required>
      <input name="phone" placeholder="Phone">
      <button type="submit" name="add_branch">Add Branch</button>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Filter Branches by City</h3>
    <form method="get" style="display:flex;flex-wrap:wrap;align-items:center;gap:6px;">
      <select name="city">
        <option value="">All Cities</option>
        <?php while($c = $citiesResult->fetch_assoc()): ?>
          <?php $cityVal = $c['City']; ?>
          <option value="<?= $cityVal ?>" <?= ($cityFilter === $cityVal) ? 'selected' : '' ?>>
            <?= $cityVal ?>
          </option>
        <?php endwhile; ?>
      </select>
      <button type="submit">Search</button>
      <a class="btn-lite" href="branches.php" style="padding:8px 12px;border-radius:8px;display:inline-block;">Reset</a>
    </form>
  </div>
  
  <div class="box">
    <h3 style="margin:0 0 10px;">Branches List</h3>

    <table>
      <tr>
        <th>ID</th>
        <th>Branch Name</th>
        <th>City</th>
        <th>Address</th>
        <th>Phone</th>
        <th>Action</th>
      </tr>

      <?php while ($row = $branches->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['BranchID'] ?></td>
          <td><?= $row['BranchName'] ?></td>
          <td><?= $row['city'] ?></td>
          <td><?= $row['Address'] ?></td>
          <td><?= $row['phone'] ?? '' ?></td>
          <td>
            <form method="post" class="row-actions" onsubmit="return confirm('Delete this branch?');">
              <input type="hidden" name="branch_id" value="<?= (int)$row['BranchID'] ?>">
              <button class="danger" type="submit" name="delete_branch">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>
<div style="margin-top:20px;">
  <a href="admin.php" class="btn-lite" style="padding:8px 14px; border-radius:10px;">
    Back to Dashboard
  </a>
</div>

</div>
</body>
</html>
