<?php
session_start();
require_once "DB.php";
//Allow admin access only
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}

//Add ingredients
if (isset($_POST['add_ingredient'])) {
  $name = trim($_POST['ingredient_name'] ?? '');
  $unit = trim($_POST['unit'] ?? '');

  if ($name !== '' && $unit !== '') {
    $stmt = $databaseConnection->prepare(
      "INSERT INTO Ingredient (IngredientName, Unit) VALUES (?, ?)"
    );
    $stmt->bind_param("ss", $name, $unit);
    $stmt->execute();
  }

  header("Location: ingredients.php");
  exit;
}

//Delete Ingredients
if (isset($_POST['delete_ingredient'])) {
  $id = (int)($_POST['ingredient_id'] ?? 0);

  if ($id > 0) {
    $chk1 = $databaseConnection->prepare("SELECT COUNT(*) c FROM RecipeIngredient WHERE IngredientID=?");
    $chk1->bind_param("i", $id);
    $chk1->execute();
    $c1 = (int)($chk1->get_result()->fetch_assoc()['c'] ?? 0);

    $chk2 = $databaseConnection->prepare("SELECT COUNT(*) c FROM PurchaseItem WHERE IngredientID=?");
    $chk2->bind_param("i", $id);
    $chk2->execute();
    $c2 = (int)($chk2->get_result()->fetch_assoc()['c'] ?? 0);

    $chk3 = $databaseConnection->prepare("SELECT COUNT(*) c FROM StockMovement WHERE IngredientID=?");
    $chk3->bind_param("i", $id);
    $chk3->execute();
    $c3 = (int)($chk3->get_result()->fetch_assoc()['c'] ?? 0);

    if (($c1 + $c2 + $c3) > 0) {
      header("Location: ingredients.php?msg=used");
      exit;
    }

    $statement=$databaseConnection->prepare("DELETE FROM Ingredient WHERE IngredientID=?");
    $statement->bind_param("i", $id);
    $statement->execute();
  }

  header("Location: ingredients.php");
  exit;
}

//Edit ingredient
$editRow = null;
if (isset($_GET['edit'])) {
  $id = (int)$_GET['edit'];
  if ($id > 0) {
    $statement=$databaseConnection->prepare("SELECT * FROM Ingredient WHERE IngredientID=? LIMIT 1");
    $statement->bind_param("i", $id);
    $statement->execute();
    $editRow=$statement->get_result()->fetch_assoc();
  }
}
if (isset($_POST['update_ingredient'])) {
  $id=(int)($_POST['ingredient_id'] ?? 0);
  $name=trim($_POST['ingredient_name'] ?? '');
  $unit=trim($_POST['unit'] ?? '');

  if ($id > 0 && $name !== '' && $unit !== '') {
    $statement=$databaseConnection->prepare(
      "UPDATE Ingredient SET IngredientName=?, Unit=? WHERE IngredientID=?"
    );
    $statement->bind_param("ssi", $name, $unit, $id);
    $statement->execute();
  }

  header("Location: ingredients.php");
  exit;
}

//Filtaring using unit
$unitFilter = trim($_GET['unit'] ?? '');
$unitsRes = $databaseConnection->query("SELECT DISTINCT Unit FROM Ingredient ORDER BY Unit");
if ($unitFilter !== '') {
  $statement=$databaseConnection->prepare("SELECT * FROM Ingredient WHERE Unit=? ORDER BY IngredientName");
  $statement->bind_param("s", $unitFilter);
  $statement->execute();
  $ingredients=$statement->get_result();
} 
else {
  $ingredients=$databaseConnection->query("SELECT * FROM Ingredient ORDER BY IngredientID DESC");
}
?>
<!--HTML&CSS codes-->
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Admin | Ingredients</title>
  <style>
  body {
    font-family: Arial;
    background: #0b0b0d;
    color: #fff;
    margin: 0;
  }

  .wrap {
    width: 1100px;
    margin: 40px auto;
  }

  .top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
  }

  .box {
    background: #121216;
    padding: 20px;
    border-radius: 14px;
    margin-bottom: 18px;
    border: 1px solid rgba(255, 255, 255, 0.12);
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 14px;
  }

  th,
  td {
    padding: 10px;
    border-bottom: 1px solid #333;
    text-align: left;
  }

  th {
    color: #cfcfd4;
  }

  input,
  select,
  button {
    padding: 8px;
    border-radius: 8px;
    border: none;
    margin: 4px;
    outline: none;
  }

  input {
    width: 220px;
  }

  select {
    width: 220px;
  }

  button {
    cursor: pointer;
    background: #d71920;
    color: #fff;
    font-weight: 700;
  }

  .btn-lite {
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.12);
    color: #fff;
    display: inline-block;
    padding: 8px 14px;
    border-radius: 10px;
  }

  .danger {
    background: #ff4d4d;
  }

  .row-actions {
    display: flex;
    gap: 8px;
    align-items: center;
  }
</style>

</head>
<body>
<div class="wrap">

  <div class="top">
    <h1 style="margin:0;">Ingredients Management</h1>
    <a href="admin.php" class="btn-lite">← Back to Dashboard</a>
  </div>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'used'): ?>
    <div class="box" style="border-color:rgba(215,25,32,.35);background:rgba(215,25,32,.10);">
      This ingredient cannot be deleted because it is used in Recipes/Purchases/Stock Movements.
    </div>
  <?php endif; ?>

  <div class="box">
    <h3 style="margin:0 0 10px;"><?= $editRow ? "Edit Ingredient" : "Add New Ingredient" ?></h3>
    <form method="post">
      <?php if ($editRow): ?>
        <input type="hidden" name="ingredient_id" value="<?= (int)$editRow['IngredientID'] ?>">
      <?php endif; ?>

      <input name="ingredient_name" placeholder="Ingredient Name" required value="<?= htmlspecialchars($editRow['IngredientName'] ?? '') ?>">
      <input name="unit" placeholder="Unit (pcs, kg, ml...)" required value="<?= htmlspecialchars($editRow['Unit'] ?? '') ?>">

      <?php if ($editRow): ?>
        <button type="submit" name="update_ingredient">Update</button>
        <a class="btn-lite" href="ingredients.php" style="padding:8px 12px;">Cancel</a>
      <?php else: ?>
        <button type="submit" name="add_ingredient">Add</button>
      <?php endif; ?>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Filter by Unit</h3>
    <form method="get">
      <select name="unit">
        <option value="">All Units</option>
        <?php while($u = $unitsRes->fetch_assoc()): ?>
          <?php $val = $u['Unit']; ?>
          <option value="<?= htmlspecialchars($val) ?>" <?= ($unitFilter === $val) ? 'selected' : '' ?>>
            <?= htmlspecialchars($val) ?>
          </option>
        <?php endwhile; ?>
      </select>
      <button type="submit">Search</button>
      <a class="btn-lite" href="ingredients.php" style="padding:8px 12px;">Reset</a>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Ingredients List</h3>

    <table>
      <tr>
        <th>ID</th>
        <th>Ingredient</th>
        <th>Unit</th>
        <th>Action</th>
      </tr>

      <?php while ($row = $ingredients->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['IngredientID'] ?></td>
          <td><?= htmlspecialchars($row['IngredientName']) ?></td>
          <td><?= htmlspecialchars($row['Unit']) ?></td>
          <td class="row-actions">
            <a class="btn-lite" href="ingredients.php?edit=<?= (int)$row['IngredientID'] ?>">Edit</a>

            <form method="post" onsubmit="return confirm('Delete this ingredient?');" style="margin:0;">
              <input type="hidden" name="ingredient_id" value="<?= (int)$row['IngredientID'] ?>">
              <button class="danger" type="submit" name="delete_ingredient">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

</div>
</body>
</html>
