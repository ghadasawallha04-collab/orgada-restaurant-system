<?php
session_start();
require_once "DB.php";
//Allow admin access only
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}
//Add new category
if (isset($_POST['add_category'])) {
  $name=trim($_POST['category_name'] ?? '');
  if ($name !== '') {
    $statement = $databaseConnection->prepare(
      "INSERT INTO Category (CategoryName) VALUES (?)"
    );
    $statement->bind_param("s", $name);
    $statement->execute();
  }
  header("Location: categories.php");
  exit;
}

//Delete existing category
if (isset($_POST['delete_category'])) {
  $id=(int)($_POST['category_id'] ?? 0);
  if ($id > 0) {
    $chk = $databaseConnection->prepare("SELECT COUNT(*) c FROM MenuItem WHERE CategoryID=?");
    $chk->bind_param("i", $id);
    $chk->execute();
    $c = (int)($chk->get_result()->fetch_assoc()['c'] ?? 0);
    if ($c > 0) {
      header("Location: categories.php?msg=used");
      exit;
    }
    $statement = $databaseConnection->prepare("DELETE FROM Category WHERE CategoryID=?");
    $statement->bind_param("i", $id);
    $statement->execute();
  }
  header("Location: categories.php");
  exit;
}
//Edit category Name
$editRow=null;
if (isset($_GET['edit'])) {
  $id = (int)$_GET['edit'];
  if ($id > 0) {
    $statement = $databaseConnection->prepare("SELECT * FROM Category WHERE CategoryID=? LIMIT 1");
    $statement->bind_param("i", $id);
    $statement->execute();
    $editRow=$statement->get_result()->fetch_assoc();
  }
}
if (isset($_POST['update_category'])) {
  $id = (int)($_POST['category_id'] ?? 0);
  $name = trim($_POST['category_name'] ?? '');
  if ($id > 0 && $name !== '') {
    $statement = $databaseConnection->prepare(
      "UPDATE Category SET CategoryName=? WHERE CategoryID=?"
    );
    $statement->bind_param("si", $name, $id);
    $statement->execute();
  }
  header("Location: categories.php");
  exit;
}
$categories=$databaseConnection->query("SELECT * FROM Category ORDER BY CategoryID DESC");
?>
<!--HTML&CSS Codes-->
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Admin | Categories</title>
<style>
  body {
    font-family: Arial;
    background: #0b0b0d;
    color: #fff;
    margin: 0;
  }

  .wrap {
    width: 1100px;
    margin: 40px auto;
  }

  .top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 12px;
  }

  .box {
    background: #121216;
    padding: 20px;
    border-radius: 14px;
    margin-bottom: 18px;
    border: 1px solid rgba(255, 255, 255, 0.12);
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 14px;
  }

  th,
  td {
    padding: 10px;
    border-bottom: 1px solid #333;
    text-align: left;
  }

  th {
    color: #cfcfd4;
  }

  input,
  button {
    padding: 8px;
    border-radius: 8px;
    border: none;
    margin: 4px;
    outline: none;
  }

  input {
    width: 340px;
  }

  button {
    cursor: pointer;
    background: #d71920;
    color: #fff;
    font-weight: 700;
  }

  .btn-lite {
    background: transparent;
    border: 1px solid rgba(255, 255, 255, 0.12);
    color: #fff;
    display: inline-block;
    padding: 8px 14px;
    border-radius: 10px;
  }

  .danger {
    background: #ff4d4d;
  }

  .row-actions {
    display: flex;
    gap: 8px;
    align-items: center;
  }
</style>

</head>
<body>
<div class="wrap">

  <div class="top">
    <h1 style="margin:0;">Categories</h1>
    <a href="admin.php" class="btn-lite">← Back to Dashboard</a>
  </div>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'used'): ?>
    <div class="box" style="border-color:rgba(215,25,32,.35);background:rgba(215,25,32,.10);">
      This category cannot be deleted because it is used in Menu Items.
    </div>
  <?php endif; ?>

  <div class="box">
    <h3 style="margin:0 0 10px;"><?= $editRow ? "Edit Category" : "Add New Category" ?></h3>

    <form method="post">
      <?php if ($editRow): ?>
        <input type="hidden" name="category_id" value="<?= (int)$editRow['CategoryID'] ?>">
      <?php endif; ?>

      <input name="category_name" placeholder="Category Name" required value="<?= htmlspecialchars($editRow['CategoryName'] ?? '') ?>">

      <?php if ($editRow): ?>
        <button type="submit" name="update_category">Update</button>
        <a class="btn-lite" href="categories.php" style="padding:8px 12px;">Cancel</a>
      <?php else: ?>
        <button type="submit" name="add_category">Add</button>
      <?php endif; ?>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Categories List</h3>

    <table>
      <tr>
        <th>ID</th>
        <th>Category Name</th>
        <th>Action</th>
      </tr>

      <?php while($row = $categories->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['CategoryID'] ?></td>
          <td><?= htmlspecialchars($row['CategoryName']) ?></td>
          <td class="row-actions">
            <a class="btn-lite" href="categories.php?edit=<?= (int)$row['CategoryID'] ?>">Edit</a>

            <form method="post" onsubmit="return confirm('Delete this category?');" style="margin:0;">
              <input type="hidden" name="category_id" value="<?= (int)$row['CategoryID'] ?>">
              <button class="danger" type="submit" name="delete_category">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

</div>
</body>
</html>
