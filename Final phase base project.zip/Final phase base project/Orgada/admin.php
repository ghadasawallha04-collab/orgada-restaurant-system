<?php
session_start();
//Allow access only for admins
if(!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin'){
  header("Location: login.php");
  exit;
}
?>
<!--HTML&CSS Codes-->
<!doctype html>
<html>
<head>
  <title>Orgada | Admin Dashboard</title>
  <style>
    *{
      box-sizing:border-box;
    }
    body{
      margin:0;
      font-family:Arial, sans-serif;
      background:#0b0b0d;
      color:#ffffff;
    }

    a{
      color:inherit;
      text-decoration:none;
    }

    .wrap{
      width:1150px;
      margin:0 auto;
    }

    .nav{
      background:#0b0b0d;
      border-bottom:1px solid rgba(255,255,255,.12);
    }

    .nav-inner{
      display:flex;
      align-items:center;
      justify-content:space-between;
      padding:14px 0;
    }

    .brand{
      display:flex;
      align-items:center;
      gap:12px;
    }

    .brand img{
      width:46px;
      height:46px;
      border-radius:14px;
      background:#ffffff;
      object-fit:cover;
    }

    .brand b{
      font-size:16px;
    }

    .brand span{
      display:block;
      font-size:12px;
      color:#cfcfd4;
      margin-top:3px;
    }

    .nav-cta{
      display:flex;
      gap:10px;
      align-items:center;
    }


    .btn{
      padding:10px 14px;
      border-radius:14px;
      border:1px solid rgba(255,255,255,.12);
      font-weight:700;
      cursor:pointer;
      background:transparent;
      color:#ffffff;
      display:inline-block;
    }

    .btn.primary{
      background:#d71920;
      border:none;
    }
    .page{
      padding:50px 0;
    }

    .header-card{
      background:#121216;
      border:1px solid rgba(255,255,255,.12);
      border-radius:18px;
      padding:22px;
      box-shadow:0 18px 45px rgba(0,0,0,.45);
      margin-bottom:18px;
    }
    h1{
      margin:0 0 6px;
      font-size:26px;
    }
    p{
      margin:0;
      color:#cfcfd4;
      line-height:1.7;
      font-size:14px;
    }

    .grid{
      display:grid;
      grid-template-columns: repeat(3, 1fr);
      gap:14px;
    }
    .card{
      background:#121216;
      border:1px solid rgba(255,255,255,.12);
      border-radius:18px;
      padding:18px;
      box-shadow:0 18px 45px rgba(0,0,0,.45);
    }

    .card h3{
      margin:0 0 10px;
      font-size:16px;
    }

    .card p{
      margin:0 0 14px;
      font-size:13px;
      color:#cfcfd4;
    }

    .footer{
      text-align:center;
      font-size:12px;
      color:#cfcfd4;
      padding:30px 0;
    }
  </style>
</head>

<body>
<header class="nav">
  <div class="wrap nav-inner">
    <div class="brand">
      <img src="assets/logo.jpg" alt="Orgada Logo">
      <div>
        <b>ORGADA BURGERS</b>
      </div>
    </div>

    <div class="nav-cta">
      <a class="btn primary" href="logout.php">Logout</a>
    </div>
  </div>
</header>

<section class="page">
  <div class="wrap">
    <div class="header-card">
      <h1>Welcome <?php echo $_SESSION['username']; ?></h1>
      <p>This dashboard allows you to manage inventory, purchases, and menu items</p>
    </div>

    <div class="grid">
      <div class="card">
        <h3>Branches</h3>
        <p>Manage branch locations and details.</p>
        <a class="btn primary" href="branches.php">Open</a>
      </div>

      <div class="card">
        <h3>Employees</h3>
        <p>Add employees and manage roles.</p>
        <a class="btn primary" href="employees.php">Open</a>
      </div>

      <div class="card">
        <h3>Suppliers</h3>
        <p>Register suppliers for purchases and invoices.</p>
        <a class="btn primary" href="suppliers.php">Open</a>
      </div>

      <div class="card">
        <h3>Warehouses</h3>
        <p>Manage warehouses and storage locations.</p>
        <a class="btn primary" href="warehouses.php">Open</a>
      </div>

      <div class="card">
        <h3>Ingredients</h3>
        <p>Add ingredients and track stock basics.</p>
        <a class="btn primary" href="ingredients.php">Open</a>
      </div>

      <div class="card">
        <h3>Purchases</h3>
        <p>Create purchase and update stock on receive.</p>
        <a class="btn primary" href="purchases.php">Open</a>
      </div>

      <div class="card">
        <h3>Stock Movements</h3>
        <p>Track stock in/out adjustments and transfers.</p>
        <a class="btn primary" href="stockmovement.php">Open</a>
      </div>

      <div class="card">
        <h3>Menu & Categories</h3>
        <p>Manage categories, items, and pricing.</p>
        <a class="btn primary" href="categories.php">Categories</a>
        <a class="btn" href="menuitem.php" style="margin-left:8px;">Menu Items</a>
      </div>

      <div class="card">
        <h3>Recipes</h3>
        <p>Link menu items to ingredients and quantities.</p>
        <a class="btn primary" href="recipes.php">Recipes</a>
        <a class="btn" href="recipeingredients.php" style="margin-left:8px;">Ingredients</a>
      </div>

      <div class="card">
        <h3>Payment Methods</h3>
        <p>Update payment methods available in the system.</p>
        <a class="btn primary" href="paymentmethods.php">Open</a>
      </div>

      <div class="card">
        <h3>Delivery Companies</h3>
        <p>Manage delivery partners and service info.</p>
        <a class="btn primary" href="deliverycompanies.php">Open</a>
      </div>
      <div class="card">
        <h3>Reports</h3>
        <p>Manage delivery partners and service info.</p>
        <a class="btn primary" href="reports.php">Open</a>
      </div>

    </div>

    <footer class="footer">
      Copyright 2025 Orgada Burgers — Ghada1220064 - Malak1220203
    </footer>

  </div>
</section>

</body>
</html>
