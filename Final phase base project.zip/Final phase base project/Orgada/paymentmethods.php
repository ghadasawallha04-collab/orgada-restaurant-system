<!-- <?php
session_start();
require_once "DB.php";

if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}

if (isset($_POST['add_pm'])) {
  $name = trim($_POST['pm_name'] ?? '');
  if ($name !== '') {
    $stmt = $databaseConnection->prepare("INSERT INTO PaymentMethod (PaymentMethodName) VALUES (?)");
    $stmt->bind_param("s", $name);
    $stmt->execute();
  }
  header("Location: paymentmethods.php");
  exit;
}

if (isset($_POST['delete_pm'])) {
  $id = (int)($_POST['pm_id'] ?? 0);

  if ($id > 0) {
    $chk = $databaseConnection->prepare("SELECT COUNT(*) c FROM Orders WHERE paymentmethodID=?");
    $chk->bind_param("i", $id);
    $chk->execute();
    $c = (int)($chk->get_result()->fetch_assoc()['c'] ?? 0);

    if ($c > 0) {
      header("Location: paymentmethods.php?msg=used");
      exit;
    }

    $stmt = $databaseConnection->prepare("DELETE FROM PaymentMethod WHERE PaymentMethodID=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
  }

  header("Location: paymentmethods.php");
  exit;
}

$editRow = null;
if (isset($_GET['edit'])) {
  $id = (int)$_GET['edit'];
  $stmt = $databaseConnection->prepare("SELECT * FROM PaymentMethod WHERE PaymentMethodID=? LIMIT 1");
  $stmt->bind_param("i", $id);
  $stmt->execute();
  $editRow = $stmt->get_result()->fetch_assoc();
}

if (isset($_POST['update_pm'])) {
  $id = (int)($_POST['pm_id'] ?? 0);
  $name = trim($_POST['pm_name'] ?? '');

  if ($id > 0 && $name !== '') {
    $stmt = $databaseConnection->prepare("UPDATE PaymentMethod SET PaymentMethodName=? WHERE PaymentMethodID=?");
    $stmt->bind_param("si", $name, $id);
    $stmt->execute();
  }

  header("Location: paymentmethods.php");
  exit;
}

$methods = $databaseConnection->query("SELECT * FROM PaymentMethod ORDER BY PaymentMethodID DESC");
?>
<!doctype html>
<html>
<head>
  <meta charset="utf-8">
  <title>Admin | Payment Methods</title>
  <style>
    body{font-family:Arial;background:#0b0b0d;color:#fff;margin:0}
    .wrap{width:1100px;margin:40px auto}
    .top{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px}
    .box{background:#121216;padding:20px;border-radius:14px;margin-bottom:18px;border:1px solid rgba(255,255,255,.12)}
    table{width:100%;border-collapse:collapse;margin-top:14px}
    th,td{padding:10px;border-bottom:1px solid #333;text-align:left}
    th{color:#cfcfd4}
    input,button{padding:8px;border-radius:8px;border:none;margin:4px;outline:none}
    input{width:320px}
    button{cursor:pointer;background:#d71920;color:#fff;font-weight:700}
    .btn-lite{background:transparent;border:1px solid rgba(255,255,255,.12);color:#fff;display:inline-block;padding:8px 14px;border-radius:10px}
    .danger{background:#ff4d4d}
    .row-actions{display:flex;gap:8px;align-items:center}
  </style>
</head>
<body>
<div class="wrap">

  <div class="top">
    <h1 style="margin:0;">Payment Methods</h1>
    <a href="admin.php" class="btn-lite">← Back to Dashboard</a>
  </div>

  <?php if (isset($_GET['msg']) && $_GET['msg'] === 'used'): ?>
    <div class="box" style="border-color:rgba(215,25,32,.35);background:rgba(215,25,32,.10);">
      This payment method cannot be deleted because it is used in Orders.
    </div>
  <?php endif; ?>

  <div class="box">
    <h3 style="margin:0 0 10px;"><?= $editRow ? "Edit Payment Method" : "Add New Payment Method" ?></h3>

    <form method="post">
      <?php if ($editRow): ?>
        <input type="hidden" name="pm_id" value="<?= (int)$editRow['PaymentMethodID'] ?>">
      <?php endif; ?>

      <input name="pm_name" placeholder="Payment Method Name" required value="<?= htmlspecialchars($editRow['PaymentMethodName'] ?? '') ?>">

      <?php if ($editRow): ?>
        <button type="submit" name="update_pm">Update</button>
        <a class="btn-lite" href="paymentmethods.php" style="padding:8px 12px;">Cancel</a>
      <?php else: ?>
        <button type="submit" name="add_pm">Add</button>
      <?php endif; ?>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Payment Methods List</h3>
    <table>
      <tr>
        <th>ID</th>
        <th>Payment Method</th>
        <th>Action</th>
      </tr>

      <?php while($row = $methods->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$row['PaymentMethodID'] ?></td>
          <td><?= htmlspecialchars($row['PaymentMethodName']) ?></td>
          <td class="row-actions">
            <a class="btn-lite" href="paymentmethods.php?edit=<?= (int)$row['PaymentMethodID'] ?>">Edit</a>

            <form method="post" onsubmit="return confirm('Delete this payment method?');" style="margin:0;">
              <input type="hidden" name="pm_id" value="<?= (int)$row['PaymentMethodID'] ?>">
              <button class="danger" type="submit" name="delete_pm">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>
  </div>

</div>
</body>
</html> -->
