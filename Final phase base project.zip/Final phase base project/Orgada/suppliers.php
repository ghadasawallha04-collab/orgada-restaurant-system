<?php
session_start();
//Allow access only for admins
require_once "DB.php";
if (!isset($_SESSION['role']) || strtolower($_SESSION['role']) !== 'admin') {
  header("Location: login.php");
  exit;
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
//Add new supplier
  if (isset($_POST['add_supplier'])) {
    $supplierName=trim($_POST['supplier_name'] ?? '');
    $phone=trim($_POST['phone'] ?? '');
    $address=trim($_POST['address'] ?? '');
    if ($supplierName !== '') {
      $sql="INSERT INTO Supplier (SupplierName, Phone, Address) VALUES (?, ?, ?)";
      $statement = $databaseConnection->prepare($sql);
      $statement->bind_param("sss", $supplierName, $phone, $address);
      $statement->execute();
    }
    header("Location: suppliers.php");
    exit;
  }
  //Delete Existing supplier
  if (isset($_POST['delete_supplier'])) {
    $supplierId = (int)($_POST['supplier_id'] ?? 0);
    if ($supplierId > 0) {
      $sql ="DELETE FROM Supplier WHERE SupplierID = ?";
      $statement = $databaseConnection->prepare($sql);
      $statement->bind_param("i", $supplierId);
      $statement->execute();
    }
    header("Location: suppliers.php");
    exit;
  }
}

//Search for supplier info
$search = trim($_GET['search'] ?? '');
if ($search !== '') {
  $keyword = "%" . $search . "%";
  $sql = "SELECT * FROM Supplier WHERE SupplierName LIKE ? ORDER BY SupplierID";
  $statement = $databaseConnection->prepare($sql);
  $statement->bind_param("s", $keyword);
  $statement->execute();
  $suppliers=$statement->get_result();
} 
else {
  $suppliers=$databaseConnection->query("SELECT * FROM Supplier ORDER BY SupplierID");
}
?>
<!--HTML&CSS Codes-->
<!doctype html>
<html>
<head>
  <title>Admin | Suppliers information</title>
  <style>
    body{
      font-family:Arial;
      background:#0b0b0d;
      color:#fff;
      margin:0
    }
    .wrap{
      width:1100px;
      margin:40px auto;
    }
    h1{
        margin:0 0 10px;
    }
    .box{
      background:#121216;
      padding:20px;
      border-radius:14px;
      margin-bottom:18px;
      border:1px solid rgba(255,255,255,.12);
    }
    table{
      width:100%;
      border-collapse:collapse;
      margin-top:14px;
    }
    th,td{
      padding:10px;
      border-bottom:1px solid #333;
      text-align:left;
    }
    th{
        color:#cfcfd4;
    }
    input,button{
      padding:8px;
      border-radius:8px;
      border:none;
      margin:4px;
      outline:none;
    }
    input{
        width:220px;
    }
    button{
      cursor:pointer;
      background:#d71920;
      color:#fff;
      font-weight:700;
    }
    .btn-lite{
      background:transparent;
      border:1px solid rgba(255,255,255,.12);
      color:#fff;
      display:inline-block;
      padding:8px 14px;
      border-radius:10px;
      text-decoration:none;
    }
    .danger{
        background:#ff4d4d;
    }
    .row-actions{
        display:flex;
        gap:8px;
        align-items:center;
    }
  </style>
</head>
<body>

<div class="wrap">

  <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;">
    <h1 style="margin:0;">Suppliers Management</h1>
    <a href="admin.php" class="btn-lite">← Back to Dashboard</a>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Add New Supplier</h3>
    <form method="post">
      <input name="supplier_name" placeholder="Supplier Name" required>
      <input name="phone" placeholder="Phone">
      <input name="address" placeholder="Address">
      <button type="submit" name="add_supplier">Add Supplier</button>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Search Supplier</h3>
    <form method="get" style="display:flex;flex-wrap:wrap;align-items:center;gap:6px;">
      <input name="search" placeholder="Search by name" value="<?= htmlspecialchars($search) ?>">
      <button type="submit">Search</button>
      <a class="btn-lite" href="suppliers.php" style="padding:8px 12px;">Reset</a>
    </form>
  </div>

  <div class="box">
    <h3 style="margin:0 0 10px;">Suppliers List</h3>

    <table>
      <tr>
        <th>ID</th>
        <th>Supplier Name</th>
        <th>Phone</th>
        <th>Address</th>
        <th>Action</th>
      </tr>

      <?php while ($s = $suppliers->fetch_assoc()): ?>
        <tr>
          <td><?= (int)$s['SupplierID'] ?></td>
          <td><?= htmlspecialchars($s['SupplierName']) ?></td>
          <td><?= htmlspecialchars($s['Phone'] ?? '') ?></td>
          <td><?= htmlspecialchars($s['Address'] ?? '') ?></td>
          <td>
            <form method="post" class="row-actions" onsubmit="return confirm('Delete this supplier?');">
              <input type="hidden" name="supplier_id" value="<?= (int)$s['SupplierID'] ?>">
              <button class="danger" type="submit" name="delete_supplier">Delete</button>
            </form>
          </td>
        </tr>
      <?php endwhile; ?>
    </table>

  </div>

</div>

</body>
</html>
