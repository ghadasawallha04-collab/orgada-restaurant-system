<?php
require_once "DB.php";

$username = "admin";
$password = "123456";
$role     = "admin";

$hash = password_hash($password, PASSWORD_DEFAULT);

$stmt = $databaseConnection->prepare(
  "INSERT INTO Users (Username, PasswordHash, Role) VALUES (?, ?, ?)"
);
$stmt->bind_param("sss", $username, $hash, $role);
$stmt->execute();

echo "User created successfully.<br>";
echo "Username: $username <br>";
echo "Password: $password <br>";
echo "<b>DELETE THIS FILE NOW.</b>";
