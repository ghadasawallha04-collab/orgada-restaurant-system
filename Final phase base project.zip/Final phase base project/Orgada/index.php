<?php
session_start();
?>
<!doctype html>
<html>
<head>
  <title>Orgada Burgers</title>

  <style>
    :root{
      --red:#d71920;
      --black:#0b0b0d;
      --white:#ffffff;
      --muted:#cfcfd4;
      --border:rgba(255,255,255,.12);
      --shadow: 0 18px 45px rgba(0,0,0,.45);
      --radius:18px;
    }

    *{box-sizing:border-box}

    body{
      margin:0;
      font-family: Arial, sans-serif;
      background:var(--black);
      color:var(--white);
    }

    a{color:inherit;text-decoration:none}

    .wrap{
      width:1150px;
      margin:0 auto;
    }

    /********************************** NAV ****************************/
    .nav{
      background:#0b0b0d;
      border-bottom:1px solid var(--border);
    }

    .nav-inner{
      display:flex;
      align-items:center;
      justify-content:space-between;
      padding:14px 0;
    }

    .brand{
      display:flex;
      align-items:center;
      gap:12px;
    }

    .brand img{
      width:46px;
      height:46px;
      border-radius:14px;
      background:#fff;
      object-fit:cover;
    }

    .brand b{
      font-size:16px;
    }

    .brand span{
      display:block;
      font-size:12px;
      color:var(--muted);
      margin-top:3px;
    }

    .nav-links{
      display:flex;
      gap:18px;
      font-size:13px;
      color:var(--muted);
    }

    .nav-links a:hover{
      color:var(--white);
    }

    .btn{
      padding:10px 14px;
      border-radius:14px;
      border:1px solid var(--border);
      font-weight:700;
      cursor:pointer;
    }

    .btn.primary{
      background:var(--red);
      border:none;
    }

    /******************************** HERO ***************************/
    .hero{
      padding:50px 0;
    }

    .hero-grid{
      display:grid;
      grid-template-columns: 1.2fr .8fr;
      gap:18px;
    }

    .card{
      background:#121216;
      border:1px solid var(--border);
      border-radius:var(--radius);
      padding:22px;
      box-shadow:var(--shadow);
    }

    h1{
      margin-top:0;
      font-size:40px;
    }

    h2{
      margin-top:0;
      font-size:22px;
    }

    p{
      color:var(--muted);
      line-height:1.7;
      font-size:15px;
    }

    /************************************** HERO IMAGE ***********************************/
    .hero-photo{
      width:100%;
      height:240px;
      object-fit:cover;
      border-radius:16px;
      border:1px solid var(--border);
      margin-top:12px;
    }

    .actions{
      display:flex;
      gap:10px;
      margin-top:16px;
    }

    /* SECTIONS */
    .section{
      padding:30px 0;
    }

    .grid-3{
      display:grid;
      grid-template-columns:repeat(3,1fr);
      gap:14px;
      margin-top:14px;
    }

    .tile{
      background:#16161b;
      border:1px solid var(--border);
      border-radius:var(--radius);
      padding:16px;
    }

    .tile b{
      display:block;
      margin-bottom:6px;
    }

    .divider{
      height:1px;
      background:var(--border);
      margin:20px 0;
    }

    .footer{
      text-align:center;
      font-size:12px;
      color:var(--muted);
      padding:30px 0;
    }
  </style>
</head>

<body>

<!------------------- NAV -------------------------->
<header class="nav">
  <div class="wrap nav-inner">
    <div class="brand">
      <img src="assets/logo.jpg" alt="Orgada Logo">
      <div>
        <b>ORGADA BURGERS</b>
        <span>Fresh • Juicy • Bold Taste</span>
      </div>
    </div>

    <nav class="nav-links">
      <a href="#about">About</a>
      <a href="#menu">Menu</a>
      <a href="#contact">Contact</a>
    </nav>

    <?php if(isset($_SESSION['role'])): ?>
      <a class="btn" href="logout.php">Logout</a>
    <?php else: ?>
      <a class="btn primary" href="login.php">Staff Login</a>
    <?php endif; ?>
  </div>
</header>

<!------------------------------ HERO *--------------------------->

<section class="hero">
  <div class="wrap hero-grid">

    <div class="card">
      <h1>Burgers made with care and consistency.</h1>
      <p>
        At Orgada Burgers, we focus on doing the basics right.
        We use fresh ingredients, keep our kitchens organized,
        and follow a clear process so the taste stays the same
        in every branch.
      </p>

      <img class="hero-photo" src="assets/orgada.jpg" alt="Orgada picture">

      <div class="actions">
        <a class="btn primary" href="#menu">View Menu</a>

        <?php if(isset($_SESSION['role'])): ?>
          <a class="btn" href="orders.php">Orders</a>
        <?php endif; ?>
      </div>
    </div>

    <div class="card">
      <h2>Why Orgada?</h2>
      <p>
        Orgada is built around organization.
        A clear system helps our staff work better
        and makes sure customers get their orders
        quickly and correctly.
      </p>
     <img class="hero-photo" src="assets/orgada2.jpg" alt="Orgada2 picture">
    </div>

  </div>
</section>

<!-------------------------------- ABOUT -------------------------->
<section class="section" id="about">
  <div class="wrap">
    <div class="card">
      <h2>About Us</h2>
      <p>
        We are two computer engeneering students Ghada Sawallha with ID: 1220064 and Malak Obaid with ID:1220203
      </p>
      <p>
        Our system helps manage orders, employees,
        and daily operations so every branch follows
        the same standards and delivers the same experience.
      </p>
    </div>
  </div>
</section>

<!------------------------------- MENU --------------------------->
<section class="section" id="menu">
  <div class="wrap">
    <div class="card">
      <h2>Menu</h2>

      <div class="grid-3">
        <div class="tile">
          <b>Classic Cheeseburger</b>
          <p>
            A simple classic with a fresh beef patty,
            melted cheese, lettuce, tomato,
            and our house sauce.
          </p>
        </div>

        <div class="tile">
          <b>Spicy Burger</b>
          <p>
            Grilled beef with a spicy kick,
            crispy toppings, and a bold sauce.
          </p>
        </div>

        <div class="tile">
          <b>Chicken Burger</b>
          <p>
            Juicy chicken breast,
            fresh lettuce,
            and a smooth creamy sauce.
          </p>
        </div>
      </div>
    </div>
  </div>
</section>

<!-------------------------------------- CONTACT ---------------------------->
<section class="section" id="contact">
  <div class="wrap">
    <div class="card">
      <h2>Contact Us</h2>
      <p>
        If you have questions, feedback,
        or business inquiries, feel free to contact us.
      </p>

      <div class="divider"></div>

      <p>
        Phone: 1700405060<br>
        Email: info@orgada.ps<br>
        Location: Palestine
      </p>
    </div>
  </div>
</section>

<footer class="footer">
  copyright 2025 Orgada Burgers — Ghada1220064 - Malak1220203
</footer>

</body>
</html>
