-- ================================
-- DUMMY DATA FOR ORGADA DATABASE 
-- ================================

-- 1) Branch
INSERT IGNORE INTO Branch (BranchName, City, Address, Phone) VALUES
('Ramallah Center', 'Ramallah', 'Main St.', 22955123),
('Birzeit Branch',  'Birzeit',  'University St.', 22855999);

-- 2) Employee
INSERT IGNORE INTO Employee (BranchID, FirstName, LastName, Position, HireDate, Phone, Salary) VALUES
(1, 'Ghada', 'Sawalha',  'Cashier', '2023-02-15', 599123456, 2500.00),
(1, 'Aya',   'AbuLibdeh','Manager','2021-06-01', 599001234, 4500.00),
(2, 'Malak', 'Obaid',    'Chef',   '2022-09-10', 599988776, 3200.00);

-- 3) Customer
INSERT IGNORE INTO Customer (FirstName, LastName, Phone, Address) VALUES
('Omar',  'Hassan', 599551122, 'Ramallah'),
('Lina',  'Khaled', 599338877, 'Birzeit'),
('Ahmad', 'Saleh',  599111222, 'Nablus'),
('Sara',  'Yousef', 599777111, 'Ramallah'),
('Kareem','Ali',    599333444, 'Birzeit');

-- 4) PaymentMethod
INSERT IGNORE INTO PaymentMethod (PaymentMethodName) VALUES
('Cash'),
('Card'),
('Online');

-- 5) DeliveryCompany
INSERT IGNORE INTO DeliveryCompany (CompanyName, Phone) VALUES
('Talabat', 1700000000),
('Local Delivery', 599444555);

-- 6) Category
INSERT IGNORE INTO Category (CategoryName) VALUES
('Burgers'),
('Sides'),
('Drinks'),
('Desserts');

-- 7) Recipe
INSERT IGNORE INTO Recipe (RecipeName) VALUES
('Classic Burger'),
('Chicken Burger'),
('French Fries'),
('Cola'),
('Ice Cream');

-- 8) Ingredient
INSERT IGNORE INTO Ingredient (IngredientName, Unit) VALUES
('Bun', 'pcs'),
('Beef Patty', 'pcs'),
('Chicken Patty', 'pcs'),
('Cheese', 'pcs'),
('Potato', 'kg'),
('Cola Syrup', 'ml'),
('Ice Cream Mix', 'ml');

-- 9) RecipeIngredient (link recipes to ingredients)

-- Classic Burger (RecipeID = 1): Bun + Beef Patty + Cheese
INSERT IGNORE INTO RecipeIngredient (IngredientID, RecipeID, Quantity) VALUES
(1, 1, 1.00),  -- Bun
(2, 1, 1.00),  -- Beef Patty
(4, 1, 1.00);  -- Cheese

-- Chicken Burger (RecipeID = 2): Bun + Chicken Patty + Cheese
INSERT IGNORE INTO RecipeIngredient (IngredientID, RecipeID, Quantity) VALUES
(1, 2, 1.00),  -- Bun
(3, 2, 1.00),  -- Chicken Patty
(4, 2, 1.00);  -- Cheese

-- French Fries (RecipeID = 3): Potato
INSERT IGNORE INTO RecipeIngredient (IngredientID, RecipeID, Quantity) VALUES
(5, 3, 0.25);

-- Cola (RecipeID = 4): Cola Syrup
INSERT IGNORE INTO RecipeIngredient (IngredientID, RecipeID, Quantity) VALUES
(6, 4, 200.00);

-- Ice Cream (RecipeID = 5): Ice Cream Mix
INSERT IGNORE INTO RecipeIngredient (IngredientID, RecipeID, Quantity) VALUES
(7, 5, 150.00);

-- 10) MenuItem
INSERT IGNORE INTO MenuItem (CategoryID, recipeID, MenuItemName, price, IsAvailable) VALUES
(1, 1, 'Classic Burger', 25.00, TRUE),
(1, 2, 'Chicken Burger', 24.00, TRUE),
(2, 3, 'French Fries',   10.00, TRUE),
(3, 4, 'Cola',            7.00, TRUE),
(4, 5, 'Ice Cream',      12.00, TRUE);

-- ✅ Extras (مرة واحدة فقط)
INSERT IGNORE INTO Extra (ExtraName, ExtraPrice, IsAvailable) VALUES
('Cheese', 3.0, TRUE),
('Sauce',  1.5, TRUE),
('Spicy',  0.0, TRUE),
('Extra Patty', 6.0, TRUE);

-- 11) Supplier
INSERT IGNORE INTO Supplier (SupplierName, Phone, Address) VALUES
('FreshFoods Co.', 599777888, 'Ramallah Industrial Area'),
('DairyPlus',      599222333, 'Birzeit'),
('PotatoFarm',     599888111, 'Nablus');

-- 12) Warehouse
INSERT IGNORE INTO Warehouse (WarehouseName) VALUES
('Main Warehouse'),
('Backup Warehouse');

-- 13) Purchase
INSERT IGNORE INTO Purchase (supplierID, warehouseId, PurchaseDate, branchId, TotalAmount, PurchaseStatus) VALUES
(1, 1, '2025-12-01',1, 300.00, 'Received'),
(2, 1, '2025-12-03',2, 150.00, 'Received'),
(3, 2, '2025-12-05',1, 200.00, 'Pending');

-- 14) PurchaseItem
INSERT IGNORE INTO PurchaseItem (PurchaseID, IngredientID, Cost, Quantity, ExpiryDate) VALUES
(1, 1, 0.80,  50, '2026-01-01'),
(1, 2, 2.50,  50, '2026-01-01'),
(1, 5, 15.00, 10, '2026-02-01'),
(2, 4, 1.20,  60, '2026-01-15'),
(2, 7, 2.00,  40, '2026-01-20'),
(3, 6, 0.50, 300, '2026-03-01');

-- 15) StockMovement
INSERT IGNORE INTO StockMovement (WarehouseID, IngredientID, MovementType, MovementDate, Quantity) VALUES
(1, 1, 'IN',  '2025-12-01', 50),
(1, 2, 'IN',  '2025-12-01', 50),
(1, 5, 'IN',  '2025-12-01', 10),
(1, 4, 'IN',  '2025-12-03', 60),
(1, 7, 'IN',  '2025-12-03', 40),
(2, 6, 'IN',  '2025-12-05', 300),
(1, 5, 'OUT', '2025-12-10', 2),
(1, 1, 'OUT', '2025-12-10', 5);

-- 16) Orders
INSERT IGNORE INTO Orders (BranchID, customerID, employeeid, paymentmethodID, deliverycompanyID, OrderDate, OrderType, TotalAmount) VALUES
(1, 1, 1, 1, NULL, '2025-12-10', 'Dine-In',   35.00),
(1, 2, 1, 3, 1,    '2025-12-10', 'Delivery',  32.00),
(2, 3, 3, 2, NULL, '2025-12-11', 'Takeaway',  24.00);

-- 17) OrderItem
INSERT IGNORE INTO OrderItem (OrderID, MenuItemID, Quantity, price) VALUES
(1, 1, 1, 25.00),
(1, 3, 1, 10.00),
(2, 1, 1, 25.00),
(2, 4, 1,  7.00),
(3, 2, 1, 24.00);

-- ✅ MenuItemExtra (ExtraID)
INSERT IGNORE INTO MenuItemExtra (MenuItemID, ExtraID)
SELECT 1, ExtraID FROM Extra WHERE ExtraName IN ('Cheese','Sauce','Spicy','Extra Patty');

INSERT IGNORE INTO MenuItemExtra (MenuItemID, ExtraID)
SELECT 2, ExtraID FROM Extra WHERE ExtraName IN ('Cheese','Sauce','Spicy','Extra Patty');

-- ================================
-- END DUMMY DATA
-- ================================